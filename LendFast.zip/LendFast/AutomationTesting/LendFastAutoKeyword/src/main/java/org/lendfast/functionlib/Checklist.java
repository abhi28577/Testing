package org.lendfast.functionlib;

import java.util.List;
//import org.openqa.selenium.JavascriptExecutor;

import org.lendfast.base.ParentPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Checklist extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
	Checklist submitclaim;
	
	String LendFastPath = System.getProperty("user.dir");
										
	//Defining WebElements
									
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Check List')]")
	WebElement HeadSection;
		
	//Logout
	@FindBy(linkText="Logout")
	WebElement LogOutClick;
		
	//Define Image Link	
	@FindBy(linkText="Image")
	WebElement ImageClick;
		
	//Define Complete Link	
	@FindBy(linkText="Complete")
	WebElement CompleteClick;
	
	//Define Override Link	
	@FindBy(linkText="Override")
	WebElement OverrideClick;
	
	//Define GoTo Link	
	@FindBy(linkText="Goto")
	WebElement GotoClick;
	
	//Popup Close Button
	@FindBy(xpath="//input[@class='closePopupButtonIcon']")
	WebElement PopupCloseButton;
		
	//Define Defunc Items
	@FindBy(xpath="//input[@id='main:cklstexcludeCompleted:cklstexcludeCompleted']")
	WebElement CheckDefunctList;
			
	//Define Mandatory Checkbox Submission List
	@FindBy(xpath="//input[@id='main:cklstexcludeNonMandatory:cklstexcludeNonMandatory']")
	WebElement CheckMandateList;
		
	//Submission Position
	@FindBy(xpath="//td[@id = 'main:checkList:0:j_id835']")
	WebElement SubmissionPosition;
			
	//Select Identification Document
	@FindBy(xpath="//select[@id='main:docType:docType']")
	WebElement SelectIdentityType;
		
	//Upload File
	@FindBy(xpath="//input[@id='main:fileUpload:upload:file']")
	WebElement UploadFile;
		
	//Select Submission Process
	@FindBy(xpath="//select[@id='main:docSource:docSource']")
	WebElement SelectSubmissionType;
		
	//Define Add Document Button
	@FindBy(xpath="//input[@id='main:addDocumentBtn']")
	WebElement AddDocClick;
		
	//Define Select Link
	@FindBy(xpath="//input[@id='main:docRelatedTo:selectBtn']")
	WebElement SelectLinkClick;
		
	//Define Ok Button
	@FindBy(xpath="//input[@id='docReqChooserForm:okBtn']")
	WebElement SelectOkClick;
		
	//Select Link
	@FindBy(xpath="//input[@id='main:docRelatedTo:selectBtn']")
	WebElement SelectListClick;	
		
	//Checkbox Verification
	@FindBy(xpath="//input[@id='main:docRelatedTo:requirementsVerified']")
	WebElement CheckboxVerify;
		
	//Document Verification
	@FindBy(xpath="//select[@id='main:statusCbo']")
	WebElement SelectDocumentVerify;	
		
	//Applicant Insurance Verification
	@FindBy(xpath="//textarea[@id='main:cklstverificationNote:cklstverificationNote']")
	WebElement InputApplicantInsuranceVerify;
		
	//Additional Information/Comments
	@FindBy(xpath="//textarea[@id='main:appsubmitComment:appsubmitComment']")
	WebElement InputAdditionalInfo;
		
	//Save Additional Information/Comments
	@FindBy(xpath="//input[@id='main:saveCommentsBtn:saveCommentsBtn']")
	WebElement SaveAdditionalInfoClick;
		
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
		
	//Yes Button
	@FindBy(xpath="//input[@id='yes']")
	WebElement YesClick;
		
	//Submit Button
	@FindBy(xpath="//input[@id='main:submitbutton']")
	WebElement SubmitClick;
	
	//Status Tab
	//@FindBy(xpath="//div[@id = 'docReqChooserForm:docRelatedTo:j_id1169header:sortDiv']")
	@FindBy(xpath="//div[@id = 'docReqChooserForm:docRelatedTo:j_id1170header:sortDiv']")
	WebElement StatusLink;
	
	//NPBS Interested Party - Yes
	@FindBy(xpath="//input[@id='main:isLenderNotedAsInterestedParty:isLenderNotedAsInterestedParty:0']")
	WebElement RadioNPBSYes;
		
	//NPBS Interested Party - No
	@FindBy(xpath="//input[@id='main:isLenderNotedAsInterestedParty:isLenderNotedAsInterestedParty:1']")
	WebElement RadioNPBSNo;
	
	//Input Policy Number
	@FindBy(xpath="//input[@id='main:assetinsPolpolicyNum:assetinsPolpolicyNum']")
	WebElement InputPolicyNumber;
		
	//Input Amount Coverage
	@FindBy(xpath="//input[@id='main:assetinsPolamountOfCover:assetinsPolamountOfCover']")
	WebElement InputCoverageAmount;
	
	//Input Expiry Date
	@FindBy(xpath="//input[@id='main:assetinsPolexpiryDate:assetinsPolexpiryDateInputDate']")
	WebElement InputExpiryDate;
	
	//Insurance Required - Yes
	@FindBy(xpath="//input[@id='main:isInsuranceRequired:isInsuranceRequired:0']")
	WebElement RadioInsuranceRequiredYes;
		
	//Insurance Required - No
	@FindBy(xpath="//input[@id='main:isInsuranceRequired:isInsuranceRequired:1']")
	WebElement RadioInsuranceRequiredNo;
		
	//Insurance Policy Type - New
	@FindBy(xpath="//input[@id='main:securityinsPrempolicyNewExisting:securityinsPrempolicyNewExisting:0']")
	WebElement RadioInsuranceTypeYes;
			
	//Insurance Policy Type - Existing
	@FindBy(xpath="//input[@id='main:securityinsPrempolicyNewExisting:securityinsPrempolicyNewExisting:1']")
	WebElement RadioInsuranceTypeNo;
		
	//Select Insurance Company Code
	@FindBy(xpath="//select[@id='main:assetinsPolcompCode:assetinsPolcompCode']")
	WebElement SelectInsuranceCompanyCode;
	
	//Select Policy Type
	@FindBy(xpath="//select[@id='main:assetinsPolpolicyType:assetinsPolpolicyType']")
	WebElement SelectPolicyType;
		
	//Constructor
	public Checklist()
	{			
		//PageFactory.initElements(driver, this); //Local Host
		PageFactory.initElements(driver.get(), this); //Remote Host
		funclib=new CommonFuncLib();		
	}
					
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Check List");		
		return HeadSectionResult;
	}	
		
	//Select Non-Mandatory List
	public void NonMandatory() throws InterruptedException
	{
		funclib.DelayTime();
		CheckDefunctList.click();
		funclib.DelayTime();
		funclib.DelayTime();		
		funclib.DelayTime();
		funclib.DelayTime();
		
		CheckMandateList.click();
		funclib.DelayTime();
		funclib.DelayTime();		
		funclib.DelayTime();
		funclib.DelayTime();
		
	}
		
// ******************************************************************************************************************************************************************
	//Submit Origination Claim
// ******************************************************************************************************************************************************************	
	public void SubmitOrigination(String TestCase) throws InterruptedException
	{
	//String SubmitPos = "Submission";
		
		String ImageType="Image";		
		String CompleteType="Complete";
		String GoToType = "Goto";
		
		//WebDriverWait wait = new WebDriverWait(driver, 25); //Local Host
		//Actions action = new Actions(driver);	//Local Host
			
		WebDriverWait wait = new WebDriverWait(driver.get(), 25); //Remote Host
		Actions action = new Actions(driver.get()); //Remote Host
		
		
		//Goto Click		
		//List<WebElement> GoToLink = driver.findElements(By.linkText("Goto")); //Local Host
		List<WebElement> GoToLink = driver.get().findElements(By.linkText("Goto")); //Remote Host
				
		if(!GoToLink.isEmpty())
		{
			funclib.DelayTime();
			String GotoClickResult = funclib.HeadingSection(GotoClick.getText(), "Goto");
			WebElement GoClick = wait.until(ExpectedConditions.elementToBeClickable(GotoClick));
			
			// Count of 'Goto' Text
			System.out.println("Goto Count: " + GoToLink.size());
			
			if(GoToLink.size() >0)
			{
				for(int GotoCounter=1;GotoCounter<=GoToLink.size();GotoCounter++)
				{			
				
					if (GotoClickResult .equals(GoToType))
					{
						funclib.DelayTime();
						action.moveToElement(GoClick).doubleClick(GoClick).perform();
						funclib.DelayTime();
						
						// Switch to Frame using id
						//driver.switchTo().frame("gotoIframe"); //Local Host
						driver.get().switchTo().frame("gotoIframe"); //Remote Host
				
						//Request Quote Validation
						//WebElement RequestQuoteLink = driver.findElement(By.xpath("//input[@id ='main:requestQuoteBtn']")); //Local Host
						WebElement RequestQuoteLink = driver.get().findElement(By.xpath("//input[@id ='main:requestQuoteBtn']")); //Remote Host
						RequestQuoteLink.click();
						
						funclib.DelayTime();
						
						//Navigate Next Page
						funclib.DelayTime();
						NextClick.click();
						
						funclib.DelayTime();
			
						//Capture Screenshot
						funclib.CaptureScreenShot(TestCase);
						
						//Switching from IFrame to Normal Window
						//driver.switchTo().defaultContent(); //Local Host
						driver.get().switchTo().defaultContent(); //Remote Host
						
						funclib.DelayTime();
						PopupCloseButton.click();
						funclib.DelayTime();
					
												
					}					
				}
			}
		}
		
		funclib.DelayTime();
		
		//Complete Click
		//List<WebElement> CompleteLink = driver.findElements(By.linkText("Complete")); //Local Host
		List<WebElement> CompleteLink = driver.get().findElements(By.linkText("Complete")); //Remote Host
				
		if(!CompleteLink.isEmpty())
		{
			funclib.DelayTime();
			String CompleteClickResult = funclib.HeadingSection(CompleteClick.getText(), "Complete");
			WebElement CompClick = wait.until(ExpectedConditions.elementToBeClickable(CompleteClick));
			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteLink.size());
			
			// Refreshing URL Browser				
			//driver.navigate().refresh(); //Local Host
			driver.get().navigate().refresh(); //Remote Host
			
			if(CompleteLink.size() >0)
			{
				for(int CompleteCounter=1;CompleteCounter<=CompleteLink.size();CompleteCounter++)
				{			
				
					if (CompleteClickResult .equals(CompleteType))
					{
						funclib.DelayTime();
						action.moveToElement(CompClick).doubleClick(CompClick).perform();
						funclib.DelayTime();
				
						//Input Applicant Insurance Verification
						InputApplicantInsuranceVerify.clear();
						funclib.DelayTime();
						InputApplicantInsuranceVerify.sendKeys("Verified Successfully");
						funclib.DelayTime();
			
						//Capture Screenshot
						funclib.CaptureScreenShot(TestCase);
					
						//Navigate Next Page
						funclib.DelayTime();
						NextClick.click();
						funclib.DelayTime();
					}					
				}
			}
		}
		
		funclib.DelayTime();
		for(int ImageCount=1;ImageCount<=3;ImageCount++)
		{
			//Image Click	
			//List<WebElement> ImageLink = driver.findElements(By.xpath("//*[contains(text(),'Image')]")); //Local Host
			List<WebElement> ImageLink = driver.get().findElements(By.xpath("//*[contains(text(),'Image')]")); //Remote Host
		
			if(!ImageLink.isEmpty())
			{
				String ImageClickResult = funclib.HeadingSection(ImageClick.getText(), "Image");
				WebElement ImgClick = wait.until(ExpectedConditions.elementToBeClickable(ImageClick));
				
				// Count of 'Image' Text	
				System.out.println("Image Count: " + ImageLink.size());
				
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				if(ImageLink.size()>0)
				{				
					if (ImageClickResult .equals(ImageType))
					{
						funclib.DelayTime();
						action.moveToElement(ImgClick).doubleClick(ImgClick).perform();				
					
						//Click on Add Document Link
						funclib.DelayTime();
						AddDocClick.click();
						funclib.DelayTime();				
					 
						//Clicking on Select Link
						funclib.DelayTime();
						SelectLinkClick.click();
						funclib.DelayTime();
						
						//Click on Status Link
						if(ImageCount >1)
						{
							StatusLink.click();
							funclib.DelayTime();
						}
					
						//Checking all Checkboxes
						String CheckboxPath = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//input";
						String Summary = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[2]";
						String StatusCheck = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[3]//span";
						
						//List<WebElement> checkBoxes = driver.findElements(By.xpath(CheckboxPath)); //Local Host
						//List<WebElement> SummaryChecks = driver.findElements(By.xpath(Summary)); //Local Host
						//List<WebElement> StatusChecks = driver.findElements(By.xpath(StatusCheck)); //Local Host
						
						List<WebElement> checkBoxes = driver.get().findElements(By.xpath(CheckboxPath)); //Remote Host
						List<WebElement> SummaryChecks = driver.get().findElements(By.xpath(Summary)); //Remote Host
						List<WebElement> StatusChecks = driver.get().findElements(By.xpath(StatusCheck)); //Remote Host
						
						String OutStandingValue="Outstanding";				
						
						//CheckMark each
						System.out.println("Status Check Count:" + StatusChecks.size());
						for(int i=0;i<StatusChecks.size();i++)
						{					
							if(StatusChecks.get(i).getText() .equals(OutStandingValue))
							{
								System.out.println("Status:" + StatusChecks.get(i).getText());
								if(!checkBoxes.get(i).isSelected())
									checkBoxes.get(i).click();
								funclib.DelayTime();
							}
							else
							{
								System.out.println("Summary Check:" + SummaryChecks.get(i).getText());
								System.out.println("Status:" + StatusChecks.get(i).getText());
								System.out.println("Loop Counter: " +i);
							}
						}		     
						
						//Click on OK Button
						System.out.println("Status Check Count:" + StatusChecks.size());
						funclib.DelayTime();
						SelectOkClick.click();
						funclib.DelayTime();
						
						//Checking all Reference Textboxes
						String TextboxPath = "//tbody[contains(@id,'main:docRelatedTo:docRelatedTo:tb')]//input";
						//List<WebElement> TextBoxes = driver.findElements(By.xpath(TextboxPath)); //Local Host
						List<WebElement> TextBoxes = driver.get().findElements(By.xpath(TextboxPath)); //Remote Host						
						for(WebElement textbox: TextBoxes)
						{				        
							funclib.DelayTime();
							if(!textbox.isSelected())				    	
								textbox.sendKeys("Verified");				    				    	
						}
											
						//Checkbox on Verified Documents
						funclib.DelayTime();
						CheckboxVerify.click();
					 
						//Select Predominant Purpose
						funclib.DelayTime();
						String SelectIdentity= "Identification";
						funclib.DropdownListSelect(SelectIdentity, SelectIdentityType);
						
						funclib.DelayTime();
						JavascriptExecutor js = (JavascriptExecutor) driver.get(); //Remote Host
						
						//This will scroll the web page till end.		
				        js.executeScript("window.scrollTo(0, document.body.scrollHeight)"); //Remote Host
						
						//Select Submission Process
						funclib.DelayTime();
						String SelectSubmission= "Upload";
						funclib.DropdownListSelect(SelectSubmission, SelectSubmissionType);
						funclib.DelayTime();
						
						//Upload File
						String LendFastPath = System.getProperty("user.dir");
						//funclib.DelayTime();
						//UploadFile.sendKeys(LendFastPath + "//Sample.pdf"); //Local Host						
						UploadFile.sendKeys("//automatedtesting//Results//lendfast//Sample.pdf"); //Remote Host
						funclib.DelayTime();
						funclib.DelayTime();
						funclib.DelayTime();
						
						//Capture Screenshot
						funclib.CaptureScreenShot(TestCase);
						
						//Navigate Next Page
						funclib.DelayTime();
						NextClick.click();
						
						//Select Verification Status
						funclib.DelayTime();
						String SelectDocumentationVerify= "Verified";
						funclib.DropdownListSelect(SelectDocumentationVerify,SelectDocumentVerify);
						funclib.DelayTime();
					
						//Capture Screenshot
						funclib.CaptureScreenShot(TestCase);
							
						//Navigate Next Page
						funclib.DelayTime();
						NextClick.click();
						
						//Capture Screenshot
						funclib.CaptureScreenShot(TestCase);
						funclib.DelayTime();
					}				
				}			
			}
		}		
		
		//Navigating to Submit Page
		
		//Capture Screenshot
		funclib.CaptureScreenShot(TestCase);
				
		//Navigate Next Page
		funclib.DelayTime();
		NextClick.click();
		
		//Input Additional Information/Submission Comments
		funclib.DelayTime();
		InputAdditionalInfo.sendKeys("Submit Successfully");
		funclib.DelayTime();
		
		//Save Additional Information/Submission Comments
		SaveAdditionalInfoClick.click();		
		Thread.sleep(10000);		
		
		//Submit Application Id
		SubmitClick.click();
		funclib.DelayTime();
		
		//Yes Button
		YesClick.click();
		Thread.sleep(40000);
		
		//Capture Screenshot
		funclib.CaptureScreenShot(TestCase);		
		
		//Close Browser/Logging Out
		Thread.sleep(5000);
		
		//Capture Screenshot
		funclib.CaptureScreenShot(TestCase);
		LogOutClick.click();
		Thread.sleep(5000);
		//driver.close();
		//driver.get().close();
	}
	
// ******************************************************************************************************************************************************************	
	//Submit Credit Analysis Claim
// ******************************************************************************************************************************************************************
	public void SubmitCreditAnalysis(String TestCase) throws InterruptedException
	{		
		String CompleteType="Complete";
		String OverrideType="Override";
		String ImageType="Image";	
		
		
		//WebDriverWait wait = new WebDriverWait(driver, 25); //Local Host
		//Actions action = new Actions(driver);	//Local Host
		
		WebDriverWait wait = new WebDriverWait(driver.get(), 25); //Remote Host
		Actions action = new Actions(driver.get());	 //Remote Host
		
		//Complete Click - Refer to Assessor (Security)
		//java.util.List<WebElement> CompleteLink=driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Refer to Assessor (Security)')]")); //Local Host
		java.util.List<WebElement> CompleteLink=driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Refer to Assessor (Security)')]")); //Remote Host
		
		if(!CompleteLink.isEmpty())
		{
			String CompleteClickResult = funclib.HeadingSection(CompleteClick.getText(), "Complete");
			
			funclib.DelayTime();
			WebElement CompClick = wait.until(ExpectedConditions.elementToBeClickable(CompleteClick));				
			
		
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteLink.size());
			
			if(CompleteLink.size() >0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				for(int CompleteCounter=1;CompleteCounter<=CompleteLink.size();CompleteCounter++)
				{			
				
					if (CompleteClickResult .equals(CompleteType))
					{
						funclib.DelayTime();
						action.moveToElement(CompClick).doubleClick(CompClick).perform();
						funclib.DelayTime();
				
						//Input Applicant Insurance Verification
						InputApplicantInsuranceVerify.clear();
						funclib.DelayTime();
						
						// Applicable for Scenario - 30
						//InputApplicantInsuranceVerify.sendKeys("4,17,27 # applicable outside policy exception comments");
						InputApplicantInsuranceVerify.sendKeys("Verified Successfully");
						funclib.DelayTime();
			
						//Capture Screenshot
						funclib.CaptureScreenShot(TestCase);
					
						//Navigate Next Page
						funclib.DelayTime();
						NextClick.click();						
					}					
				}
			}
		}
		
		//Image Click - Conditional Approval and Approval	
		//java.util.List<WebElement> ImageLink=driver.findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Conditional Approval and Approval')]")); //Local Host
		java.util.List<WebElement> ImageLink=driver.get().findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Conditional Approval and Approval')]")); //Remote Host
		
		//java.util.List<WebElement> ImageLinkApproval=driver.findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Approval')]")); //Local Host
		java.util.List<WebElement> ImageLinkApproval=driver.get().findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Approval')]")); //Remote Host
		
		if(!ImageLink.isEmpty() || !ImageLinkApproval.isEmpty())
		{
			funclib.DelayTime();
			String ImageClickResult = funclib.HeadingSection(ImageClick.getText(), "Image");
			
			WebElement ImgClick = wait.until(ExpectedConditions.elementToBeClickable(ImageClick));
			
		
			// Count of 'Image' Text	
			System.out.println("Image Count: " + ImageLink.size());
			System.out.println("Image Count: " + ImageLinkApproval.size());
			
			if((ImageLink.size()>0) || (ImageLinkApproval.size()>0))
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				if (ImageClickResult .equals(ImageType))
				{
					funclib.DelayTime();
					action.moveToElement(ImgClick).doubleClick(ImgClick).perform();				
				
					//Click on Add Document Link
					funclib.DelayTime();
					AddDocClick.click();
					funclib.DelayTime();				
				 
					//Clicking on Select Link
					funclib.DelayTime();
					SelectLinkClick.click();
					funclib.DelayTime();
					
					//Click on Status Link
					StatusLink.click();
					funclib.DelayTime();
				
					//Checking all Checkboxes
					String CheckboxPath = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//input";
					String Summary = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[2]";
					String StatusCheck = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[3]//span";				
					
					//List<WebElement> checkBoxes = driver.findElements(By.xpath(CheckboxPath)); //Local Host
					//List<WebElement> SummaryChecks = driver.findElements(By.xpath(Summary)); //Local Host
					//List<WebElement> StatusChecks = driver.findElements(By.xpath(StatusCheck)); //Local Host
					
					List<WebElement> checkBoxes = driver.get().findElements(By.xpath(CheckboxPath)); //Remote Host
					List<WebElement> SummaryChecks = driver.get().findElements(By.xpath(Summary)); //Remote Host
					List<WebElement> StatusChecks = driver.get().findElements(By.xpath(StatusCheck)); //Remote Host
					
					String OutStandingValue="Outstanding";			
					
					//CheckMark each
					funclib.DelayTime();
					System.out.println("Status Check Count:" + StatusChecks.size());
					for(int i=0;i<StatusChecks.size();i++)
					{					
						if(StatusChecks.get(i).getText() .equals(OutStandingValue))
						{
							System.out.println("Status:" + StatusChecks.get(i).getText());
							if(!checkBoxes.get(i).isSelected())
								checkBoxes.get(i).click();
							funclib.DelayTime();
						}
						else
						{
							System.out.println("Summary Check:" + SummaryChecks.get(i).getText());
							System.out.println("Status:" + StatusChecks.get(i).getText());
							System.out.println("Loop Counter: " +i);
						}
					}		     
					
					//Click on OK Button
					System.out.println("Status Check Count:" + StatusChecks.size());
					funclib.DelayTime();
					SelectOkClick.click();
					funclib.DelayTime();
					
					//Checking all Reference Textboxes
					String TextboxPath = "//tbody[contains(@id,'main:docRelatedTo:docRelatedTo:tb')]//input";
					//List<WebElement> TextBoxes = driver.findElements(By.xpath(TextboxPath)); //Local Host
					List<WebElement> TextBoxes = driver.get().findElements(By.xpath(TextboxPath)); //Remote Host
					for(WebElement textbox: TextBoxes)
					{				        
						funclib.DelayTime();
						if(!textbox.isSelected())				    	
							textbox.sendKeys("Verified");				    				    	
					}
					
					//Checkbox on Verified Documents
					funclib.DelayTime();
					CheckboxVerify.click();
				 
					//Select Predominant Purpose
					funclib.DelayTime();
					String SelectIdentity= "Identification";
					funclib.DropdownListSelect(SelectIdentity, SelectIdentityType);
				 
					//Select Submission Process
					funclib.DelayTime();
					String SelectSubmission= "Upload";
					funclib.DropdownListSelect(SelectSubmission, SelectSubmissionType);
					funclib.DelayTime();
					
					//Upload File
					//funclib.DelayTime();					
					//UploadFile.sendKeys(LendFastPath + "//Sample.pdf"); //Local Host
					UploadFile.sendKeys("//automatedtesting//Results//lendfast//Sample.pdf"); //Remote Host
					funclib.DelayTime();
					funclib.DelayTime();
					funclib.DelayTime();
										
					//Capture Screenshot
					funclib.CaptureScreenShot(TestCase);
					
					//Navigate Next Page
					funclib.DelayTime();
					NextClick.click();
					
					//Select Verification Status
					funclib.DelayTime();
					String SelectDocumentationVerify= "Verified";
					funclib.DropdownListSelect(SelectDocumentationVerify,SelectDocumentVerify);
				
					//Capture Screenshot
					funclib.CaptureScreenShot(TestCase);
						
					//Navigate Next Page
					funclib.DelayTime();
					NextClick.click();
					
					//Capture Screenshot
					funclib.CaptureScreenShot(TestCase);
				}				
			}			
		}
		
		//Override Click - Approval
		//java.util.List<WebElement> OverrideLink=driver.findElements(By.xpath("//td/a[contains(text(),'Override')]/../preceding-sibling::td/span[contains(text(),'Approval')]")); //Local Host
		java.util.List<WebElement> OverrideLink=driver.get().findElements(By.xpath("//td/a[contains(text(),'Override')]/../preceding-sibling::td/span[contains(text(),'Approval')]")); //Remote Host
		
		if(!OverrideLink.isEmpty())
		{
			String OverrideClickResult = funclib.HeadingSection(OverrideClick.getText(), "Override");
			
			funclib.DelayTime();
			WebElement OverClick = wait.until(ExpectedConditions.elementToBeClickable(OverrideClick));				
					
				
			// Count of 'Override' Text
			System.out.println("Override Count: " + OverrideLink.size());
					
			if(OverrideLink.size() >0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
						
				for(int OverrideCounter=1;OverrideCounter<=OverrideLink.size();OverrideCounter++)
				{			
						
					if (OverrideClickResult .equals(OverrideType))
					{
						funclib.DelayTime();
						action.moveToElement(OverClick).doubleClick(OverClick).perform();
						funclib.DelayTime();
						
						//Input Applicant Insurance Verification
						InputApplicantInsuranceVerify.clear();
						funclib.DelayTime();
						InputApplicantInsuranceVerify.sendKeys("Verified Successfully");
						funclib.DelayTime();
					
						//Capture Screenshot
						funclib.CaptureScreenShot(TestCase);
							
						//Navigate Next Page
						funclib.DelayTime();
						NextClick.click();						
					}					
				}
			}
		}
		
		//Close Browser/Logging Out
		Thread.sleep(5000);
		//LogOutClick.click();
		//Thread.sleep(5000);
		//driver.close();
		//driver.get().close();
	}
	
	
// ******************************************************************************************************************************************************************	
	//Settlement - Complete
// ******************************************************************************************************************************************************************	
	public void CompleteSettlement(String TestCase) throws InterruptedException
	{
		String CompleteClickResult = funclib.HeadingSection(CompleteClick.getText(), "Complete");
		String CompleteType="Complete";	
		
		//WebDriverWait wait = new WebDriverWait(driver, 25); //Local Host
		//Actions action = new Actions(driver);	//Local Host
		
		WebDriverWait wait = new WebDriverWait(driver.get(), 25); //Remote Host
		Actions action = new Actions(driver.get()); //Remote Host
		WebElement CompClick = wait.until(ExpectedConditions.elementToBeClickable(CompleteClick));
		
		if (CompleteClickResult .equals(CompleteType))
		{
			// Refreshing URL Browser				
			//driver.navigate().refresh(); //Local Host
			driver.get().navigate().refresh(); //Remote Host
			
			funclib.DelayTime();
			action.moveToElement(CompClick).doubleClick(CompClick).perform();
			funclib.DelayTime();
			
			//Input Applicant Insurance Verification
			InputApplicantInsuranceVerify.clear();
			funclib.DelayTime();
			InputApplicantInsuranceVerify.sendKeys("Verified Successfully");
		
			//Capture Screenshot
			funclib.CaptureScreenShot(TestCase);
				
			//Navigate Next Page
			funclib.DelayTime();
			NextClick.click();						
		}					
	}
	
	
// ******************************************************************************************************************************************************************
	//Settlement - Image
// ******************************************************************************************************************************************************************	
	public void ImageSettlement(String TestCase) throws InterruptedException
	{
		String ImageType="Image";
		
		//WebDriverWait wait = new WebDriverWait(driver, 25); //Local Host
		//Actions action = new Actions(driver);	 //Local Host
		
		WebDriverWait wait = new WebDriverWait(driver.get(), 25); //Remote Host
		Actions action = new Actions(driver.get()); //Remote Host
		
		String ImageClickResult = funclib.HeadingSection(ImageClick.getText(), "Image");
		WebElement ImgClick = wait.until(ExpectedConditions.elementToBeClickable(ImageClick));		
		
		if (ImageClickResult .equals(ImageType))
		{
			// Refreshing URL Browser				
			//driver.navigate().refresh(); //Local Host
			driver.get().navigate().refresh(); //Remote Host
			
			funclib.DelayTime();
			
			//driver.navigate().refresh(); //Local Host
			driver.get().navigate().refresh(); //Remote Host
			funclib.DelayTime();			
			
			action.moveToElement(ImgClick).doubleClick(ImgClick).perform();
			funclib.DelayTime();
			//driver.navigate().back(); //Local Host
			driver.get().navigate().back(); //Remote Host
			funclib.DelayTime();
			action.moveToElement(ImgClick).doubleClick(ImgClick).perform();
		
			//Click on Add Document Link
			funclib.DelayTime();
			AddDocClick.click();
			funclib.DelayTime();				
		 
			//Clicking on Select Link
			funclib.DelayTime();
			SelectLinkClick.click();
			funclib.DelayTime();
			
			//Click on Status Link
			StatusLink.click();
			funclib.DelayTime();
		
			//Checking all Checkboxes
			String CheckboxPath = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//input";
			String Summary = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[2]";
			String StatusCheck = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[3]//span";				
			
			//List<WebElement> checkBoxes = driver.findElements(By.xpath(CheckboxPath)); //Local Host
			//List<WebElement> SummaryChecks = driver.findElements(By.xpath(Summary)); //Local Host
			//List<WebElement> StatusChecks = driver.findElements(By.xpath(StatusCheck)); //Local Host
			
			List<WebElement> checkBoxes = driver.get().findElements(By.xpath(CheckboxPath)); //Remote Host
			List<WebElement> SummaryChecks = driver.get().findElements(By.xpath(Summary)); //Remote Host
			List<WebElement> StatusChecks = driver.get().findElements(By.xpath(StatusCheck)); //Remote Host
			
			String OutStandingValue="Outstanding";				
			
			//CheckMark each
			System.out.println("Status Check Count:" + StatusChecks.size());
			for(int i=0;i<StatusChecks.size();i++)
			{					
				if(StatusChecks.get(i).getText() .equals(OutStandingValue))
				{
					System.out.println("Status:" + StatusChecks.get(i).getText());
					if(!checkBoxes.get(i).isSelected())
						checkBoxes.get(i).click();
					funclib.DelayTime();
				}
				else
				{
					System.out.println("Summary Check:" + SummaryChecks.get(i).getText());
					System.out.println("Status:" + StatusChecks.get(i).getText());
					System.out.println("Loop Counter: " +i);
				}
			}		     
			
			//Click on OK Button
			System.out.println("Status Check Count:" + StatusChecks.size());
			funclib.DelayTime();
			SelectOkClick.click();
			funclib.DelayTime();
			
			//Checking all Reference Textboxes
			String TextboxPath = "//tbody[contains(@id,'main:docRelatedTo:docRelatedTo:tb')]//input";
			//List<WebElement> TextBoxes = driver.findElements(By.xpath(TextboxPath)); //Local Host
			List<WebElement> TextBoxes = driver.get().findElements(By.xpath(TextboxPath)); //Remote Host
			for(WebElement textbox: TextBoxes)
			{				        
				funclib.DelayTime();
				if(!textbox.isSelected())				    	
					textbox.sendKeys("Verified");				    				    	
			}
			
			//Checkbox on Verified Documents
			funclib.DelayTime();
			CheckboxVerify.click();
		 
			//Select Predominant Purpose
			funclib.DelayTime();
			String SelectIdentity= "Identification";
			funclib.DropdownListSelect(SelectIdentity, SelectIdentityType);
		 
			//Select Submission Process
			funclib.DelayTime();
			String SelectSubmission= "Upload";
			funclib.DropdownListSelect(SelectSubmission, SelectSubmissionType);
			funclib.DelayTime();
			
			//Upload File
			//funclib.DelayTime();					
			//UploadFile.sendKeys(LendFastPath + "//Sample.pdf"); //Local Host
			UploadFile.sendKeys("//automatedtesting//Results//lendfast//Sample.pdf"); //Remote Host
			funclib.DelayTime();
			funclib.DelayTime();
			funclib.DelayTime();
			
			//Capture Screenshot
			funclib.CaptureScreenShot(TestCase);
			
			//Navigate Next Page
			funclib.DelayTime();
			NextClick.click();
			
			//Select Verification Status
			funclib.DelayTime();
			String SelectDocumentationVerify= "Verified";
			funclib.DropdownListSelect(SelectDocumentationVerify,SelectDocumentVerify);
		
			//Capture Screenshot
			funclib.CaptureScreenShot(TestCase);
				
			//Navigate Next Page
			funclib.DelayTime();
			NextClick.click();
			
			//Capture Screenshot
			funclib.CaptureScreenShot(TestCase);
		}
	}
	
// ******************************************************************************************************************************************************************	
	//Submit Settlement
// ******************************************************************************************************************************************************************	
	public void SubmitSettlement(String TestCase) throws InterruptedException
	{
		//Complete Click - Refer to Assessor (Security)
		//List<WebElement> CompleteAssessor=driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Refer to Assessor (Security)')]")); //Local Host
		List<WebElement> CompleteAssessor=driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Refer to Assessor (Security)')]")); //Remote Host
		
		//Complete Click - Documents Lodged
		//List<WebElement> CompleteLodged=driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Documents Lodged')]")); //Local Host
		List<WebElement> CompleteLodged=driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Documents Lodged')]")); //Remote Host
		
		//Complete Click - Documents Closing
		//List<WebElement> CompleteClosing=driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Closing')]")); //Local Host
		List<WebElement> CompleteClosing=driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Closing')]")); //Remote Host
		
		//Complete Assessor
		if(!CompleteAssessor.isEmpty())
		{			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteAssessor.size());
							
			if(CompleteAssessor.size() >0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				for(int CompleteCounter=1;CompleteCounter<=CompleteAssessor.size();CompleteCounter++)
				{			
					funclib.DelayTime();
					CompleteSettlement(TestCase);					
				}
			}
		}
		
		//Complete Documents Lodged
		if(!CompleteLodged.isEmpty())
		{			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteLodged.size());
							
			if(CompleteLodged.size() >0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
						
				for(int CompleteCounter=1;CompleteCounter<=CompleteLodged.size();CompleteCounter++)
				{			
					funclib.DelayTime();
					CompleteSettlement(TestCase);					
				}
			}
		}
		
		//Complete Documents Closing
		if(!CompleteClosing.isEmpty())
		{			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteClosing.size());
									
			if(CompleteClosing.size() >0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
								
				for(int CompleteCounter=1;CompleteCounter<=CompleteClosing.size();CompleteCounter++)
				{			
					funclib.DelayTime();
					CompleteSettlement(TestCase);					
				}
			}
		}
		
		
		// Complete - Funding Settlement
		//List<WebElement> CompleteFunding=driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Funding')]")); //Local Host
		List<WebElement> CompleteFunding=driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Funding')]")); //Remote Host
		
		if(!CompleteFunding.isEmpty())
		{			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteFunding.size());
							
			if(CompleteFunding.size() >0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				for(int CompleteCounter=1;CompleteCounter<=CompleteFunding.size();CompleteCounter++)
				{			
					funclib.DelayTime();
					CompleteSettlement(TestCase);					
				}
			}
		}
		
		
		// Complete - Printing of Contracts
		//List<WebElement> CompletePrintContract= driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Printing of Contracts')]")); //Local Host
		List<WebElement> CompletePrintContract= driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Printing of Contracts')]")); //Remote Host
		
		if(!CompletePrintContract.isEmpty())
		{			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompletePrintContract.size());
							
			if(CompletePrintContract.size() >0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				for(int CompleteCounter=1;CompleteCounter<=CompletePrintContract.size();CompleteCounter++)
				{			
					funclib.DelayTime();
					CompleteSettlement(TestCase);					
				}
			}
		}
		
		// Complete - Ready For Settlement
		//List<WebElement> CompleteReadySettlement= driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Ready For Settlement')]")); //Local Host
		List<WebElement> CompleteReadySettlement= driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Ready For Settlement')]")); //Remote Host
		
		if(!CompleteReadySettlement.isEmpty())
		{			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteReadySettlement.size());
							
			if(CompleteReadySettlement.size() >0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				for(int CompleteCounter=1;CompleteCounter<=CompleteReadySettlement.size();CompleteCounter++)
				{			
					funclib.DelayTime();
					CompleteSettlement(TestCase);	
				}
			}
		}
		
		
		//Image - Printing of Contracts
		//List<WebElement> ImageLink=driver.findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Printing of Contracts')]")); //Local Host
		List<WebElement> ImageLink=driver.get().findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Printing of Contracts')]")); //Remote Host
		
		if(!ImageLink.isEmpty())
		{		
			// Count of 'Image' Text
			System.out.println("Image Count: " + ImageLink.size());
			
			if(ImageLink.size()>0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				funclib.DelayTime();
				ImageSettlement(TestCase);
			}			
		}
		
		//Image - Ready For Settlement
		//List<WebElement> ImageSettlement=driver.findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Ready For Settlement')]")); //Local Host
		List<WebElement> ImageSettlement=driver.get().findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Ready For Settlement')]")); //Remote Host
		
		if(!ImageSettlement.isEmpty())
		{		
			// Count of 'Image' Text
			System.out.println("Image Count: " + ImageSettlement.size());
			
			if(ImageSettlement.size()>0)
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				funclib.DelayTime();
				ImageSettlement(TestCase);
			}			
		}
	}

// ******************************************************************************************************************************************************************
	//Submit Settlement - Go To
// ******************************************************************************************************************************************************************
	public void SubmitSettlementGoTo(String InsuranceReq, String InsurancePolicy, String CompanyCode, String PolicyType, String PolicyNumber, String CoverAmount, String ExpiryDate, String NPBSInterest,String TestCase) throws InterruptedException
	{
		String GoToType="Goto";		
		
		String GoToClickResult = funclib.HeadingSection(GotoClick.getText(), "Goto");
		
		//WebDriverWait wait = new WebDriverWait(driver, 25); //Local Host
		//Actions action = new Actions(driver); //Local Host
		
		WebDriverWait wait = new WebDriverWait(driver.get(), 25); //Remote Host
		Actions action = new Actions(driver.get()); //Remote Host
		
		WebElement GoClick = wait.until(ExpectedConditions.elementToBeClickable(GotoClick));
		funclib.DelayTime();
		
		//GoTo Click		
		//java.util.List<WebElement> GoToLink=driver.findElements(By.xpath("//td/a[contains(text(),'Goto')]/../preceding-sibling::td/span[contains(text(),'Documents Returned')]")); //Local Host
		java.util.List<WebElement> GoToLink=driver.get().findElements(By.xpath("//td/a[contains(text(),'Goto')]/../preceding-sibling::td/span[contains(text(),'Documents Returned')]")); //Remote Host
		
		System.out.println("GoTo Count: " + GoToLink.size());
		
		
		for(int GoToCounter=1;GoToCounter<=GoToLink.size();GoToCounter++)
		{			
			
			if (GoToClickResult .equals(GoToType))
			{
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				funclib.DelayTime();
				action.moveToElement(GoClick).doubleClick(GoClick).perform();
				funclib.DelayTime();
				
				// Switch to Frame using id
				//driver.switchTo().frame("gotoIframe"); //Local Host
				driver.get().switchTo().frame("gotoIframe"); //Remote Host
			
				//Property Insurance Required
				funclib.DelayTime();
				
				String InsuranceRequired = InsuranceReq;		
				String InsuranceRequiredResult= funclib.SelOptionValue(RadioInsuranceRequiredYes, RadioInsuranceRequiredYes.getAttribute("value"),RadioInsuranceRequiredNo,RadioInsuranceRequiredNo.getAttribute("value"),InsuranceRequired);
				System.out.println("Insuranced Required:" + InsuranceRequiredResult);
				
				if(InsuranceRequiredResult .equals("true"))
				{
					//Property Insurance Policy Type
					funclib.DelayTime();
					String InsurancePolicyType = InsurancePolicy;		
					String InsurancePolicyTypeResult= funclib.SelOptionValue(RadioInsuranceTypeYes, RadioInsuranceTypeYes.getAttribute("value"),RadioInsuranceTypeNo,RadioInsuranceTypeNo.getAttribute("value"),InsurancePolicyType);
					System.out.println("Insuranced Policy Type:" + InsurancePolicyTypeResult);
				
					//Select Insurance Company Code
					funclib.DelayTime();
					String SelInsuranceCompanyCode = CompanyCode;
					String SelectInsuranceCompanyCodeResult = funclib.DropdownListSelect(SelInsuranceCompanyCode, SelectInsuranceCompanyCode);
					System.out.println("Insuranced Company Code:" + SelectInsuranceCompanyCodeResult);
				
					//Select Policy Type
					funclib.DelayTime();
					String SelPolicyType = PolicyType;
					String SelectPolicyTypeResult = funclib.DropdownListSelect(SelPolicyType, SelectPolicyType);
					System.out.println("Policy Type:" + SelectPolicyTypeResult);				
				
					//Input Policy Number
					funclib.DelayTime();
					InputPolicyNumber.clear();
					funclib.DelayTime();
					InputPolicyNumber.sendKeys(PolicyNumber);
					System.out.println("Policy Number:" + PolicyNumber);
					
					//Input Coverage Amount
					funclib.DelayTime();
					InputCoverageAmount.clear();
					funclib.DelayTime();
					InputCoverageAmount.sendKeys(CoverAmount);
					System.out.println("Coverage Amount:" + CoverAmount);
				
					//Input Expiry Date
					funclib.DelayTime();
					InputExpiryDate.clear();
					funclib.DelayTime();
					InputExpiryDate.sendKeys(ExpiryDate);
					System.out.println("Expiry Date:" + ExpiryDate);
					
					//NPBS as an Interested Party
					funclib.DelayTime();
					String NPBSParty = NPBSInterest;		
					String NPBSInterestResult= funclib.SelOptionValue(RadioNPBSYes, RadioNPBSYes.getAttribute("value"),RadioNPBSNo,RadioNPBSNo.getAttribute("value"),NPBSParty);
					System.out.println("Insuranced Required:" + NPBSInterestResult);
					funclib.DelayTime();
				}
		
				//Capture Screenshot
				funclib.CaptureScreenShot(TestCase);
				
				//Navigate Next Page
				funclib.DelayTime();				
				NextClick.click();
				
				//Switching from IFrame to Normal Window
				//driver.switchTo().defaultContent(); //Local Host
				driver.get().switchTo().defaultContent(); //Remote Host
				
				//Close Popup Button
				funclib.DelayTime();
				funclib.DelayTime();
				PopupCloseButton.click();
			}
			//else
			//	break;
		}
				
				//Image - Printing Of Contracts	
				funclib.DelayTime();
				//List<WebElement> ImagePrintContract=driver.findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Documents Returned')]")); //Local Host
				List<WebElement> ImagePrintContract=driver.get().findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Documents Returned')]")); //Remote Host
				funclib.DelayTime();
		
				if(!ImagePrintContract.isEmpty())
				{		
					// Count of 'Image' Text
					System.out.println("Image Count: " + ImagePrintContract.size());
			
					if(ImagePrintContract.size()>0)
					{
						funclib.DelayTime();
						ImageSettlement(TestCase);
					}		
				}						
	}
	
	// ******************************************************************************************************************************************************************
		//Submit Origination Claim
	// ******************************************************************************************************************************************************************	
		public void NoSubmitOrigination(String TestCase) throws InterruptedException
		{
		//String SubmitPos = "Submission";
			
			String ImageType="Image";		
			String CompleteType="Complete";
			String GoToType = "Goto";
			
			//WebDriverWait wait = new WebDriverWait(driver, 25); //Local Host
			//Actions action = new Actions(driver);	//Local Host
				
			WebDriverWait wait = new WebDriverWait(driver.get(), 25); //Remote Host
			Actions action = new Actions(driver.get()); //Remote Host
			
			
			//Goto Click		
			//List<WebElement> GoToLink = driver.findElements(By.linkText("Goto")); //Local Host
			List<WebElement> GoToLink = driver.get().findElements(By.linkText("Goto")); //Remote Host
					
			if(!GoToLink.isEmpty())
			{
				funclib.DelayTime();
				String GotoClickResult = funclib.HeadingSection(GotoClick.getText(), "Goto");
				WebElement GoClick = wait.until(ExpectedConditions.elementToBeClickable(GotoClick));
				
				// Count of 'Goto' Text
				System.out.println("Goto Count: " + GoToLink.size());
				
				if(GoToLink.size() >0)
				{
					for(int GotoCounter=1;GotoCounter<=GoToLink.size();GotoCounter++)
					{			
					
						if (GotoClickResult .equals(GoToType))
						{
							funclib.DelayTime();
							action.moveToElement(GoClick).doubleClick(GoClick).perform();
							funclib.DelayTime();
							
							// Switch to Frame using id
							//driver.switchTo().frame("gotoIframe"); //Local Host
							driver.get().switchTo().frame("gotoIframe"); //Remote Host
					
							//Request Quote Validation
							//WebElement RequestQuoteLink = driver.findElement(By.xpath("//input[@id ='main:requestQuoteBtn']")); //Local Host
							WebElement RequestQuoteLink = driver.get().findElement(By.xpath("//input[@id ='main:requestQuoteBtn']")); //Remote Host
							RequestQuoteLink.click();
							
							funclib.DelayTime();
							
							//Navigate Next Page
							funclib.DelayTime();
							NextClick.click();
							
							funclib.DelayTime();
				
							//Capture Screenshot
							funclib.CaptureScreenShot(TestCase);
							
							//Switching from IFrame to Normal Window
							//driver.switchTo().defaultContent(); //Local Host
							driver.get().switchTo().defaultContent(); //Remote Host
							
							funclib.DelayTime();
							PopupCloseButton.click();
							funclib.DelayTime();
						
													
						}					
					}
				}
			}
			
			funclib.DelayTime();
			
			//Complete Click
			//List<WebElement> CompleteLink = driver.findElements(By.linkText("Complete")); //Local Host
			List<WebElement> CompleteLink = driver.get().findElements(By.linkText("Complete")); //Remote Host
					
			if(!CompleteLink.isEmpty())
			{
				funclib.DelayTime();
				String CompleteClickResult = funclib.HeadingSection(CompleteClick.getText(), "Complete");
				WebElement CompClick = wait.until(ExpectedConditions.elementToBeClickable(CompleteClick));
				
				// Count of 'Complete' Text
				System.out.println("Complete Count: " + CompleteLink.size());
				
				// Refreshing URL Browser				
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				if(CompleteLink.size() >0)
				{
					for(int CompleteCounter=1;CompleteCounter<=CompleteLink.size();CompleteCounter++)
					{			
					
						if (CompleteClickResult .equals(CompleteType))
						{
							funclib.DelayTime();
							action.moveToElement(CompClick).doubleClick(CompClick).perform();
							funclib.DelayTime();
					
							//Input Applicant Insurance Verification
							InputApplicantInsuranceVerify.clear();
							funclib.DelayTime();
							InputApplicantInsuranceVerify.sendKeys("Verified Successfully");
							funclib.DelayTime();
				
							//Capture Screenshot
							funclib.CaptureScreenShot(TestCase);
						
							//Navigate Next Page
							funclib.DelayTime();
							NextClick.click();
							funclib.DelayTime();
						}					
					}
				}
			}
			
			funclib.DelayTime();
			for(int ImageCount=1;ImageCount<=3;ImageCount++)
			{
				//Image Click	
				//List<WebElement> ImageLink = driver.findElements(By.xpath("//*[contains(text(),'Image')]")); //Local Host
				List<WebElement> ImageLink = driver.get().findElements(By.xpath("//*[contains(text(),'Image')]")); //Remote Host
			
				if(!ImageLink.isEmpty())
				{
					String ImageClickResult = funclib.HeadingSection(ImageClick.getText(), "Image");
					WebElement ImgClick = wait.until(ExpectedConditions.elementToBeClickable(ImageClick));
					
					// Count of 'Image' Text	
					System.out.println("Image Count: " + ImageLink.size());
					
					// Refreshing URL Browser				
					//driver.navigate().refresh(); //Local Host
					driver.get().navigate().refresh(); //Remote Host
					
					if(ImageLink.size()>0)
					{				
						if (ImageClickResult .equals(ImageType))
						{
							funclib.DelayTime();
							action.moveToElement(ImgClick).doubleClick(ImgClick).perform();				
						
							//Click on Add Document Link
							funclib.DelayTime();
							AddDocClick.click();
							funclib.DelayTime();				
						 
							//Clicking on Select Link
							funclib.DelayTime();
							SelectLinkClick.click();
							funclib.DelayTime();
							
							//Click on Status Link
							if(ImageCount >1)
							{
								StatusLink.click();
								funclib.DelayTime();
							}
						
							//Checking all Checkboxes
							String CheckboxPath = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//input";
							String Summary = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[2]";
							String StatusCheck = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[3]//span";
							
							//List<WebElement> checkBoxes = driver.findElements(By.xpath(CheckboxPath)); //Local Host
							//List<WebElement> SummaryChecks = driver.findElements(By.xpath(Summary)); //Local Host
							//List<WebElement> StatusChecks = driver.findElements(By.xpath(StatusCheck)); //Local Host
							
							List<WebElement> checkBoxes = driver.get().findElements(By.xpath(CheckboxPath)); //Remote Host
							List<WebElement> SummaryChecks = driver.get().findElements(By.xpath(Summary)); //Remote Host
							List<WebElement> StatusChecks = driver.get().findElements(By.xpath(StatusCheck)); //Remote Host
							
							String OutStandingValue="Outstanding";				
							
							//CheckMark each
							System.out.println("Status Check Count:" + StatusChecks.size());
							for(int i=0;i<StatusChecks.size();i++)
							{					
								if(StatusChecks.get(i).getText() .equals(OutStandingValue))
								{
									System.out.println("Status:" + StatusChecks.get(i).getText());
									if(!checkBoxes.get(i).isSelected())
										checkBoxes.get(i).click();
									funclib.DelayTime();
								}
								else
								{
									System.out.println("Summary Check:" + SummaryChecks.get(i).getText());
									System.out.println("Status:" + StatusChecks.get(i).getText());
									System.out.println("Loop Counter: " +i);
								}
							}		     
							
							//Click on OK Button
							System.out.println("Status Check Count:" + StatusChecks.size());
							funclib.DelayTime();
							SelectOkClick.click();
							funclib.DelayTime();
							
							//Checking all Reference Textboxes
							String TextboxPath = "//tbody[contains(@id,'main:docRelatedTo:docRelatedTo:tb')]//input";
							//List<WebElement> TextBoxes = driver.findElements(By.xpath(TextboxPath)); //Local Host
							List<WebElement> TextBoxes = driver.get().findElements(By.xpath(TextboxPath)); //Remote Host
							for(WebElement textbox: TextBoxes)
							{				        
								funclib.DelayTime();
								if(!textbox.isSelected())				    	
									textbox.sendKeys("Verified");				    				    	
							}
												
							//Checkbox on Verified Documents
							funclib.DelayTime();
							CheckboxVerify.click();
						 
							//Select Predominant Purpose
							funclib.DelayTime();
							String SelectIdentity= "Identification";
							funclib.DropdownListSelect(SelectIdentity, SelectIdentityType);
							
							funclib.DelayTime();
							//JavascriptExecutor js = (JavascriptExecutor) driver.get();
							
							//This will scroll the web page till end.		
					        //js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
							
							//Select Submission Process
							funclib.DelayTime();
							String SelectSubmission= "Upload";
							funclib.DropdownListSelect(SelectSubmission, SelectSubmissionType);
							funclib.DelayTime();
							
							//Upload File
							String LendFastPath = System.getProperty("user.dir");
							funclib.DelayTime();					
							//UploadFile.sendKeys(LendFastPath + "//Sample.pdf");
							UploadFile.sendKeys("//automatedtesting//Results//lendfast//Sample.pdf");
							funclib.DelayTime();
							funclib.DelayTime();
							funclib.DelayTime();
							
							//Capture Screenshot
							funclib.CaptureScreenShot(TestCase);
							
							//Navigate Next Page
							funclib.DelayTime();
							NextClick.click();
							
							//Select Verification Status
							funclib.DelayTime();
							String SelectDocumentationVerify= "Verified";
							funclib.DropdownListSelect(SelectDocumentationVerify,SelectDocumentVerify);
							funclib.DelayTime();
						
							//Capture Screenshot
							funclib.CaptureScreenShot(TestCase);
								
							//Navigate Next Page
							funclib.DelayTime();
							NextClick.click();
							
							//Capture Screenshot
							funclib.CaptureScreenShot(TestCase);
							funclib.DelayTime();
						}				
					}			
				}
			}		
			
			//Navigating to Submit Page
			
			//Capture Screenshot
			funclib.CaptureScreenShot(TestCase);
					
			//Navigate Next Page
			funclib.DelayTime();
			NextClick.click();
			
			//Input Additional Information/Submission Comments
			//funclib.DelayTime();
			//InputAdditionalInfo.sendKeys("Submit Successfully");
			funclib.DelayTime();
			
			//Save Additional Information/Submission Comments
			//SaveAdditionalInfoClick.click();		
			//Thread.sleep(10000);			
		}
}