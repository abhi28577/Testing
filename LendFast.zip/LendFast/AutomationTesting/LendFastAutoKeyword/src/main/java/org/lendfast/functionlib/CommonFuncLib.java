package org.lendfast.functionlib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import org.lendfast.base.ParentPage;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.support.ui.Select;

public class CommonFuncLib extends ParentPage 
{
// *************************************************************************************************************	
	//Capturing Head Section
// *************************************************************************************************************	
	public String HeadingSection(String HeadingLocator, String HeadingValue)
	{
		//Initialize Heading Section Text
		String SectionId = HeadingLocator;
			
		//Extract Desired Text
		String SectionDesiredVal = HeadingValue;			
					
		//Extract String Before Desired Substring 
		String SectionBeforeDesiredVal =  SectionId.substring(0, SectionId.indexOf(SectionDesiredVal));
					
		//Extract String After Desired Substring
		String SectionAfterDesiredVal = SectionId.substring(SectionId.indexOf(SectionDesiredVal) + SectionDesiredVal.length());
					
		//Initialize Before Substring to NULL
		if(SectionBeforeDesiredVal.length()>0)
			SectionBeforeDesiredVal="";
				
		//Initialize After Substring to NULL
		if(SectionAfterDesiredVal.length()>0)
			SectionAfterDesiredVal="";
					
		//Final String after Initializing Before and After Substring
		SectionId = SectionBeforeDesiredVal + SectionDesiredVal + SectionAfterDesiredVal;
			
		return SectionId;			
	}

// *************************************************************************************************************
	
// *************************************************************************************************************
	// Radio Options
// *************************************************************************************************************
	public String SelOptionValue(WebElement RadioLocatorTrue,String RadioLocatorTrueValue,WebElement RadioLocatorFalse,String RadioLocatorFalseValue, String OptionVal) throws InterruptedException
	{		
		String OptionValue = OptionVal;
		String OptionResult = null;
				
		//String RetType1 = "TRUE";
		String RetType1 = RadioLocatorTrueValue;
		//String RetType2 = "FALSE";
		String RetType2 = RadioLocatorFalseValue;
		
		Thread.sleep(2000);
		
		if(OptionValue.toLowerCase().equals(RetType1.toLowerCase()))
		{			
			RadioLocatorTrue.click();			
			OptionResult= RadioLocatorTrueValue;			
		}
		
		if(OptionValue.toLowerCase().equals(RetType2.toLowerCase()))
		{
			RadioLocatorFalse.click();
			OptionResult= RadioLocatorFalseValue;			
		}		
		
		return OptionResult;	
	}


	
// *************************************************************************************************************
	
// *************************************************************************************************************
	// Radio Options - Keyword-Driven Approach
// *************************************************************************************************************
		public String SelOptionValueKeyword(WebElement RadioLocator,String RadioLocatorValue, String OptionVal) throws InterruptedException
		{		
			String OptionValue = OptionVal;
			String OptionResult = null;		
			
			Thread.sleep(2000);
			
			if(OptionValue.toLowerCase().equals(RadioLocatorValue.toLowerCase()))
			{			
				RadioLocator.click();			
				OptionResult= RadioLocatorValue;			
			}			
			
			return OptionResult;	
		}	
	
	
	
// *************************************************************************************************************

// *************************************************************************************************************
	// Drop-Down List
// *************************************************************************************************************
	public String DropdownListSelect(String SelValue, WebElement SelectLocator)
	{
		String SelectionType = SelValue;
		String SelectionValue = null;
		//Actions action = new Actions(driver); //Local Host
		Actions action = new Actions(driver.get()); //Remote Host
						
		try 
		{
			Select SelectOptions = new Select(SelectLocator);				
			List<WebElement> SelValueText = SelectOptions.getOptions();
			Thread.sleep(2000);
			SelectLocator.click();
			Thread.sleep(1000);
			action.sendKeys(Keys.HOME).build().perform();
			Thread.sleep(1000);
			
			for(WebElement SelListValue : SelValueText)
			{
				SelectionValue = SelListValue.getText();
				Thread.sleep(100);
				if(SelectionValue .equals(SelectionType))
				{					
					SelectOptions.selectByVisibleText(SelectionValue);
					//SelectAppType.isSelected();					
					action.sendKeys(Keys.ENTER).build().perform();
					Thread.sleep(100);
					break;
				}
				else
				{
					// Keep Navigating Key-Down to Select Option List unless Desired Option Value found					
					
					action.sendKeys(Keys.ARROW_DOWN).build().perform();
					Thread.sleep(100);
					//SelectAppType.click();
					//SelectAppOptions.selectByVisibleText(AppTypeValue);
				}
				//System.out.println(value);
			}
		}
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//SelectLocator.click();
		return SelectionValue;
	}



//*************************************************************************************************************

//*************************************************************************************************************
	// Take Screenshot
//*************************************************************************************************************

	public void CaptureScreenShot(String TestCase)
	{
		String LendFastPath = System.getProperty("user.dir");
		
		// Take screenshot and store as a file format             
		//File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE); //Local Host 
		File src=((TakesScreenshot)driver.get()).getScreenshotAs(OutputType.FILE); //Remote Host
		try 
		{
			// now copy the  screenshot to desired location using copyFile method			
			//FileUtils.copyFile(src, new File(LendFastPath + "//Screenshot//" + TestCase + "//" +System.currentTimeMillis()+".png")); //Local Host                            
			FileUtils.copyFile(src, new File("//automatedtesting//Results//screenshot//" + TestCase + "//" +System.currentTimeMillis()+".png")); //Remote Host
		} 
		catch (IOException e)
	 	{
			System.out.println(e.getMessage());
		}
		
//		System.out.println("Screenshot Captured");
	}
	
//*************************************************************************************************************

//*************************************************************************************************************
	// Enter Addresses Manually
//*************************************************************************************************************
	public void ManualAddressDetails(String AustralianAddress, WebElement RadioStrAusAddressLocatorYes, WebElement RadioStrAusAddressLocatorNo, String PropertyName, WebElement InputPropertyName,String Unit, WebElement InputPropertyUnit,String Level, WebElement InputPropertyLevel, String HouseNum, WebElement InputHouseNum,String StreetName, WebElement InputStreetName,String StreetType,WebElement SelectStreetType, String StreetSuffix, WebElement SelectStreetSuffix,String Suburb, WebElement InputSuburb,String State, WebElement SelectState,String PostalCode, WebElement InputPostalCode) throws InterruptedException
	{  
		//Select Australian Address
		String OptionValue = AustralianAddress;		
		SelOptionValue(RadioStrAusAddressLocatorYes, RadioStrAusAddressLocatorYes.getAttribute("value"),RadioStrAusAddressLocatorNo,RadioStrAusAddressLocatorNo.getAttribute("value"),OptionValue);
		
		Thread.sleep(2000);
		//Input Property Name
		InputPropertyName.sendKeys(PropertyName);
		
		Thread.sleep(2000);
		//Input Unit/Flat
		InputPropertyUnit.sendKeys(Unit);
		
		Thread.sleep(2000);
		//Input Level
		InputPropertyLevel.sendKeys(Level);		
		
		Thread.sleep(2000);
		//Input House Number
		InputHouseNum.sendKeys(HouseNum);
		
		Thread.sleep(2000);
		//Input Street Name
		InputStreetName.sendKeys(StreetName);
		
		Thread.sleep(2000);
		//Select Street Type
		String StrType = StreetType;
		if(StrType != "")
			DropdownListSelect(StrType, SelectStreetType);
		
		Thread.sleep(2000);
		//Select Street Suffix
		String StrSuffix = StreetSuffix;
		if(StrSuffix != "")
			DropdownListSelect(StrSuffix, SelectStreetSuffix);
		
		Thread.sleep(2000);
		//Suburb
		InputSuburb.sendKeys(Suburb);
		
		Thread.sleep(2000);
		//Select State
		String StrState = State;
		if(StrState != "")
			DropdownListSelect(StrState, SelectState);		
		
		Thread.sleep(2000);
		//Input Postal Code
		InputPostalCode.sendKeys(PostalCode);
	}
	
//*************************************************************************************************************
//*************************************************************************************************************
	// Write Result to Excel File
//*************************************************************************************************************
	
	public boolean SetCellData(String SheetName, String Path, String ColName, int RowNum, String Value)
	{
		//String Path="C:\\Users\\abhishek.paspuleti\\eclipse-workspace\\LendFastAutopack\\src\\main\\java\\org\\lendfast\\testdata\\lendfast_testdata.xlsx";
		//String Path="C:\\Users\\abhishek.paspuleti\\eclipse-workspace\\LendFast\\AutomationTesting\\LendFastAutoKeyword\\src\\test\\java\\org\\lendfast\\Test001\\keywordtest.xlsx";
		
		FileInputStream InputFile = null;
		try {
			InputFile = new FileInputStream(Path);
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		FileOutputStream OutputFile=null;
		XSSFWorkbook workbook = null;
		try {
			workbook = new XSSFWorkbook(InputFile);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		XSSFRow row=null;
		XSSFCell cell=null;
		XSSFSheet WorkSheet;
		
		int ColNum=-1;
		WorkSheet= workbook.getSheet(SheetName);
		
		row= WorkSheet.getRow(0);
		for(int i=0;i<row.getLastCellNum();i++)
		{
			if(row.getCell(i).getStringCellValue().trim().equals(ColName))
			{
				ColNum=i;
			}	
			
		}
		row=WorkSheet.getRow(RowNum-1);
		if(row==null)
			row=WorkSheet.createRow(RowNum-1);
		
		cell=row.getCell(ColNum);
		
		if(cell== null)	
			cell = row.createCell(ColNum);
		
		cell.setCellValue(Value);
		
		
		try {
			OutputFile=new FileOutputStream(Path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			workbook.write(OutputFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			OutputFile.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return true;
	}

// *************************************************************************************************************

// *************************************************************************************************************
		// Drop-Down List - Specific Scenarios
// *************************************************************************************************************
		public String DropdownListSelectSpecific(String SelValue, WebElement SelectLocator)
		{
			String SelectionType = SelValue;
			String SelectionValue = null;
			//Actions action = new Actions(driver); //Local Host
			Actions action = new Actions(driver.get()); //Remote Host
							
			try 
			{
				Select SelectOptions = new Select(SelectLocator);				
				List<WebElement> SelValueText = SelectOptions.getOptions();
				Thread.sleep(2000);
				SelectLocator.click();
				Thread.sleep(2000);
				action.sendKeys(Keys.HOME).build().perform();
				Thread.sleep(2000);
				
				for(WebElement SelListValue : SelValueText)
				{
					SelectionValue = SelListValue.getText();
					if(SelectionValue .equals(SelectionType))
					{
						Thread.sleep(100);
						SelectOptions.selectByVisibleText(SelectionValue);
						//SelectAppType.isSelected();						
						action.sendKeys(Keys.ARROW_UP).build().perform();
						Thread.sleep(2000);
						action.sendKeys(Keys.ENTER).build().perform();
						Thread.sleep(2000);
						action.sendKeys(Keys.TAB).build().perform();
						Thread.sleep(2000);
						break;
					}
					else
					{
						// Keep Navigating Key-Down to Select Option List unless Desired Option Value found
						
						action.sendKeys(Keys.ARROW_DOWN).build().perform();
						Thread.sleep(300);
						//SelectAppType.click();
						//SelectAppOptions.selectByVisibleText(AppTypeValue);
					}
					//System.out.println(value);
				}
			}
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//SelectLocator.click();
			return SelectionValue;
		}


		
// *************************************************************************************************************

// *************************************************************************************************************
// Delay Time
// *************************************************************************************************************
		public void DelayTime() throws InterruptedException
		{
			//Delay Time by 6.5 Seconds
			Thread.sleep(6500);
		}
		

//*************************************************************************************************************
		

// *************************************************************************************************************

// *************************************************************************************************************
// Get Current Day
// *************************************************************************************************************
		public String getCurrentDay() throws InterruptedException
		{
			//Create a Calendar Object
	        Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
	 
	        //Get Current Day as a number
	        int todayInt = calendar.get(Calendar.DAY_OF_MONTH);
	        System.out.println("Today Int: " + todayInt +"\n");
	 
	        //Integer to String Conversion
	        String todayStr = Integer.toString(todayInt);
	        System.out.println("Today Str: " + todayStr + "\n");
	 
	        return todayStr;
		}				

//*************************************************************************************************************

	
}