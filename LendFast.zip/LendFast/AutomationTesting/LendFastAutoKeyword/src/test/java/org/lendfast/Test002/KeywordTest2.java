package org.lendfast.Test002;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.Checklist;
import org.lendfast.functionlib.CommonFuncLib;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.lendfast.utils.KeywordTestData1;
import org.lendfast.utils.KeywordTestData2;
import org.lendfast.utils.PageWaitUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


// URL List
/*
url1=http://lfe-npbs-689057271.ap-southeast-2.elb.amazonaws.com/lendfast/internaljsp/logon.jsp
url=https://pfxloanapplication.ad.newcastlepermanent.com.au
url2=https://uatloanapplication.ad.newcastlepermanent.com.au
*/

public class KeywordTest2 extends ParentPage 
{
	String SheetName = "keywords";
	
	// Application Id
	int rownumber=0, SubResult=0;
	String AppIdNumber="";
	String Add1AppIdNumber="";
	String CapturedTextValue="";
	String Path="";	
	String TestDataSplit[];
	String LocatorSplit[], today;
	
	String LendFastPath = System.getProperty("user.dir");
	
	CommonFuncLib funclib;
	Checklist submitclaim;
	
	@BeforeTest
	public void BrowserInitialize() throws MalformedURLException
	{
		//initialization(); //Local Host
		GridBrowserSetUp(); //Remote Host
	}
	
	@BeforeMethod
	public void SetUp()
	{			
		funclib=new CommonFuncLib();
		submitclaim = new Checklist();
	}	
	
	@DataProvider
	public Object[][] Mortgage()
	{
		Object keyword_data[][] = KeywordTestData2.getTestData(SheetName);
		return keyword_data;
	}
	
	@Test (dataProvider = "Mortgage") 
	public void Validate_Mortgage(String MenuList, String ScriptName, String Functionality, String KeywordType, String LocatorName, String TestData, String TestCase) throws InterruptedException, IOException
	{		
		rownumber = rownumber+1;	
		
		switch (KeywordType)
		{
		
			case "CaptureScreenshot":	
			
				// Capturing Screenshot
				funclib.CaptureScreenShot(TestCase);			
			
				break;
				
			case "Delay":
				
				// Delay Time
				funclib.DelayTime();
				
				break;
			
			case "Next":
				
				//Define Next Screen			
				//WebElement Next = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement Next = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				Next.click();				
				
				break;
			
			case "InputText":				
				
				//Define WebElement
				//WebElement InputString = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement InputString = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
				
				if(TestData .equals("-"))
				{
					//Input Text
					InputString.clear();
					funclib.DelayTime();					
					InputString.sendKeys(CapturedTextValue);
					funclib.DelayTime();
					
					//Print Input Text
					System.out.println(Functionality + " : " + CapturedTextValue);
				}
				else
				{
					//Input Text				
					InputString.clear();
					funclib.DelayTime();				
					InputString.sendKeys(TestData);
					funclib.DelayTime();
				
				//Print Input Text
				System.out.println(Functionality + " : " + TestData);
				}		
				
				
				break;
			
			case "InputManualAddress":
				
				//Define WebElement
				//WebElement InputManualString = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement InputManualString = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
				//WebDriverWait wait = new WebDriverWait(driver, 25);
				//Actions action = new Actions(driver);	//Local Host
				
				//WebDriverWait wait = new WebDriverWait(driver.get(), 25);
				Actions action = new Actions(driver.get()); //Remote Host
				
				InputManualString.clear();
				funclib.DelayTime();				
				InputManualString.sendKeys(TestData);
				funclib.DelayTime();
				
				action.sendKeys(Keys.ARROW_DOWN).build().perform();
				Thread.sleep(4000);
				action.sendKeys(Keys.ENTER).build().perform();
				funclib.DelayTime();
			
				break;	
				
			case "ClickLink":						
				
				//Define WebElement
				//WebElement ClickButton = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement ClickButton = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
							
				//Click on Link
				ClickButton.click();				
				
				funclib.DelayTime();
				
				//Print
				System.out.println("Link Button: " + Functionality);
				
				break;
				
			case "DoubleClickLink":	
				
				//WebDriverWait wait = new WebDriverWait(driver, 25); //Local Host
				//Actions DoubleClickAction = new Actions(driver); //Local Host
				
				WebDriverWait wait = new WebDriverWait(driver.get(), 25); //Remote Host
				Actions DoubleClickAction = new Actions(driver.get()); //Remote Host				
				
				//Count of Links
				//List<WebElement> ClickLinkCount = driver.findElements(By.xpath(LocatorName)); //Local Host
				List<WebElement> ClickLinkCount = driver.get().findElements(By.xpath(LocatorName)); //Remote Host
				
				//Print
				System.out.println("Click Count Size: " + ClickLinkCount.size());
				
				if(!ClickLinkCount.isEmpty())
				{
					funclib.DelayTime();
					////WebElement CompleteClick = driver.findElement(By.linkText("Complete"));
					//WebElement CompleteClick = driver.findElement(By.xpath(LocatorName)); //Local Host
					WebElement CompleteClick = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
					
					WebElement CompClick = wait.until(ExpectedConditions.elementToBeClickable(CompleteClick));
									
					if(ClickLinkCount.size() >0)
					{
						funclib.DelayTime();
						DoubleClickAction.moveToElement(CompClick).doubleClick(CompClick).perform();
						funclib.DelayTime();
					}
				}		
				
				//Print
				System.out.println("Link Button: " + Functionality);
				
				break;
				
			
			case "DisplayTitle":
				
				//Display Title
				//String HeadTitle=driver.getTitle();
				String HeadTitle=driver.get().getTitle();
				System.out.println("Page Title: " + HeadTitle);
				Assert.assertEquals(HeadTitle, "LendFast");
				
				break;
			
			case "ClickLinkText":
				
				//Define WebElement
				//WebElement ClickLinkText = driver.findElement(By.linkText(TestData)); //Local Host
				WebElement ClickLinkText = driver.get().findElement(By.linkText(TestData)); //Remote Host
				
				//Click on Link Text
				ClickLinkText.click();
				
				funclib.DelayTime();
				
				//Print
				System.out.println("Link Text: " + Functionality);
				
				break;
			
			case "ReturnWorkList":
				//Click on Return to Worklist	
				//WebElement WorkList = driver.findElement(By.linkText("Return to Work List")); //Local Host		
				WebElement WorkList = driver.get().findElement(By.linkText("Return to Work List")); //Remote Host
				
				String WorkListVar = "Return to Work List";
				
				//int WorkListCount = driver.findElements(By.linkText("Return to Work List")).size(); //Local Host
				int WorkListCount = driver.get().findElements(By.linkText("Return to Work List")).size(); //Remote Host
				
				if(WorkListCount> 0)
				{
					if(WorkList.getText() .equals(WorkListVar))
					{
						if(WorkList.isDisplayed())
						{
							funclib.DelayTime();
							WorkList.click();
						}
					}
				}
			
				
				break;
			
			case "HeadSection":
				
				//Define WebElement
				//WebElement HeadingSection = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement HeadingSection = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
				//Head Section Result
				String HeadSectionResult = funclib.HeadingSection(HeadingSection.getText(), TestData);
				
				//Print Heading
				System.out.println("Section Heading/Extracted Information: " + HeadSectionResult);
				Assert.assertEquals(HeadSectionResult, TestData);
				
				break;
			
			case "CheckProductSelection":
				
				for(int CheckProductCounter=1; CheckProductCounter<=30;CheckProductCounter++)
				{			
					//Define WebElement
					//WebElement CheckProductSelection = driver.findElement(By.xpath(LocatorName)); //Local Host
					WebElement CheckProductSelection = driver.get().findElement(By.xpath(LocatorName));	//Remote Host		
				
					//Check DropDown
					if(CheckProductSelection.isEnabled())						
						break;
					else
						funclib.DelayTime();					
				}
				break;
			
			case "CheckHeadSection":
				
				for(int CheckHeadCounter=1; CheckHeadCounter<=30;CheckHeadCounter++)
				{			
					//Define WebElement
					//WebElement CheckHeadingSection = driver.findElement(By.xpath(LocatorName)); //Local Host
					WebElement CheckHeadingSection = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
					//Head Section Result
					String CheckHeadSectionResult = funclib.HeadingSection(CheckHeadingSection.getText(), TestData);
				
					//Print Heading
					if(CheckHeadSectionResult .equals(TestData))						
						funclib.DelayTime();
					else
						break;					
				}
				
				
				break;
			
			case "QueryCheck":
				
				String QueryPersonal ="Personal"; 
				String QuerySettlement ="Settlement";				
				String QueryMortgageLoan ="Mortgage Loan";
				String QueryCheckList ="Check List";
				String QueryAction ="Action";			
				
				//Define WebElement
				//WebElement QueryCheck = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement QueryCheck = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
				//Query Check Result
				String QueryCheckResult = funclib.HeadingSection(QueryCheck.getText(), TestData);			
				
				if((QueryCheckResult .equals (TestData)) && (MenuList .equals (QueryPersonal)) )
				{
					funclib.DelayTime();					
					funclib.CaptureScreenShot(TestCase);					
					//WebElement MoveNext = driver.findElement(By.xpath("//input[@id='main:next']")); //Local Host
					WebElement MoveNext = driver.get().findElement(By.xpath("//input[@id='main:next']")); //Remote Host
					MoveNext.click();
					funclib.DelayTime();
					System.out.println("Section Heading:" + TestData);
					funclib.DelayTime();					
				}
				
				//Credit Analysis
				if((QueryCheckResult .equals (TestData) && MenuList .equals(QueryMortgageLoan)) || (QueryCheckResult .equals (TestData) && MenuList .equals(QueryCheckList)) || (QueryCheckResult .equals (TestData) && MenuList .equals(QueryAction)))
				{
					funclib.DelayTime();
					//driver.navigate().refresh();
					//driver.get().navigate().refresh();
					funclib.DelayTime();					
					
					//WebElement MoveNext = driver.findElement(By.xpath("//input[@id='main:next']"));
					//MoveNext.click();					
				}
				
				if((QueryCheckResult .equals (TestData)) && (MenuList .equals(QuerySettlement)) )
				{					
					//WebElement SelectSettlementStatus = driver.findElement(By.xpath("//select[@id='main:SettlementStatus:SettlementStatus']")); //Local Host
					WebElement SelectSettlementStatus = driver.get().findElement(By.xpath("//select[@id='main:SettlementStatus:SettlementStatus']")); //Remote Host
					//WebElement InputPlace = driver.findElement(By.xpath("//input[@id='main:placeOfSettlement:placeOfSettlement']")); //Local Host
					WebElement InputPlace = driver.get().findElement(By.xpath("//input[@id='main:placeOfSettlement:placeOfSettlement']")); //Remote Host
					//WebElement SelectLenderType = driver.findElement(By.xpath("//select[@id='main:agentTypeChoice:agentTypeChoice']")); //Local Host
					WebElement SelectLenderType = driver.get().findElement(By.xpath("//select[@id='main:agentTypeChoice:agentTypeChoice']")); //Remote Host
					
					funclib.DelayTime();
					
					// Settlement Status
					funclib.DelayTime();
					funclib.DropdownListSelect("Booked", SelectSettlementStatus);
					funclib.DelayTime();
					
					// Place
					InputPlace.clear();
					funclib.DelayTime();
					InputPlace.sendKeys("NewCastle");
					funclib.DelayTime();
					
					//Lender Representation Type
					funclib.DelayTime();
					funclib.DropdownListSelect("NPBS Staff", SelectLenderType);
					funclib.DelayTime();
					
					//WebElement MoveNext = driver.findElement(By.xpath("//input[@id='main:next']")); //Local Host
					WebElement MoveNext = driver.get().findElement(By.xpath("//input[@id='main:next']")); //Remote Host
					MoveNext.click();
					funclib.DelayTime();					
				}
					
				
				break;
			
			case "LaunchSynchronous":
				
				//Launch Synchronous Decision Engine
				//WebElement MessageCheck = driver.findElement(By.xpath("//td[@id='main:taskList:0:j_id1910']")); //Local Host
				WebElement MessageCheck = driver.get().findElement(By.xpath("//td[@id='main:taskList:0:j_id1910']")); //Remote Host
				
				System.out.println(MessageCheck.getText());
				
				if(!(MessageCheck.getText() .equals(TestData)))
				{
					//WebElement SynchronousLogOutClick = driver.findElement(By.linkText("Logout")); //Local Host
					WebElement SynchronousLogOutClick = driver.get().findElement(By.linkText("Logout")); //Remote Host
					SynchronousLogOutClick.click();
					funclib.DelayTime();
					funclib.DelayTime();
				}
				else
				{
					//WebElement MessageElement = driver.findElement(By.xpath("//td[contains(text(),'Launch Synchronous Decision Engine')]")); //Local Host
					WebElement MessageElement = driver.get().findElement(By.xpath("//td[contains(text(),'Launch Synchronous Decision Engine')]")); //Remote Host
					
					if(MessageElement.getText() .equals(TestData))
					{
						funclib.DelayTime();
						funclib.DelayTime();
							
						//WebElement AdminLink = driver.findElement(By.linkText("Admin")); //Local Host
						WebElement AdminLink = driver.get().findElement(By.linkText("Admin")); //Remote Host
						AdminLink.click();
							
						funclib.DelayTime();
						funclib.DelayTime();
							
						//WebElement AppMaintenanceLink = driver.findElement(By.xpath("//a[@id='main:j_id643:applicationMaintenanceTogglePanelClose']")); //Local Host
						WebElement AppMaintenanceLink = driver.get().findElement(By.xpath("//a[@id='main:j_id643:applicationMaintenanceTogglePanelClose']")); //Remote Host
						AppMaintenanceLink.click();
						funclib.DelayTime();
							
						//Initialize Meta Data for Application
						//WebElement MetaDataText = driver.findElement(By.xpath("//input[@name='main:j_id643:j_id695:j_id741']")); //Local Host
						WebElement MetaDataText = driver.get().findElement(By.xpath("//input[@name='main:j_id643:j_id695:j_id741']")); //Remote Host
						MetaDataText.sendKeys(AppIdNumber);
						//MetaDataText.sendKeys("001023417");
						funclib.DelayTime();
						funclib.DelayTime();
							
						//Submit Meta Data Text
						//WebElement MetaDataSubmit = driver.findElement(By.xpath("//input[@name='main:j_id643:j_id752']")); //Local Host
						WebElement MetaDataSubmit = driver.get().findElement(By.xpath("//input[@name='main:j_id643:j_id752']")); //Remote Host
						MetaDataSubmit.click();
						funclib.DelayTime();
						funclib.DelayTime();
							
						//Regenerate WorkList Entry
						//WebElement WorkListText = driver.findElement(By.xpath("//input[@name='main:j_id643:j_id1168:j_id1214:j_id1260']")); //Local Host
						WebElement WorkListText = driver.get().findElement(By.xpath("//input[@name='main:j_id643:j_id1168:j_id1214:j_id1260']")); //Remote Host
						WorkListText.sendKeys(AppIdNumber);
						//WorkListText.sendKeys("001023417");
						funclib.DelayTime();
						funclib.DelayTime();
							
						//Submit WorkList Entry
						//WebElement WorkListSubmit = driver.findElement(By.xpath("//input[@name='main:j_id643:j_id1168:j_id1271']")); //Local Host
						WebElement WorkListSubmit = driver.get().findElement(By.xpath("//input[@name='main:j_id643:j_id1168:j_id1271']")); //Remote Host
						WorkListSubmit.click();
						funclib.DelayTime();
						funclib.DelayTime();
							
						//Refresh Cached Application
						//WebElement RefreshCacheText = driver.findElement(By.xpath("//input[@name='main:j_id643:j_id1050:j_id1096:j_id1142']")); //Local Host
						WebElement RefreshCacheText = driver.get().findElement(By.xpath("//input[@name='main:j_id643:j_id1050:j_id1096:j_id1142']")); //Remote Host
						RefreshCacheText.sendKeys(AppIdNumber);
						//RefreshCacheText.sendKeys("001023417");
						funclib.DelayTime();
						funclib.DelayTime();
							
						//Submit Refreshed Cached Application						
						//WebElement RefreshCacheSubmit = driver.findElement(By.xpath("//input[@name='main:j_id643:j_id1050:j_id1153']")); //Local Host
						WebElement RefreshCacheSubmit = driver.get().findElement(By.xpath("//input[@name='main:j_id643:j_id1050:j_id1153']")); //Remote Host
						RefreshCacheSubmit.click();
						funclib.DelayTime();
						funclib.DelayTime();
						
						//WebElement SynchronousLogOutClick = driver.findElement(By.linkText("Logout")); //Local Host
						WebElement SynchronousLogOutClick = driver.get().findElement(By.linkText("Logout")); //Remote Host
						SynchronousLogOutClick.click();
						funclib.DelayTime();
						funclib.DelayTime();						
					}					
				}
								
				break;
			
			case "ApplicationId":
				
				//Define WebElement
				//WebElement AppId = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement AppId = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
				String AppIdText = AppId.getText();				
				funclib.DelayTime();
				String AppIdResult = AppIdText.replaceAll("\\D","");
				System.out.println("Application Id:" + AppIdResult);
				
				//Update Application Id in Excel Sheet				
				Path = LendFastPath + "//src//test//java//org//lendfast//Test002//keywordtest.xlsx";
				
				File myFile = new File(Path);
				
				FileInputStream fis = new FileInputStream(myFile);
				XSSFWorkbook myWorkBook = new XSSFWorkbook(fis);
				XSSFSheet mySheet = myWorkBook.getSheet("keywords");
				XSSFRow row = null;
				
				// Making the object of excel row
				row = mySheet.getRow(0);	
								
				//int rowCount = mySheet.getLastRowNum() + 1;
				int rowCount = rownumber +1;
				
				System.out.println("Row Count :- " + rowCount);
				
				AppIdNumber = AppIdResult;		
				

				funclib.SetCellData(SheetName,Path,"TestData", rowCount, AppIdResult);
				
				break;		
			
			case "Add1ApplicationId":
				
				//Define WebElement
				//WebElement Add1AppId = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement Add1AppId = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
				String Add1AppIdText = Add1AppId.getText();				
				funclib.DelayTime();
				String Add1AppIdResult = Add1AppIdText.replaceAll("\\D","");
				System.out.println("Application Id:" + Add1AppIdResult);
				
				//Update Application Id in Excel Sheet				
				Path = LendFastPath + "//src//test//java//org//lendfast//Test002//keywordtest.xlsx";
				
				File Add1myFile = new File(Path);
				
				FileInputStream Add1fis = new FileInputStream(Add1myFile);
				XSSFWorkbook Add1myWorkBook = new XSSFWorkbook(Add1fis);
				XSSFSheet Add1mySheet = Add1myWorkBook.getSheet("keywords");
				XSSFRow Add1row = null;
				
				// Making the object of excel row
				row = Add1mySheet.getRow(0);	
								
				//int rowCount = mySheet.getLastRowNum() + 1;
				int Add1rowCount = rownumber +1;
				
				System.out.println("Row Count :- " + Add1rowCount);
				
				Add1AppIdNumber = Add1AppIdResult;		
				

				funclib.SetCellData(SheetName,Path,"TestData", Add1rowCount, Add1AppIdResult);
				
				break;
				
			case "InputApplicationId":
				
				//Define WebElement
				//WebElement AppIdString = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement AppIdString = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
				//Input Text				
				AppIdString.clear();
				funclib.DelayTime();				
				AppIdString.sendKeys(AppIdNumber);
				//AppIdString.sendKeys("001024047");
				funclib.DelayTime();
				
				//Print Input Text
				System.out.println(Functionality + " : " + AppIdNumber);
				
				//Actions AppIdAction = new Actions(driver); //Local Host
				Actions AppIdAction = new Actions(driver.get()); //Remote Host
				Thread.sleep(2000);
				AppIdAction.sendKeys(Keys.ENTER).build().perform();
				Thread.sleep(5000);
				
				break;
				
			case "Add1InputApplicationId":
				
				//Define WebElement
				//WebElement Add1AppIdString = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement Add1AppIdString = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
				//Input Text				
				Add1AppIdString.clear();
				funclib.DelayTime();				
				Add1AppIdString.sendKeys(Add1AppIdNumber);
				//Add1AppIdString.sendKeys("001023704");
				funclib.DelayTime();
				
				//Print Input Text
				System.out.println(Functionality + " : " + Add1AppIdNumber);
				
				//Actions Add1AppIdAction = new Actions(driver); //Local Host
				Actions Add1AppIdAction = new Actions(driver.get()); //Remote Host
				Thread.sleep(2000);
				Add1AppIdAction.sendKeys(Keys.ENTER).build().perform();
				Thread.sleep(5000);
				
				break;
			
			case "GenerateContract":
				
				//Splitting Locator Address
				TestDataSplit = LocatorName.split(",") ;				
				
				//Check Generate Contract Link is Enabled
				for(int generatecontractcounter=1;generatecontractcounter<=3;generatecontractcounter++)				
				{					
					//Define WebElement
					//WebElement GenerateContract = driver.findElement(By.xpath(TestDataSplit[0])); //Local Host
					WebElement GenerateContract = driver.get().findElement(By.xpath(TestDataSplit[0])); //Remote Host			
					
					if(GenerateContract.isEnabled())
					{				
						//Generate Contract Enabled
						System.out.println("Generate Contract : Enabled");
						funclib.DelayTime();
					
						GenerateContract.click();
						funclib.DelayTime();
					
						//Wait Time
						for(int delaytimecounter=1; delaytimecounter<=15;delaytimecounter++)
						{													
							funclib.DelayTime();													
						}
						
						//CaptureScreenshot
						funclib.CaptureScreenShot(TestCase);
						funclib.DelayTime();
						
						//Next Screen
						//WebElement GenerateNext = driver.findElement(By.xpath(TestDataSplit[1])); //Local Host
						WebElement GenerateNext = driver.get().findElement(By.xpath(TestDataSplit[1])); //Remote Host
						
						GenerateNext.click();
						funclib.DelayTime();
					}
					//else
					//	break;
				}
				
				
				break;
			
			case "HemCalc":
				//Calculate HEMS Value by Multiplying with 52 Weeks
				int HemCalcResult, TotalHemWeeks;
				TotalHemWeeks = 52;
				
				HemCalcResult = (Integer.parseInt(TestData)) * TotalHemWeeks;
				System.out.println("Hem Calc Result:" + HemCalcResult);
				
				break;
			
			case "CalcSubtract":
				
				// Define WebElement					
				//WebElement DesiredCaptureText = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement DesiredCaptureText = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				String CaptureText = DesiredCaptureText.getText();				
				
				if(CaptureText .equals(CapturedTextValue))
					CaptureText = DesiredCaptureText.getAttribute("value");
				
				String CapturedTextResult = CaptureText.replaceAll("\\$","");
				CapturedTextResult = CapturedTextResult.replaceAll("\\.\\d+","");
				CapturedTextResult = CapturedTextResult.replaceAll("\\D","");
				System.out.println("Value:" + CapturedTextResult);
				
				//Subtract Value
				SubResult = Integer.parseInt(CapturedTextResult)-SubResult;
				
				System.out.println(SubResult);
				
				if(TestData .equals("<Value>"))
				{
					funclib.DelayTime();
					DesiredCaptureText.clear();
					funclib.DelayTime();
					DesiredCaptureText.sendKeys(Integer.toString(SubResult));
				}				
				break;
			
			case "CalendarDate":
				
				LocatorSplit = LocatorName.split(",");
				
				//WebElement ValuationDate = driver.findElement(By.xpath(LocatorSplit[0])); //Local Host
				WebElement ValuationDate = driver.get().findElement(By.xpath(LocatorSplit[0])); //Remote Host
				//WebElement ValuationDateWidget = driver.findElement(By.xpath(LocatorSplit[1])); //Local Host
				WebElement ValuationDateWidget = driver.get().findElement(By.xpath(LocatorSplit[1])); //Remote Host
				
				//Input Valuation Date	
				funclib.DelayTime();
				ValuationDate.click();
				
				funclib.DelayTime();
				
				today = funclib.getCurrentDay();	
				
				 List<WebElement> columns = ValuationDateWidget.findElements(By.tagName("td"));
				 
				 for (WebElement cell: columns) 
				 {
					 //Select Today's Date
					// System.out.println("Date:" +cell.getText());
			         if (cell.getText().equals(today)) 
			         {          	 	        	 
			        	 funclib.DelayTime();
			        	 cell.click();
			        	 
			        	 if(ValuationDate.getText() .equals(cell.getText()))
				        	 break;	         
			         }	         
			     }
				
				funclib.DelayTime();
				
				break;
			
			case "ValidateUser":
				
				//Define WebElement
				//WebElement UserId = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement UserId = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
					
				String ValidUser = TestData;						
				
				//Initialize User Get Text
				String LoginId = UserId.getText();					
				
				//Extract User id Credentials/Substring from the User Id Text
				String LoginIdDesiredVal = ValidUser;			
						
				//Extract String Before Desired Substring 
				String LoginIdBeforeDesiredVal =  LoginId.substring(0, LoginId.indexOf(LoginIdDesiredVal));
						
				//Extract String After Desired Substring
				String LoginIdAfterDesiredVal = LoginId.substring(LoginId.indexOf(LoginIdDesiredVal) + LoginIdDesiredVal.length());
						
				//Initialize Before Substring to NULL
				if(LoginIdBeforeDesiredVal.length()>0)
					LoginIdBeforeDesiredVal="";
					
				//Initialize After Substring to NULL
				if(LoginIdAfterDesiredVal.length()>0)
					LoginIdAfterDesiredVal="";
					
				//Final String after Initializing Before and After Substring
				LoginId = LoginIdBeforeDesiredVal + LoginIdDesiredVal + LoginIdAfterDesiredVal;
			
				System.out.println("User Id: " + LoginId);
				Assert.assertEquals(LoginId, TestData);			
				
				break;
				
			case "DropDown":
				
				//Define WebElement
				//WebElement SelectDropDownType = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement SelectDropDownType = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
			
				// Select Value from DropDown List
				String SelectDropDown = funclib.DropdownListSelect(TestData, SelectDropDownType);
				System.out.println("Selected DropDown Value: " + Functionality + " : " + SelectDropDown);
				Assert.assertEquals(SelectDropDown, TestData);
				
				break;
			
			case "ProductDropDown":
				
				//Define WebElement
				//WebElement ProductDropDownType = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement ProductDropDownType = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
			
				// Select Value from DropDown List
				String ProductDropDown = funclib.DropdownListSelectSpecific(TestData, ProductDropDownType);
				System.out.println("Selected DropDown Value: " + Functionality + " : " + ProductDropDown);
				Assert.assertEquals(ProductDropDown, TestData);
				
				break;
				
			case "Radio":
				
				// Define WebElement					
				//WebElement RadioOption = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement RadioOption = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
			
				// Select Top Up
				String RadioOptionValue = funclib.SelOptionValueKeyword(RadioOption, RadioOption.getAttribute("value"), TestData);
				System.out.println("Selected Radio Value: " + Functionality + " : " + RadioOptionValue);
				Assert.assertEquals(RadioOptionValue.toUpperCase(), TestData.toUpperCase());
				
				break;
			
			case "GetCompareText":
				
				// Define WebElement					
				//WebElement CapturedText = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement CapturedText = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				
				//Get Text
				String CapturedTextInfo = CapturedText.getText();
				System.out.println("Captured Text:" + CapturedTextInfo);
				
				// Compare Text
				if(CapturedTextInfo.toLowerCase() .equals(TestData.toLowerCase()))				
					System.out.println("Captured Text and Actual Text : Match");				
				else
					System.out.println("Captured Text and Actual Text : MisMatch");
				
				Assert.assertEquals(CapturedTextInfo.toLowerCase(), TestData.toLowerCase());
				
				break;
			
			case "GetCaptureText":
				
				// Define WebElement					
				//WebElement GetCaptureText = driver.findElement(By.xpath(LocatorName)); //Local Host
				WebElement GetCaptureText = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
				//String GetCapturedText = GetCaptureText.getText();			
				//String GetCapturedText = GetCaptureText.getAttribute("value");
								
				CapturedTextValue = GetCaptureText.getAttribute("value");
				System.out.println("Captured Value:" + CapturedTextValue);
				
				/*
				
				if(GetCapturedText .equals(CapturedTextValue)) 
				{					
					GetCapturedText=GetCaptureText.getAttribute("value");
				
					System.out.println(GetCapturedText);				
				}
				else
				{
					CapturedTextValue=GetCapturedText;
					System.out.println("Captured Text:" + CapturedTextValue);
				}
				*/
				break;			
			
			case "RefreshUrl":
				
				// Refreshing URL Browser							
				//driver.navigate().refresh(); //Local Host
				driver.get().navigate().refresh(); //Remote Host
				
				break;			
			
			case "LogOut":			
				
				//Define WebElement
				//WebElement LogOutClick = driver.findElement(By.linkText("Logout"));	//Local Host			
				WebElement LogOutClick = driver.get().findElement(By.linkText("Logout")); //Remote Host
				LogOutClick.click();
				
				break;
			
			case "ToggleClickableElement":
								
				//Click on Link Text
				//WebDriverWait clicktogglewait = new WebDriverWait(driver, 25);
				//Actions clicktoggleaction = new Actions(driver);				
				
				//WebDriverWait clicktogglewait = new WebDriverWait(driver.get(), 25);
				//Actions clicktoggleaction = new Actions(driver.get());				
				
				//java.util.List<WebElement> ToggleMaxLink=driver.findElements(By.linkText(TestData)); //Local Host
				java.util.List<WebElement> ToggleMaxLink=driver.get().findElements(By.linkText(TestData)); //Remote Host
				
				if(ToggleMaxLink.size() > 0)
				{					
					for(int ClickCounter=1;ClickCounter<=ToggleMaxLink.size();ClickCounter++)
					{						
						
						funclib.DelayTime();						
						
						// Define WebElement
						//WebElement ClickElement = driver.findElement(By.xpath(LocatorName)); //Local Host			
						WebElement ClickElement = driver.get().findElement(By.xpath(LocatorName)); //Remote Host
						
						//WebElement ClickElem = clicktogglewait.until(ExpectedConditions.elementToBeClickable(ClickElement));
						//clicktoggleaction.moveToElement(ClickElem).doubleClick(ClickElem).perform();
						
						ClickElement.click();
						funclib.DelayTime();
					}
				}
				
				break;
			
			case "ClickableElement":			
				
				// Assess
				String AssessClick = "Assess";
				String ModifyClick= "Modify";
				String WaiveClick = "Waive";				
				
				//Click on Link Text
				//WebDriverWait clickwait = new WebDriverWait(driver, 25); //Local Host
				//Actions clickaction = new Actions(driver);	//Local Host
				
				WebDriverWait clickwait = new WebDriverWait(driver.get(), 25); //Remote Host
				Actions clickaction = new Actions(driver.get());	//Remote Host
				
				//java.util.List<WebElement> MaxLink=driver.findElements(By.linkText(TestData)); //Local Host
				java.util.List<WebElement> MaxLink=driver.get().findElements(By.linkText(TestData)); //Remote Host
				
				if(MaxLink.size() > 0)
				{					
					for(int ClickCounter=1;ClickCounter<=MaxLink.size();ClickCounter++)
					{						
						
						funclib.DelayTime();						
						
						// Define WebElement
						//WebElement ClickElement = driver.findElement(By.linkText(TestData)); //Local Host					
						WebElement ClickElement = driver.get().findElement(By.linkText(TestData)); //Remote Host
						
						WebElement ClickElem = clickwait.until(ExpectedConditions.elementToBeClickable(ClickElement));
						clickaction.moveToElement(ClickElem).doubleClick(ClickElem).perform();						
						funclib.DelayTime();
						
						//Construction Cost and Value General Assessment
						if(AssessClick .equals(TestData))
						{
							
							//WebElement ClickElem = clickwait.until(ExpectedConditions.elementToBeClickable(ClickElement));
							//clickaction.moveToElement(ClickElem).doubleClick(ClickElem).perform();
							
							//WebElement ButtonBack = driver.findElement(By.xpath("//input[@id='main:back']")); //Local Host
							WebElement ButtonBack = driver.get().findElement(By.xpath("//input[@id='main:back']")); //Remote Host
							ButtonBack.click();
							funclib.DelayTime();
							
							String ValueAssessmentId = "//a[@id='main:valuationList:" + (ClickCounter-1) + ":Assess']";
							System.out.println("Value Id:" + ValueAssessmentId);
							//WebElement ValueAssessment = driver.findElement(By.xpath(ValueAssessmentId)); //Local Host
							WebElement ValueAssessment = driver.get().findElement(By.xpath(ValueAssessmentId)); //Remote Host
							ValueAssessment.click();
							funclib.DelayTime();
							
							//WebElement AcceptRadio = driver.findElement(By.xpath("//input[@id='main:isAcceptable:isAcceptable:0']")); //Local Host
							WebElement AcceptRadio = driver.get().findElement(By.xpath("//input[@id='main:isAcceptable:isAcceptable:0']")); //Remote Host
							AcceptRadio.click();							
							funclib.DelayTime();						
							
							//Move Next
							//WebElement MoveNext = driver.findElement(By.xpath("//input[@id='main:next']")); //Local Host
							WebElement MoveNext = driver.get().findElement(By.xpath("//input[@id='main:next']")); //Remote Host
							funclib.DelayTime();
							MoveNext.click();
							
							funclib.DelayTime();
						}
						
						//Waive Click
						if(WaiveClick .equals(TestData))
						{	
							
							//WebElement ClickElem = clickwait.until(ExpectedConditions.elementToBeClickable(ClickElement));
							//clickaction.moveToElement(ClickElem).doubleClick(ClickElem).perform();
							
							funclib.DelayTime();														
							
							//WebElement SelectWaiveReason = driver.findElement(By.xpath("//select[@id='main:changeReasonChoice:changeReasonChoice']")); //Local Host							
							WebElement SelectWaiveReason = driver.get().findElement(By.xpath("//select[@id='main:changeReasonChoice:changeReasonChoice']")); //Remote Host
							funclib.DropdownListSelect("Campaign/Special Promotion ", SelectWaiveReason);							
							funclib.DelayTime();							
							funclib.CaptureScreenShot(TestCase);
							
							//Move Next
							//WebElement MoveNext = driver.findElement(By.xpath("//input[@id='main:next']")); //Local Host
							WebElement MoveNext = driver.get().findElement(By.xpath("//input[@id='main:next']")); //Remote Host
							funclib.DelayTime();
							
							MoveNext.click();
							funclib.DelayTime();							
						}					
						
						//Modify Assets/Liabilities
						if(ModifyClick .equals(TestData))
						{	
							funclib.DelayTime();
							
							//WebElement ButtonBack = driver.findElement(By.xpath("//input[@id='main:back']")); //Local Host
							WebElement ButtonBack = driver.get().findElement(By.xpath("//input[@id='main:back']")); //Remote Host
							funclib.DelayTime();
							ButtonBack.click();
							funclib.DelayTime();
							
							//Click on Modify Link
							//WebElement ModifyAssetLink = driver.findElement(By.xpath("//a[@id='main:liabilityList:" + (ClickCounter-1) + ":modifyBtn']")); //Local Host
							WebElement ModifyAssetLink = driver.get().findElement(By.xpath("//a[@id='main:liabilityList:" + (ClickCounter-1) + ":modifyBtn']")); //Remote Host
							funclib.DelayTime();
							
							ModifyAssetLink.click();
							funclib.DelayTime();						
							
							
							//Maintaining Advance Payment Configuration							
							//List<WebElement> AdvancePayMaintenanceNoList = driver.findElements(By.xpath("//div/span[contains(text(),'maintain their advance payments')]")); //Local Host
							List<WebElement> AdvancePayMaintenanceNoList = driver.get().findElements(By.xpath("//div/span[contains(text(),'maintain their advance payments')]")); //Remote Host
									
														
							//Debt Repaid
							//List<WebElement> DebtRepaidList = driver.findElements(By.xpath("//div/span[contains(text(),'debt being repaid')]")); //Local Host
							List<WebElement> DebtRepaidList = driver.get().findElements(By.xpath("//div/span[contains(text(),'debt being repaid')]")); //Remote Host
							
							
							//Debt Limit
							//List<WebElement> DebtLimitList = driver.findElements(By.xpath("//div/span[contains(text(),'the limit to')]")); //Local Host
							List<WebElement> DebtLimitList = driver.get().findElements(By.xpath("//div/span[contains(text(),'the limit to')]")); //Remote Host
													
						
							if(AdvancePayMaintenanceNoList.size()>0)
							{								
								//WebElement AdvancePayMaintenanceNo = driver.findElement(By.xpath("//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:1']")); //Local Host
								WebElement AdvancePayMaintenanceNo = driver.get().findElement(By.xpath("//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:1']")); //Remote Host
								
								if(!AdvancePayMaintenanceNo.isSelected())
								{
									//Maintain Advance Payments
									AdvancePayMaintenanceNo.click();
									funclib.DelayTime();
								
									//Revised Advance Payment WriteOff Configuration
									//WebElement RevisedAdvanceWriteOff = driver.findElement(By.xpath("//input[@id='main:revisedRedrawAmount:revisedRedrawAmount']")); //Local Host
									WebElement RevisedAdvanceWriteOff = driver.get().findElement(By.xpath("//input[@id='main:revisedRedrawAmount:revisedRedrawAmount']")); //Remote Host
									
									//Advance Payment WriteOff Configuration
									//WebElement AdvanceWriteOff = driver.findElement(By.xpath("//input[@id='main:redrawAmountReducedBy:redrawAmountReducedBy']")); //Local Host
									WebElement AdvanceWriteOff = driver.get().findElement(By.xpath("//input[@id='main:redrawAmountReducedBy:redrawAmountReducedBy']")); //Remote Host
									
									//Advance Write Off
									if(AdvanceWriteOff.isEnabled())
									{
										AdvanceWriteOff.sendKeys(RevisedAdvanceWriteOff.getAttribute("value"));
										funclib.DelayTime();
									}
								}
							}	
							
							
							//Debt Repaid							
							if(DebtRepaidList.size()>0)
							{	
								//Debt Repaid
								//WebElement DebtRepaid = driver.findElement(By.xpath("//input[@id='main:liabbeingRepaid:liabbeingRepaid:2']")); //Local Host
								WebElement DebtRepaid = driver.get().findElement(By.xpath("//input[@id='main:liabbeingRepaid:liabbeingRepaid:2']")); //Remote Host
								funclib.DelayTime();
								DebtRepaid.click();
								funclib.DelayTime();
							}
							
							//Debt Cleared
							//List<WebElement> DebtClearedList = driver.findElements(By.xpath("//div/span/span[contains(text(),'debt being cleared')]")); //Local Host
							List<WebElement> DebtClearedList = driver.get().findElements(By.xpath("//div/span/span[contains(text(),'debt being cleared')]")); //Remote Host
							
														
							//Debt Cleared
							if(DebtClearedList.size()>0)
							{									
								//Debt Cleared
								//WebElement DebtCleared = driver.findElement(By.xpath("//input[@id='main:liabbeingCleared:liabbeingCleared:2']")); //Local Host
								WebElement DebtCleared = driver.get().findElement(By.xpath("//input[@id='main:liabbeingCleared:liabbeingCleared:2']")); //Remote Host
								funclib.DelayTime();
								DebtCleared.click();
								funclib.DelayTime();
							}						
							
							
							//Debt Limit
							if(DebtLimitList.size()>0)
							{								
								//Debt Limit
								//WebElement DebtLimit = driver.findElement(By.xpath("//input[@id='main:liablimitBeingChanged:liablimitBeingChanged:2']")); //Local Host
								WebElement DebtLimit = driver.get().findElement(By.xpath("//input[@id='main:liablimitBeingChanged:liablimitBeingChanged:2']")); //Remote Host
								funclib.DelayTime();
								DebtLimit.click();
								funclib.DelayTime();
							}
							
							
							//Liability Tax Deductible
							//List<WebElement> TaxDeductibleList = driver.findElements(By.xpath("//div/span[contains(text(),'liability tax deductible')]")); //Local Host
							List<WebElement> TaxDeductibleList = driver.get().findElements(By.xpath("//div/span[contains(text(),'liability tax deductible')]")); //Remote Host
							
														
							//Liability Tax Deductible
							if(TaxDeductibleList.size()>0)
							{									
								//Debt Cleared
								//WebElement TaxDeductible = driver.findElement(By.xpath("//input[@id='main:isTaxDeductible:isTaxDeductible:0']")); //Local Host
								WebElement TaxDeductible = driver.get().findElement(By.xpath("//input[@id='main:isTaxDeductible:isTaxDeductible:0']")); //Remote Host
								funclib.DelayTime();
								TaxDeductible.click();
								funclib.DelayTime();
							}
																							
							funclib.CaptureScreenShot(TestCase);
							funclib.DelayTime();
									
							//Move Next
							//WebElement MoveNext = driver.findElement(By.xpath("//input[@id='main:next']")); //Local Host
							WebElement MoveNext = driver.get().findElement(By.xpath("//input[@id='main:next']")); //Remote Host
							funclib.DelayTime();
							
							MoveNext.click();
							funclib.DelayTime();					
						}					
						System.out.println("Element: Clicked");
						funclib.DelayTime();
					}
				}				
				
				//Capture Screenshot
				funclib.CaptureScreenShot(TestCase);				
				funclib.DelayTime();
				
				break;
			
			case "SubmitOriginationClaim":
				
				//Filter Out Mandate Items
				submitclaim.NonMandatory();
				
				//Submit Origination Claim
				submitclaim.SubmitOrigination(TestCase);
								
				break;
			
			case "NoSubmitOriginationClaim":
				
				//Filter Out Mandate Items
				submitclaim.NonMandatory();
				
				//Submit Origination Claim
				submitclaim.NoSubmitOrigination(TestCase);
								
				break;
					
			case "SubmitCreditClaim":
				
				//Filter Out Mandate Items
				submitclaim.NonMandatory();
				
				//Submit Credit Analysis Claim
				submitclaim.SubmitCreditAnalysis(TestCase);
				
				break;
				
			case "SubmitSettlementClaim":
				
				//Filter Out Mandate Items
				submitclaim.NonMandatory();
				
				//Submit Settlement Claim
				submitclaim.SubmitSettlement(TestCase);
				
				break;
			
			case "SubmitGoToSettlementClaim":
				
				//Filter Out Mandate Items
				submitclaim.NonMandatory();
				
				//Submit Settlement Claim
				TestDataSplit = TestData.split(",");
				funclib.DelayTime();
				submitclaim.SubmitSettlementGoTo(TestDataSplit[0],TestDataSplit[1],TestDataSplit[2],TestDataSplit[3],TestDataSplit[4],TestDataSplit[5],TestDataSplit[6],TestDataSplit[7],TestCase);
				
				break;			
			
			case "CheckAdvancePayment":
				//Check Advance Payment Options
				//WebElement CheckAdvancePayment = driver.findElement(By.xpath("//input[@id='main:liabadvancePayment:liabadvancePayment']")); //Local Host
				WebElement CheckAdvancePayment = driver.get().findElement(By.xpath("//input[@id='main:liabadvancePayment:liabadvancePayment']")); //Remote Host
				
				//Advance Payment Interested - Yes
				//WebElement RadioAdvancePaymentYes = driver.findElement(By.xpath("//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:0']")); //Local Host
				WebElement RadioAdvancePaymentYes = driver.get().findElement(By.xpath("//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:0']")); //Remote Host
				
				//Advance Payment Interested - No
				//WebElement RadioAdvancePaymentNo = driver.findElement(By.xpath("//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:1']"));
				//WebElement RadioAdvancePaymentNo = driver.get().findElement(By.xpath("//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:1']"));
				
				
				//Check if Advance Payment > $0.00
				String AdvancePay = "$0.00";
				
				//int CheckAdvancePayCount = driver.findElements(By.xpath("//input[@id='main:liabadvancePayment:liabadvancePayment']")).size(); //Local Host
				int CheckAdvancePayCount = driver.get().findElements(By.xpath("//input[@id='main:liabadvancePayment:liabadvancePayment']")).size(); //Remote Host
				
				if(CheckAdvancePayCount> 0)
				{
					if(!AdvancePay .equals(CheckAdvancePayment.getAttribute("value")))
					{
						if(RadioAdvancePaymentYes.isDisplayed())
						{
							funclib.DelayTime();
							RadioAdvancePaymentYes.click();
						}
					}
				}
			
				break;			
			
			default:
				
				break;
				
		}
	}
}
