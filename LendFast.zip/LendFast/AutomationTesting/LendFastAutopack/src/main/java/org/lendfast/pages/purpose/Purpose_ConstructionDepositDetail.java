package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_ConstructionDepositDetail extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
									
	//Defining WebElements
								
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Construction/Major Renovation - Deposit Details')]")
	WebElement HeadSection;
	
	//Select Soure Of Deposit
	@FindBy(xpath="//select[@id='main:depositsource:depositsource']")
	WebElement SelectSourceDeposit;
	
	//Deposit Status - Future Contribution
	@FindBy(xpath="//input[@id='main:depositisPaid:depositisPaid:0']")
	WebElement RadioDepositStatusFuture;
	
	//Deposit Status - Paid
	@FindBy(xpath="//input[@id='main:depositisPaid:depositisPaid:1']")
	WebElement RadioDepositStatusPaid;
	
	//Input Deposit Amount
	@FindBy(xpath="//input[@id='main:depositamount:depositamount']")
	WebElement InputDepositAmount;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Purpose_ConstructionDepositDetail()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Construction/Major Renovation - Deposit Details");		
		return HeadSectionResult;
	}
		
		//Select Source of Deposit
		public String SelSourceDeposit(String SourceDeposit)
		{
			String SelectOption = SourceDeposit;
			String SelDepositType = funclib.DropdownListSelect(SelectOption, SelectSourceDeposit);
			return SelDepositType;		
		}
		
		//Select Deposit Status
		public String SelDepositStatus(String DepositStatus) throws InterruptedException
		{		
			String OptionValue = DepositStatus;		
			String DepositStatusResult= funclib.SelOptionValue(RadioDepositStatusFuture, RadioDepositStatusFuture.getAttribute("value"),RadioDepositStatusPaid,RadioDepositStatusPaid.getAttribute("value"),OptionValue);	
			return DepositStatusResult;		
		}
		
		//Input Deposit Amount
		public void InputDepositAmount(String DepositAmount) throws InterruptedException
		{
			InputDepositAmount.clear();
			funclib.DelayTime();
			InputDepositAmount.sendKeys(DepositAmount);
			funclib.DelayTime();		
		}
		
		//Navigate to Next Page
		public void NextPage() throws InterruptedException
		{		
			funclib.DelayTime();
			NextClick.click();	
		}
}
