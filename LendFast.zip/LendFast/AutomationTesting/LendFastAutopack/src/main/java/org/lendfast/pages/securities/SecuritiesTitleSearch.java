package org.lendfast.pages.securities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SecuritiesTitleSearch extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
	
	//Defining WebElements
	
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'LTO Searches')]")
	WebElement HeadSection;
	
	//Add Extract Title Link
	@FindBy(xpath="//input[@id='main:NeedingExtractPropertyTitle']")
	WebElement AddTitleClick;
	
	//Valid Search Result - Yes
	@FindBy(xpath="//input[@id='main:ltosearchisValid:ltosearchisValid:0']")
	WebElement RadioSearchResultYes;
	
	//Valid Search Result - No
	@FindBy(xpath="//input[@id='main:ltosearchisValid:ltosearchisValid:1']")
	WebElement RadioSearchResultNo;
	
	//Title Type
	@FindBy(xpath="//select[@id='main:propTitletitleType:propTitletitleType']")
	WebElement SelectTitleType;
	
	//Title Match Vendor - Yes
	@FindBy(xpath="//input[@id='main:ltoSearchisNameMatch:ltoSearchisNameMatch:0']")
	WebElement RadioTitleMatchYes;
	
	//Title Match Vendor - No
	@FindBy(xpath="//input[@id='main:ltoSearchisNameMatch:ltoSearchisNameMatch:1']")
	WebElement RadioTitleMatchNo;
	
	//Real Property Match Vendor - Yes
	@FindBy(xpath="//input[@id='main:ltoSearchisRpdMatch:ltoSearchisRpdMatch:0']")
	WebElement RadioPropertyMatchYes;	
	
	//Real Property Match Vendor - No
	@FindBy(xpath="//input[@id='main:ltoSearchisRpdMatch:ltoSearchisRpdMatch:1']")
	WebElement RadioPropertyMatchNo;	
	
	//Transfer of Land - Yes
	@FindBy(xpath="//input[@id='main:hasTransferOfLand:hasTransferOfLand:0']")
	WebElement RadioLandTransferYes;
	
	//Transfer of Land - No
	@FindBy(xpath="//input[@id='main:hasTransferOfLand:hasTransferOfLand:1']")
	WebElement RadioLandTransferNo;
	
	//Transfer of Land - Vendor Owner - Match - Yes
	@FindBy(xpath="//input[@id='main:areNamesMatchingTransferOfLand:areNamesMatchingTransferOfLand:0']")
	WebElement RadioLandTransferVendorOwnerYes;
	
	//Transfer of Land - Vendor Owner - Match - No
	@FindBy(xpath="//input[@id='main:areNamesMatchingTransferOfLand:areNamesMatchingTransferOfLand:1']")
	WebElement RadioLandTransferVendorOwnerNo;
	
	//Estate and Interest
	@FindBy(xpath="//select[@id='main:ltoSearchtenureType:ltoSearchtenureType']")
	WebElement SelectEstateInterest;
	
	//Acceptance of Proceeding - Yes
	@FindBy(xpath="//input[@id='main:ltoSearchisAcceptable:ltoSearchisAcceptable:0']")
	WebElement RadioAcceptanceYes;
	
	//Acceptance of Proceeding - No
	@FindBy(xpath="//input[@id='main:ltoSearchisAcceptable:ltoSearchisAcceptable:1']")
	WebElement RadioAcceptanceNo;
	
	//Physical Title - Yes
	@FindBy(xpath="//input[@id='main:propTitlehasPhysTitle:propTitlehasPhysTitle:0']")
	WebElement RadioPhysicalTitleYes;
	
	//Physical Title - No
	@FindBy(xpath="//input[@id='main:propTitlehasPhysTitle:propTitlehasPhysTitle:1']")
	WebElement RadioPhysicalTitleNo;	
	
	//Ancillary Titles - Yes
	@FindBy(xpath="//input[@id='main:ltoSearchhasAncillaryTitles:ltoSearchhasAncillaryTitles:0']")
	WebElement RadioAncillaryYes;
	
	//Ancillary Titles - No
	@FindBy(xpath="//input[@id='main:ltoSearchhasAncillaryTitles:ltoSearchhasAncillaryTitles:1']")
	WebElement RadioAncillaryNo;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public SecuritiesTitleSearch()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
	
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "LTO Searches");		
		return HeadSectionResult;
	}
	
	//Click on Add Title Extract Link
	public void TitleSearch() throws InterruptedException
	{			
		AddTitleClick.click();
		funclib.DelayTime();
	}
	
	//Select Search Valid Result
	public String SelValidResult(String ValidResult) throws InterruptedException
	{		
		String OptionValue = ValidResult;		
		String SearchValidResult= funclib.SelOptionValue(RadioSearchResultYes, RadioSearchResultYes.getAttribute("value"),RadioSearchResultNo,RadioSearchResultNo.getAttribute("value"),OptionValue);	
		return SearchValidResult;		
	}
	
	//Select Title Type
	public String SelTitleType(String TitleType)
	{
		String SelectOption = TitleType;
		String SelectTitle = funclib.DropdownListSelect(SelectOption, SelectTitleType);
		return SelectTitle;		
	}	
	
	//Select Title-Vendor Name Match
	public String SelTitleNameMatch(String TitleName) throws InterruptedException
	{		
		String OptionValue = TitleName;		
		String TitleNameResult= funclib.SelOptionValue(RadioTitleMatchYes, RadioTitleMatchYes.getAttribute("value"),RadioTitleMatchNo,RadioTitleMatchNo.getAttribute("value"),OptionValue);	
		return TitleNameResult;		
	}
	
	//Select Real Property Match
	public String SelRealPropertyMatch(String RealProperty) throws InterruptedException
	{		
		String OptionValue = RealProperty;		
		String RealPropertyResult= funclib.SelOptionValue(RadioPropertyMatchYes, RadioPropertyMatchYes.getAttribute("value"),RadioPropertyMatchNo,RadioPropertyMatchNo.getAttribute("value"),OptionValue);	
		return RealPropertyResult;		
	}
	
	//Select Transfer of Land
	public String SelLandTransfer(String LandTransfer) throws InterruptedException
	{		
		String OptionValue = LandTransfer;		
		String LandTransferResult= funclib.SelOptionValue(RadioLandTransferYes, RadioLandTransferYes.getAttribute("value"),RadioLandTransferNo,RadioLandTransferNo.getAttribute("value"),OptionValue);	
		return LandTransferResult;		
	}
	
	//Select Transfer of Land -> Vendor-Owner Name Match
	public String SelLandTransferMatch(String LandTransferMatch) throws InterruptedException
	{		
		String OptionValue = LandTransferMatch;		
		String LandTransferMatchResult= funclib.SelOptionValue(RadioLandTransferVendorOwnerYes, RadioLandTransferVendorOwnerYes.getAttribute("value"),RadioLandTransferVendorOwnerNo,RadioLandTransferVendorOwnerNo.getAttribute("value"),OptionValue);	
		return LandTransferMatchResult;		
	}
	
	//Select Estate and Interest
	public String SelEstateInterest(String EstateInterest)
	{
		String SelectOption = EstateInterest;
		String SelEstateInterestResult = funclib.DropdownListSelect(SelectOption, SelectEstateInterest);
		return SelEstateInterestResult;		
	}
	
	//Select Acceptance of Proceed
	public String SelAcceptanceProceed(String AcceptanceProceed) throws InterruptedException
	{		
		String OptionValue = AcceptanceProceed;		
		String AcceptanceProceedResult= funclib.SelOptionValue(RadioAcceptanceYes, RadioAcceptanceYes.getAttribute("value"),RadioAcceptanceNo,RadioAcceptanceNo.getAttribute("value"),OptionValue);	
		return AcceptanceProceedResult;		
	}
	
	//Select Physical Title Existence
	public String SelPhysicalTitle(String PhysicalTitle) throws InterruptedException
	{		
		String OptionValue = PhysicalTitle;		
		String PhysicalTitleResult= funclib.SelOptionValue(RadioPhysicalTitleYes, RadioPhysicalTitleYes.getAttribute("value"),RadioPhysicalTitleNo,RadioPhysicalTitleNo.getAttribute("value"),OptionValue);	
		return PhysicalTitleResult;		
	}
	
	//Select Ancillary Title
	public String SelAncillaryTitle(String AncillaryTitle) throws InterruptedException
	{		
		String OptionValue = AncillaryTitle;		
		String AncillaryTitleResult= funclib.SelOptionValue(RadioAncillaryYes, RadioAncillaryYes.getAttribute("value"),RadioAncillaryNo,RadioAncillaryNo.getAttribute("value"),OptionValue);	
		return AncillaryTitleResult;		
	}	
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
}
