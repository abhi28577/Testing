package org.lendfast.pages.login;

import org.lendfast.base.ParentPage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends ParentPage
{
		
	//User Id	
	@FindBy(xpath="//div[contains(text(),'(')]")
	WebElement UserId;
	
	//Create Application
	@FindBy(linkText="Create Application")
	WebElement CreateApplication;
	
	//Open Application
	@FindBy(xpath="//a[@id='main:taskList:0:Open']")
	WebElement OpenApplication;
	
	//Purpose Selection
	@FindBy(linkText="Purpose")
	WebElement Purpose;
	
	//Assets Selection
	@FindBy(linkText="Assets")
	WebElement Assets;
	
	//Product Selection
	@FindBy(linkText="Product Selection")
	WebElement ProductSelection;
	
	//Securities
	@FindBy(linkText="Securities")
	WebElement Securities;
	
	
	//CheckList
	@FindBy(linkText="Checklist")
	WebElement CheckList;
		
	
	public HomePage()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
	}
	
	//Validating User Credentials between User Credential Excel Sheet and HomePage Credentials
	public String UserIdCredentials(String Username,String Pass) throws InterruptedException
	{
		String ValidUser = Username;
		//String ValidPass = Pass;		
		
		//Initialize User Get Text
		String LoginId = UserId.getText();
		
		//Extract User id Credentials/Substring from the User Id Text
		String LoginIdDesiredVal = ValidUser;			
				
		//Extract String Before Desired Substring 
		String LoginIdBeforeDesiredVal =  LoginId.substring(0, LoginId.indexOf(LoginIdDesiredVal));
				
		//Extract String After Desired Substring
		String LoginIdAfterDesiredVal = LoginId.substring(LoginId.indexOf(LoginIdDesiredVal) + LoginIdDesiredVal.length());
				
		//Initialize Before Substring to NULL
		if(LoginIdBeforeDesiredVal.length()>0)
			LoginIdBeforeDesiredVal="";
				
		//Initialize After Substring to NULL
		if(LoginIdAfterDesiredVal.length()>0)
			LoginIdAfterDesiredVal="";
				
		//Final String after Initializing Before and After Substring
		LoginId = LoginIdBeforeDesiredVal + LoginIdDesiredVal + LoginIdAfterDesiredVal;
		
		return LoginId;
	}
	
	//Navigating to New Application
	public void CreateApplication() throws InterruptedException
	{	
		CreateApplication.click();
		//OpenApplication.click();
		//Thread.sleep(5000);
		
		//Assets.click();
		//CheckList.click();
		//Securities.click();		
	}
}


