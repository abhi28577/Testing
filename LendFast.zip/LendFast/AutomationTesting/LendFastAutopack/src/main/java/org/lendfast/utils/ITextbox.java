package org.lendfast.utils;

public interface ITextbox {
	public String getText();

    public void clear();
    
    public void click();
    
    public boolean isDisplayed();
    
      
    public void type(String... keyword);

}
