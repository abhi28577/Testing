package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_Purposes extends ParentPage 
{
	// Initialize Functions
		CommonFuncLib funclib;
			
	//Defining WebElements
			
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Purposes')]")
	WebElement HeadSection;
	
	//Loan Purpose Type
	@FindBy(xpath="//select[@id='main:purposetype:purposetype']")
	WebElement SelectLoanPurposeType;
	
	//Define Add Purpose Button
	@FindBy(xpath="//input[@id='main:addBtn']")
	WebElement AddPurposeClick;
	
	//Constructor
	public Purpose_Purposes()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
	
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Purposes");		
		return HeadSectionResult;
	}
	
	//Select Loan Purpose Type
	public String SelLoanPurposeType(String LoanPurposeType) throws InterruptedException
	{
		String SelectOption = LoanPurposeType;
		String SelLoanType = funclib.DropdownListSelect(SelectOption, SelectLoanPurposeType);		
		return SelLoanType;		
	}
	
	//Click on Add Purpose Link
	public void AddPurposePage() throws InterruptedException
	{		
		funclib.DelayTime();
		AddPurposeClick.click();
	}
}
