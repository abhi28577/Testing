package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GuarantorEmploymentDetail extends ParentPage 
{
	// Initialize Functions
		CommonFuncLib funclib;
							
		//Defining WebElements
							
		//Define Heading Section
		@FindBy(xpath="//div[contains(text(),'Employments for Guarantor')]")
		WebElement HeadSection;
		
		//Modify Click option
		@FindBy(xpath="//a[@id='main:empList:0:modify']")
		WebElement ClickModify;
		
		//Constructor
		public GuarantorEmploymentDetail()
		{			
			PageFactory.initElements(driver, this);
			//PageFactory.initElements(driver.get(), this);
			funclib=new CommonFuncLib();
		}
								
		//Capturing Head Section
		public String CaptureHeadSection()
		{
			String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Employments for Guarantor");
			
			return HeadSectionResult;
		}
		
		//Click on Modify Link
		public void ModifyClick() throws InterruptedException
		{
			//Click on Modify Click against Employment of Applicant
				ClickModify.click();
				funclib.DelayTime();
		}
}
