package org.lendfast.pages.decision;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CAReports extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
					
	//Define WebElements
					
	//Define Application Type
	@FindBy(xpath="//div[contains(text(),'CA Reports')]")
	WebElement HeadSection;
			
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
			
	//Constructor
	public CAReports()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}	
				
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "CA Reports");		
		return HeadSectionResult;
	}
			
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
}
