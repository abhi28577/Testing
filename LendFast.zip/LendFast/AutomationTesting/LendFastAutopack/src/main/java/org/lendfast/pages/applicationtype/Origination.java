package org.lendfast.pages.applicationtype;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Origination extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
	
	//Defining WebElements
	
	//Define Origination Heading Section
	@FindBy(xpath="//div[contains(text(),'Origination')]")
	WebElement HeadSection;
	
	//Define Heading Section for Existing Applications
	@FindBy(xpath="//div[contains(text(),'Existing Applications')]")
	WebElement HeadSectionExisting;
	
	//Extract Application Id
	@FindBy(xpath="//span[@id='infoAreaSpan']")
	WebElement ApplicationId;
	
	//Define Origination System
	@FindBy(xpath="//span[@id='main:apporiginatorsystem:apporiginatingsystem']")
	WebElement OriginSystem;
	
	//Define Origination Area
	@FindBy(xpath="//select[@id='main:apporiginatorlevel1Div:apporiginatorlevel1Select']")
	WebElement SelOriginArea;
	
	//Define Originator Level
	@FindBy(xpath="//select[@id='main:apporiginatorlevel2:apporiginatorlevel2Select']")
	WebElement SelOriginLevel;
	
	//Define Originator Level 2
	@FindBy(xpath="//select[@id='main:apporiginatorlevel3:apporiginatorlevel3Select']")
	WebElement SelOriginLevel2;
	
	//Define Radio Button Options (Yes)
	@FindBy(xpath="//input[@id='main:isAppIntroducerReferred:isAppIntroducerReferred:0']")
	WebElement RadioTopUpYes;
		
	//Define Radio Button Options (No)
	@FindBy(xpath="//input[@id='main:isAppIntroducerReferred:isAppIntroducerReferred:1']")
	WebElement RadioTopUpNo;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Origination()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
	
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Origination");
		
		return HeadSectionResult;
	}
	
	//Capturing Head Section
	public String CaptureHeadSectionExisting()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSectionExisting.getText(), "Existing Applications");				
		return HeadSectionResult;		
	}
	
	// Capturing Originating System
	public String OriginSystem()
	{
		return OriginSystem.getText();
	}
	
	//Capturing Application Id
	public String CaptureApplicationId() throws InterruptedException
	{
		String AppId = ApplicationId.getText();
		funclib.DelayTime();
		String AppIdResult = AppId.replaceAll("\\D","");
		//System.out.println("Application Id:" + AppIdResult);
		return AppIdResult;
	}
	
	
	//Select Origination Area
	public String SelOriginationArea(String TOrigin)
	{
		String SelectApplication = funclib.DropdownListSelect(TOrigin, SelOriginArea);
		return SelectApplication;		
	}
	
	
	//Select Originator Level
	public String SelOriginatorLevel(String TOriginLevel)
	{
		String SelectApplication = funclib.DropdownListSelect(TOriginLevel, SelOriginLevel);
		return SelectApplication;		
	}
	
	//Select Originator Level 2
	public String SelOriginatorLevel2(String TOriginLevel2)
	{
		String SelectApplication = funclib.DropdownListSelect(TOriginLevel2, SelOriginLevel2);
		return SelectApplication;		
	}
	
	//Select Referrer Commission
	public String SelReferrerType(String TReferrer) throws InterruptedException
	{		
		String ReferrerResult = funclib.SelOptionValue(RadioTopUpYes, RadioTopUpYes.getAttribute("value"),RadioTopUpNo,RadioTopUpNo.getAttribute("value"), TReferrer);				
		return ReferrerResult;	
	}
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
	

}
