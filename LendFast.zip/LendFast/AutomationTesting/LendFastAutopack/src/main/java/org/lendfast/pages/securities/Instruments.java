package org.lendfast.pages.securities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Instruments extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
					
	//Define WebElements
					
	//Define Application Type
	@FindBy(xpath="//div[contains(text(),'Instruments')]")
	WebElement HeadSection;
			
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
			
	//Constructor
	public Instruments()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}	
				
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Instruments");		
		return HeadSectionResult;
	}
			
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
}
