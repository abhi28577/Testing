package org.lendfast.utils;

public interface ICheckbox {
	
	public boolean isChecked();

	public void click();


}
