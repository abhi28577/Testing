package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicantEmploymentDetailSkip extends ParentPage 
{
	// Initialize Functions
		CommonFuncLib funclib;
							
		//Defining WebElements
							
		//Define Heading Section
		@FindBy(xpath="//div[contains(text(),'Employments for Applicant')]")
		WebElement HeadSection;
		
		//Next Click
		@FindBy(xpath="//input[@id='main:next']")
		WebElement NextClick;
		
		//Constructor
		public ApplicantEmploymentDetailSkip()
		{			
			PageFactory.initElements(driver, this);
			//PageFactory.initElements(driver.get(), this);
			funclib=new CommonFuncLib();
		}
								
		//Capturing Head Section
		public String CaptureHeadSection()
		{
			String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Employments for Applicant");
			
			return HeadSectionResult;
		}
		
		//Click on Next Link
		public void NextClick() throws InterruptedException
		{
			//Click on Next Click against Employment of Applicant
			funclib.DelayTime();
			NextClick.click();			
			funclib.DelayTime();
		}

}
