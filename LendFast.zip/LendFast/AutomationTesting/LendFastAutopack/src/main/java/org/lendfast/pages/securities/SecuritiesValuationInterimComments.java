package org.lendfast.pages.securities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SecuritiesValuationInterimComments extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;	
									
	//Defining WebElements
								
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Valuation Interim Comments')]")
	WebElement HeadSection;
	
	//Radio Button - Accepted
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:0']")
	WebElement RadioAccepted;
	
	//Radio Button - Allocated
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:1']")
	WebElement RadioAllocated;
	
	//Radio Button - Assigned
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:2']")
	WebElement RadioAssigned;
	
	//Radio Button - Awaiting Cancellation
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:3']")
	WebElement RadioCancellation;
	
	//Radio Button - Awaiting Completion
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:4']")
	WebElement RadioCompletion;
	
	//Radio Button - Cancelled
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:5']")
	WebElement RadioCancelled;
	
	//Radio Button - Completed
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:6']")
	WebElement RadioCompleted;
	
	//Radio Button - Declined
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:7']")
	WebElement RadioDeclined;
	
	//Radio Button - Delayed
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:8']")
	WebElement RadioDelayed;
	
	//Radio Button - Finalised
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:9']")
	WebElement RadioFinalised;
	
	//Radio Button - More Information Requested
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:10']")
	WebElement RadioRequested;
	
	//Radio Button - Rejected
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:11']")
	WebElement RadioRejected;
	
	//Radio Button - Report Received
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:12']")
	WebElement RadioReceived;
	
	//Radio Button - Sent
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:13']")
	WebElement RadioSent;
	
	//Radio Button - Submitted
	@FindBy(xpath="//input[@id='main:valnreqvaluerStatus:valnreqvaluerStatus:14']")
	WebElement RadioSubmitted;
	
	//Click on Assess Link
	@FindBy(xpath="//td[contains(text(),'Manual Valuation')]/following-sibling::td[7]/a[contains(text(),'Assess')]")
	WebElement AssessClick;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public SecuritiesValuationInterimComments()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
						
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Valuation Interim Comments");		
		return HeadSectionResult;
	}
	
	//Select Valuation Interim Comments
	public void SelectInterimType(String InterimComments) throws InterruptedException
	{
		String Accepted = "ACCEPTED";
		String Allocated = "ALLOCATED";
		String Assigned = "ASSIGNED";
		String Cancellation = "AWAITING_CANCELLATION";
		String Completion = "IN_PROGRESS";
		String Cancelled = "CANCELLED";
		String Completed = "COMPLETED";
		String Declined = "DECLINED";
		String Delayed = "DELAYED";
		String Finalised = "FINALISED";
		String Requested = "INQUIRING";
		String Rejected = "REJECTED";
		String Received = "REPORT_RECEIVED";
		String Sent = "SENT";
		String Submitted = "SUBMITTED";
		
		funclib.DelayTime();
		
		//Accepted
		if(InterimComments .equals(Accepted))
		{
			RadioAccepted.click();
			funclib.DelayTime();
			System.out.println("Accepted");
		}
		
		//Allocated
		if(InterimComments .equals(Allocated))
		{
			RadioAllocated.click();
			funclib.DelayTime();
			System.out.println("Allocated");
		}
		
		//Assigned
		if(InterimComments .equals(Assigned))
		{
			RadioAssigned.click();
			funclib.DelayTime();
			System.out.println("Assigned");
		}
		
		//Cancellation
		if(InterimComments .equals(Cancellation))
		{
			RadioCancellation.click();
			funclib.DelayTime();
			System.out.println("Awaiting Cancellation");
		}
		
		//Completion
		if(InterimComments .equals(Completion))
		{
			RadioCompletion.click();
			funclib.DelayTime();
			System.out.println("Awaiting Completion");
		}
		
		//Cancelled
		if(InterimComments .equals(Cancelled))
		{
			RadioCancelled.click();
			funclib.DelayTime();
			System.out.println("Cancelled");
		}
		
		//Completed
		if(InterimComments .equals(Completed))
		{
			RadioCompleted.click();
			funclib.DelayTime();
			System.out.println("Completed");
		}
		
		//Declined
		if(InterimComments .equals(Declined))
		{
			RadioDeclined.click();
			funclib.DelayTime();
			System.out.println("Declined");
		}
		
		//Delayed
		if(InterimComments .equals(Delayed))
		{
			RadioDelayed.click();
			funclib.DelayTime();
			System.out.println("Delayed");
		}
		
		//Finalised
		if(InterimComments .equals(Finalised))
		{
			RadioFinalised.click();
			funclib.DelayTime();
			System.out.println("Finalised");
		}
		
		//Requested
		if(InterimComments .equals(Requested))
		{
			RadioRequested.click();
			funclib.DelayTime();
			System.out.println("More Information Requested");
		}
		
		//Rejected
		if(InterimComments .equals(Rejected))
		{
			RadioRejected.click();
			funclib.DelayTime();
			System.out.println("Rejected");
		}
		
		//Received
		if(InterimComments .equals(Received))
		{
			RadioReceived.click();
			funclib.DelayTime();
			System.out.println("Report Received");
		}
		
		//Sent
		if(InterimComments .equals(Sent))
		{
			RadioSent.click();
			funclib.DelayTime();
			System.out.println("Sent");
		}
		
		//Submitted
		if(InterimComments .equals(Submitted))
		{
			RadioSubmitted.click();
			funclib.DelayTime();
			System.out.println("Submitted");
		}
	}
	
	//Credit Analysis - Click On Status Link against Manual Valuation
	public void AssessLinkClick() throws InterruptedException
	{
		//Click on Status Link
		funclib.DelayTime();
		AssessClick.click();
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
