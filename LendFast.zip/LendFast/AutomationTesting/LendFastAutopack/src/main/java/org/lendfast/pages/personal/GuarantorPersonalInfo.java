package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GuarantorPersonalInfo extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
		
	//Defining WebElements
		
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Personal Detail for Guarantor')]")
	WebElement HeadSection;
	
	//Spouse/Partner
	@FindBy(xpath="//select[@id='main:partypartnerStatus:partypartnerStatus']")
	WebElement SelectPartner;
	
	//Dependents of Applicant - Yes
	@FindBy(xpath="//input[@id='main:partyhasDependents:partyhasDependents:0']")
	WebElement RadioDependentYes;
	
	//Dependents of Applicant - No
	@FindBy(xpath="//input[@id='main:partyhasDependents:partyhasDependents:1']")
	WebElement RadioDependentNo;	
	
	//Signing Method
	@FindBy(xpath="//select[@id='main:signingBy:signingBy']")
	WebElement SelectSignMethod;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public GuarantorPersonalInfo()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Personal Detail for Guarantor");
		
		return HeadSectionResult;
	}
	
	//Select Spouse/Partner
	public String SelPartner(String Partner)
	{
		String SelectOption = Partner;
		String SelPartner = funclib.DropdownListSelect(SelectOption, SelectPartner);
		return SelPartner;		
	}
	
	//Select Dependents
	public String SelDependent(String Dependent) throws InterruptedException
	{		
		String OptionValue = Dependent;		
		String DependentResult= funclib.SelOptionValue(RadioDependentYes, RadioDependentYes.getAttribute("value"),RadioDependentNo,RadioDependentNo.getAttribute("value"),OptionValue);	
		return DependentResult;		
	}	
	
	//Select Signing Method
	public String SelSignMethod(String SignMethod) throws InterruptedException
	{
		String SelectOption = SignMethod;
		String SelSign = funclib.DropdownListSelect(SelectOption, SelectSignMethod);		
		return SelSign;		
	}
	
	public void NextPage() throws InterruptedException
	{
		//Navigate to Next Page
		funclib.DelayTime();
		NextClick.click();	
	}

}
