package org.lendfast.pages.securities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SecuritiesLTOSearchChecks extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
		
	//Defining WebElements
		
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'LTO Search Checks Details')]")
	WebElement HeadSection;
	
	//Listed Encumbrances - Yes
	@FindBy(xpath="//input[@id='main:proptitlehasEncumbrances:proptitlehasEncumbrances:0']")
	WebElement RadioEncumbranceCheckYes;
		
	//Listed Encumbrances - No
	@FindBy(xpath="//input[@id='main:proptitlehasEncumbrances:proptitlehasEncumbrances:1']")
	WebElement RadioEncumbranceCheckNo;
	
	//UnRegistered Dealings - Yes
	@FindBy(xpath="//input[@id='main:proptitlehasUnregDealings:proptitlehasUnregDealings:0']")
	WebElement RadioUnRegisteredYes;
			
	//UnRegistered Dealings - No
	@FindBy(xpath="//input[@id='main:proptitlehasUnregDealings:proptitlehasUnregDealings:1']")
	WebElement RadioUnRegisteredNo;
	
	//NPBS Mortgage Ranking - Yes
	@FindBy(xpath="//input[@id='main:encumranking:encumranking:0']")
	WebElement RadioMortgageRankYes;
				
	//NPBS Mortgage Ranking - No
	@FindBy(xpath="//input[@id='main:encumranking:encumranking:1']")
	WebElement RadioMortgageRankNo;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public SecuritiesLTOSearchChecks()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
	
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "LTO Search Checks Details");		
		return HeadSectionResult;
	}
	
	//Select Encumbrances Listed Type
	public String SelEncumbranceType(String EncumbranceType) throws InterruptedException
	{		
		String OptionValue = EncumbranceType;		
		String EncumbranceTypeResult= funclib.SelOptionValue(RadioEncumbranceCheckYes, RadioEncumbranceCheckYes.getAttribute("value"),RadioEncumbranceCheckNo,RadioEncumbranceCheckNo.getAttribute("value"),OptionValue);	
		return EncumbranceTypeResult;		
	}
	
	//Select UnRegistered Dealings Type
	public String SelUnRegisteredType(String UnRegisteredType) throws InterruptedException
	{		
		String OptionValue = UnRegisteredType;		
		String UnRegisteredTypeResult= funclib.SelOptionValue(RadioUnRegisteredYes, RadioUnRegisteredYes.getAttribute("value"),RadioUnRegisteredNo,RadioUnRegisteredNo.getAttribute("value"),OptionValue);	
		return UnRegisteredTypeResult;		
	}
	
	//Select Mortgage Ranking Type
	public String SelMortgageRankType(String MortgageRankType) throws InterruptedException
	{		
		String OptionValue = MortgageRankType;		
		String MortgageRankTypeResult= funclib.SelOptionValue(RadioMortgageRankYes, RadioMortgageRankYes.getAttribute("value"),RadioMortgageRankNo,RadioMortgageRankNo.getAttribute("value"),OptionValue);	
		return MortgageRankTypeResult;		
	}
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
	
	
}
