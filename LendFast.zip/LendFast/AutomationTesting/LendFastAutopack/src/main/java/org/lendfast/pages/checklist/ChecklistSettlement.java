package org.lendfast.pages.checklist;

import java.util.List;
import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ChecklistSettlement extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;	
									
	//Defining WebElements
								
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Check List')]")
	WebElement HeadSection;
	
	//Define Image Link	
	@FindBy(linkText="Image")
	WebElement ImageClick;
	
	//Define Complete Link	
	@FindBy(linkText="Complete")
	WebElement CompleteClick;	
	
	//Define GoTo Link	
	@FindBy(linkText="Goto")
	WebElement GotoClick;

	//Define Defunc Items
	@FindBy(xpath="//input[@id='main:cklstexcludeCompleted:cklstexcludeCompleted']")
	WebElement CheckDefunctList;
	
	//Define Mandatory Checkbox Submission List
	@FindBy(xpath="//input[@id='main:cklstexcludeNonMandatory:cklstexcludeNonMandatory']")
	WebElement CheckMandateList;
	
	//Submission Position
	@FindBy(xpath="//td[@id = 'main:checkList:0:j_id835']")
	WebElement SubmissionPosition;
		
	//Select Identification Document
	@FindBy(xpath="//select[@id='main:docType:docType']")
	WebElement SelectIdentityType;
	
	//Upload File
	@FindBy(xpath="//input[@id='main:fileUpload:upload:file']")
	WebElement UploadFile;
	
	//Select Submission Process
	@FindBy(xpath="//select[@id='main:docSource:docSource']")
	WebElement SelectSubmissionType;
	
	//Define Add Document Button
	@FindBy(xpath="//input[@id='main:addDocumentBtn']")
	WebElement AddDocClick;
	
	//Define Select Link
	@FindBy(xpath="//input[@id='main:docRelatedTo:selectBtn']")
	WebElement SelectLinkClick;
	
	//Define Ok Button
	@FindBy(xpath="//input[@id='docReqChooserForm:okBtn']")
	WebElement SelectOkClick;
	
	//Select Link
	@FindBy(xpath="//input[@id='main:docRelatedTo:selectBtn']")
	WebElement SelectListClick;	
	
	//Checkbox Verification
	@FindBy(xpath="//input[@id='main:docRelatedTo:requirementsVerified']")
	WebElement CheckboxVerify;
	
	//Document Verification
	@FindBy(xpath="//select[@id='main:statusCbo']")
	WebElement SelectDocumentVerify;	
	
	//Applicant Insurance Verification
	@FindBy(xpath="//textarea[@id='main:cklstverificationNote:cklstverificationNote']")
	WebElement InputApplicantInsuranceVerify;
	
	//Additional Information/Comments
	@FindBy(xpath="//textarea[@id='main:appsubmitComment:appsubmitComment']")
	WebElement InputAdditionalInfo;
	
	//Save Additional Information/Comments
	@FindBy(xpath="//input[@id='main:saveCommentsBtn:saveCommentsBtn']")
	WebElement SaveAdditionalInfoClick;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Yes Button
	@FindBy(xpath="//input[@id='yes']")
	WebElement YesClick;
	
	//Submit Button
	@FindBy(xpath="//input[@id='main:submitbutton']")
	WebElement SubmitClick;
	
	//Insurance Required - Yes
	@FindBy(xpath="//input[@id='main:isInsuranceRequired:isInsuranceRequired:0']")
	WebElement RadioInsuranceRequiredYes;
	
	//Insurance Required - No
	@FindBy(xpath="//input[@id='main:isInsuranceRequired:isInsuranceRequired:1']")
	WebElement RadioInsuranceRequiredNo;
	
	//Insurance Policy Type - New
	@FindBy(xpath="//input[@id='main:securityinsPrempolicyNewExisting:securityinsPrempolicyNewExisting:0']")
	WebElement RadioInsuranceTypeYes;
		
	//Insurance Policy Type - Existing
	@FindBy(xpath="//input[@id='main:securityinsPrempolicyNewExisting:securityinsPrempolicyNewExisting:1']")
	WebElement RadioInsuranceTypeNo;
	
	//Select Insurance Company Code
	@FindBy(xpath="//select[@id='main:assetinsPolcompCode:assetinsPolcompCode']")
	WebElement SelectInsuranceCompanyCode;
	
	//Select Policy Type
	@FindBy(xpath="//select[@id='main:assetinsPolpolicyType:assetinsPolpolicyType']")
	WebElement SelectPolicyType;
	
	//Input Policy Number
	@FindBy(xpath="//input[@id='main:assetinsPolpolicyNum:assetinsPolpolicyNum']")
	WebElement InputPolicyNumber;
	
	//Input Amount Coverage
	@FindBy(xpath="//input[@id='main:assetinsPolamountOfCover:assetinsPolamountOfCover']")
	WebElement InputCoverageAmount;
	
	//Input Expiry Date
	@FindBy(xpath="//input[@id='main:assetinsPolexpiryDate:assetinsPolexpiryDateInputDate']")
	WebElement InputExpiryDate;
	
	//NPBS Interested Party - Yes
	@FindBy(xpath="//input[@id='main:isLenderNotedAsInterestedParty:isLenderNotedAsInterestedParty:0']")
	WebElement RadioNPBSYes;
	
	//NPBS Interested Party - No
	@FindBy(xpath="//input[@id='main:isLenderNotedAsInterestedParty:isLenderNotedAsInterestedParty:1']")
	WebElement RadioNPBSNo;
	
	//Popup Close Button
	@FindBy(xpath="//input[@class='closePopupButtonIcon']")
	WebElement PopupCloseButton;
	
	//Status Tab
	@FindBy(xpath="//div[@id = 'docReqChooserForm:docRelatedTo:j_id1169header:sortDiv']")
	WebElement StatusLink;
	
	//Constructor
	public ChecklistSettlement()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
				
		
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Check List");		
		return HeadSectionResult;
	}	
	
	//Select Non-Mandatory List
	public void NonMandatory() throws InterruptedException
	{
		funclib.DelayTime();
		CheckDefunctList.click();
		funclib.DelayTime();
		CheckMandateList.click();
	}
	
	//Function - Complete
	public void CompleteFunction() throws InterruptedException
	{
		String CompleteClickResult = funclib.HeadingSection(CompleteClick.getText(), "Complete");
		String CompleteType="Complete";	
		
		WebDriverWait wait = new WebDriverWait(driver, 25);
		Actions action = new Actions(driver);	
		
		//WebDriverWait wait = new WebDriverWait(driver.get(), 25);
		//Actions action = new Actions(driver.get());

		WebElement CompClick = wait.until(ExpectedConditions.elementToBeClickable(CompleteClick));
		
		if (CompleteClickResult .equals(CompleteType))
		{
			funclib.DelayTime();
			action.moveToElement(CompClick).doubleClick(CompClick).perform();				
			
			//Input Applicant Insurance Verification
			InputApplicantInsuranceVerify.clear();
			funclib.DelayTime();
			InputApplicantInsuranceVerify.sendKeys("Verified Successfully");
		
			//Capture Screenshot
			funclib.CaptureScreenShot();
				
			//Navigate Next Page
			funclib.DelayTime();
			NextClick.click();						
		}					
	}
	
	//Function - Image
	public void ImageFunction() throws InterruptedException
	{
		String ImageType="Image";
		
		WebDriverWait wait = new WebDriverWait(driver, 25);
		Actions action = new Actions(driver);	
		
		//WebDriverWait wait = new WebDriverWait(driver.get(), 25);
		//Actions action = new Actions(driver.get());
		
		String ImageClickResult = funclib.HeadingSection(ImageClick.getText(), "Image");
		WebElement ImgClick = wait.until(ExpectedConditions.elementToBeClickable(ImageClick));
		
		if (ImageClickResult .equals(ImageType))
		{
			funclib.DelayTime();
			action.moveToElement(ImgClick).doubleClick(ImgClick).perform();				
		
			//Click on Add Document Link
			funclib.DelayTime();
			AddDocClick.click();
			funclib.DelayTime();				
		 
			//Clicking on Select Link
			funclib.DelayTime();
			SelectLinkClick.click();
			funclib.DelayTime();
			
			//Click on Status Link
			StatusLink.click();
			funclib.DelayTime();
		
			//Checking all Checkboxes
			String CheckboxPath = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//input";
			String Summary = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[2]";
			String StatusCheck = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[3]//span";				
			
			List<WebElement> checkBoxes = driver.findElements(By.xpath(CheckboxPath));
			List<WebElement> SummaryChecks = driver.findElements(By.xpath(Summary));
			List<WebElement> StatusChecks = driver.findElements(By.xpath(StatusCheck));
			
			//List<WebElement> checkBoxes = driver.get().findElements(By.xpath(CheckboxPath));
			//List<WebElement> SummaryChecks = driver.get().findElements(By.xpath(Summary));
			//List<WebElement> StatusChecks = driver.get().findElements(By.xpath(StatusCheck));
			
			String OutStandingValue="Outstanding";				
			
			//CheckMark each
			System.out.println("Status Check Count:" + StatusChecks.size());
			for(int i=0;i<StatusChecks.size();i++)
			{					
				if(StatusChecks.get(i).getText() .equals(OutStandingValue))
				{
					System.out.println("Status:" + StatusChecks.get(i).getText());
					if(!checkBoxes.get(i).isSelected())
						checkBoxes.get(i).click();
					funclib.DelayTime();
				}
				else
				{
					System.out.println("Summary Check:" + SummaryChecks.get(i).getText());
					System.out.println("Status:" + StatusChecks.get(i).getText());
					System.out.println("Loop Counter: " +i);
				}
			}		     
			
			//Click on OK Button
			System.out.println("Status Check Count:" + StatusChecks.size());
			funclib.DelayTime();
			SelectOkClick.click();
			funclib.DelayTime();
			
			//Checking all Reference Textboxes
			String TextboxPath = "//tbody[contains(@id,'main:docRelatedTo:docRelatedTo:tb')]//input";
			List<WebElement> TextBoxes = driver.findElements(By.xpath(TextboxPath));
			//List<WebElement> TextBoxes = driver.get().findElements(By.xpath(TextboxPath));
			for(WebElement textbox: TextBoxes)
			{				        
				funclib.DelayTime();
				if(!textbox.isSelected())				    	
					textbox.sendKeys("Verified");				    				    	
			}
			
			//Checkbox on Verified Documents
			funclib.DelayTime();
			CheckboxVerify.click();
		 
			//Select Predominant Purpose
			funclib.DelayTime();
			String SelectIdentity= "Identification";
			funclib.DropdownListSelect(SelectIdentity, SelectIdentityType);
		 
			//Select Submission Process
			funclib.DelayTime();
			String SelectSubmission= "Upload";
			funclib.DropdownListSelect(SelectSubmission, SelectSubmissionType);
			
			//Upload File
			funclib.DelayTime();						
			UploadFile.sendKeys("C:\\Users\\abhishek.paspuleti\\eclipse-workspace\\Sample.pdf");				
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate Next Page
			funclib.DelayTime();
			NextClick.click();
			
			//Select Verification Status
			funclib.DelayTime();
			String SelectDocumentationVerify= "Verified";
			funclib.DropdownListSelect(SelectDocumentationVerify,SelectDocumentVerify);
		
			//Capture Screenshot
			funclib.CaptureScreenShot();
				
			//Navigate Next Page
			funclib.DelayTime();
			NextClick.click();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
		}
	}
	
	//Submission Position Image
	public void SubmissionPos() throws InterruptedException
	{
		//Complete Click - Refer to Assessor (Security)
		List<WebElement> CompleteAssessor=driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Refer to Assessor (Security)')]"));
		//List<WebElement> CompleteAssessor=driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Refer to Assessor (Security)')]"));
		
		//Complete Assessor
		if(!CompleteAssessor.isEmpty())
		{			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteAssessor.size());
							
			if(CompleteAssessor.size() >0)
			{
				for(int CompleteCounter=1;CompleteCounter<=CompleteAssessor.size();CompleteCounter++)
				{			
					funclib.DelayTime();
					CompleteFunction();					
				}
			}
		}
		
		
		// Complete - Funding Settlement
		List<WebElement> CompleteFunding=driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Funding')]"));
		//List<WebElement> CompleteFunding=driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Funding')]"));
		
		if(!CompleteFunding.isEmpty())
		{			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteFunding.size());
							
			if(CompleteFunding.size() >0)
			{
				for(int CompleteCounter=1;CompleteCounter<=CompleteFunding.size();CompleteCounter++)
				{			
					funclib.DelayTime();
					CompleteFunction();					
				}
			}
		}
		
		
		// Complete - Printing of Contracts
		List<WebElement> CompletePrintContract= driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Printing of Contracts')]"));
		//List<WebElement> CompletePrintContract= driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Printing of Contracts')]"));
		
		if(!CompletePrintContract.isEmpty())
		{			
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompletePrintContract.size());
							
			if(CompletePrintContract.size() >0)
			{
				for(int CompleteCounter=1;CompleteCounter<=CompletePrintContract.size();CompleteCounter++)
				{			
					funclib.DelayTime();
					CompleteFunction();					
				}
			}
		}
		
		
		//Image - Printing of Contracts
		List<WebElement> ImageLink=driver.findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Printing of Contracts')]"));
		//List<WebElement> ImageLink=driver.get().findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Printing of Contracts')]"));
		
		if(!ImageLink.isEmpty())
		{		
			// Count of 'Image' Text
			System.out.println("Image Count: " + ImageLink.size());
			
			if(ImageLink.size()>0)
			{
				funclib.DelayTime();
				ImageFunction();
			}			
		}
		
		//Image - Ready For Settlement
		List<WebElement> ImageSettlement=driver.findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Ready For Settlement')]"));
		//List<WebElement> ImageSettlement=driver.get().findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Ready For Settlement')]"));
		
		if(!ImageSettlement.isEmpty())
		{		
			// Count of 'Image' Text
			System.out.println("Image Count: " + ImageSettlement.size());
			
			if(ImageSettlement.size()>0)
			{
				funclib.DelayTime();
				ImageFunction();
			}			
		}
	}	
	
	
	//Submission Position Goto
	public void SubmissionPosGoTo(String InsuranceReq, String InsurancePolicy, String CompanyCode, String PolicyType, String PolicyNumber, String CoverAmount, String ExpiryDate, String NPBSInterest) throws InterruptedException
	{
		String GoToType="Goto";		
		
		String GoToClickResult = funclib.HeadingSection(GotoClick.getText(), "Goto");
		
		WebDriverWait wait = new WebDriverWait(driver, 25);
		Actions action = new Actions(driver);
		
		//WebDriverWait wait = new WebDriverWait(driver.get(), 25);
		//Actions action = new Actions(driver.get());
		
		WebElement GoClick = wait.until(ExpectedConditions.elementToBeClickable(GotoClick));
		funclib.DelayTime();
		
		//GoTo Click		
		java.util.List<WebElement> GoToLink=driver.findElements(By.xpath("//td/a[contains(text(),'Goto')]/../preceding-sibling::td/span[contains(text(),'Documents Returned')]"));
		//java.util.List<WebElement> GoToLink=driver.get().findElements(By.xpath("//td/a[contains(text(),'Goto')]/../preceding-sibling::td/span[contains(text(),'Documents Returned')]"));
		
		System.out.println("GoTo Count: " + GoToLink.size());
		
		
		for(int GoToCounter=1;GoToCounter<=GoToLink.size();GoToCounter++)
		{			
			
			if (GoToClickResult .equals(GoToType))
			{
				funclib.DelayTime();
				action.moveToElement(GoClick).doubleClick(GoClick).perform();
				
				// Switch to Frame using id
				driver.switchTo().frame("gotoIframe");
				//driver.get().switchTo().frame("gotoIframe");
			
				//Property Insurance Required
				funclib.DelayTime();
				
				String InsuranceRequired = InsuranceReq;		
				String InsuranceRequiredResult= funclib.SelOptionValue(RadioInsuranceRequiredYes, RadioInsuranceRequiredYes.getAttribute("value"),RadioInsuranceRequiredNo,RadioInsuranceRequiredNo.getAttribute("value"),InsuranceRequired);
				System.out.println("Insuranced Required:" + InsuranceRequiredResult);
				
				//Property Insurance Policy Type
				funclib.DelayTime();
				String InsurancePolicyType = InsurancePolicy;		
				String InsurancePolicyTypeResult= funclib.SelOptionValue(RadioInsuranceTypeYes, RadioInsuranceTypeYes.getAttribute("value"),RadioInsuranceTypeNo,RadioInsuranceTypeNo.getAttribute("value"),InsurancePolicyType);
				System.out.println("Insuranced Policy Type:" + InsurancePolicyTypeResult);
				
				//Select Insurance Company Code
				funclib.DelayTime();
				String SelInsuranceCompanyCode = CompanyCode;
				String SelectInsuranceCompanyCodeResult = funclib.DropdownListSelect(SelInsuranceCompanyCode, SelectInsuranceCompanyCode);
				System.out.println("Insuranced Company Code:" + SelectInsuranceCompanyCodeResult);
				
				//Select Policy Type
				funclib.DelayTime();
				String SelPolicyType = PolicyType;
				String SelectPolicyTypeResult = funclib.DropdownListSelect(SelPolicyType, SelectPolicyType);
				System.out.println("Policy Type:" + SelectPolicyTypeResult);				
				
				//Input Policy Number
				funclib.DelayTime();
				InputPolicyNumber.clear();
				funclib.DelayTime();
				InputPolicyNumber.sendKeys(PolicyNumber);
				System.out.println("Policy Number:" + PolicyNumber);
				
				//Input Coverage Amount
				funclib.DelayTime();
				InputCoverageAmount.clear();
				funclib.DelayTime();
				InputCoverageAmount.sendKeys(CoverAmount);
				System.out.println("Coverage Amount:" + CoverAmount);
				
				//Input Expiry Date
				funclib.DelayTime();
				InputExpiryDate.clear();
				funclib.DelayTime();
				InputExpiryDate.sendKeys(ExpiryDate);
				System.out.println("Expiry Date:" + ExpiryDate);
				
				//NPBS as an Interested Party
				funclib.DelayTime();
				String NPBSParty = NPBSInterest;		
				String NPBSInterestResult= funclib.SelOptionValue(RadioNPBSYes, RadioNPBSYes.getAttribute("value"),RadioNPBSNo,RadioNPBSNo.getAttribute("value"),NPBSParty);
				System.out.println("Insuranced Required:" + NPBSInterestResult);
				funclib.DelayTime();
		
				//Capture Screenshot
				funclib.CaptureScreenShot();
				
				//Navigate Next Page
				funclib.DelayTime();				
				NextClick.click();
				
				//Switching from IFrame to Normal Window
				driver.switchTo().defaultContent();
				//driver.get().switchTo().defaultContent();
				
				//Close Popup Button
				funclib.DelayTime();
				funclib.DelayTime();
				PopupCloseButton.click();
			}
			else
				break;
		}
				
				//Image - Printing Of Contracts			
				List<WebElement> ImagePrintContract=driver.findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Documents Returned')]"));
				//List<WebElement> ImagePrintContract=driver.get().findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Documents Returned')]"));
				funclib.DelayTime();
		
				if(!ImagePrintContract.isEmpty())
				{		
					// Count of 'Image' Text
					System.out.println("Image Count: " + ImagePrintContract.size());
			
					if(ImagePrintContract.size()>0)
					{
						funclib.DelayTime();
						ImageFunction();
					}		
				}						
	}
		
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
		
		funclib.DelayTime();		
	}
}