package org.lendfast.pages.securities;

import org.lendfast.base.ParentPage;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SecuritiesValuationDetails extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;	
										
	//Defining WebElements
	String today;
								
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Valuation details')]")
	WebElement HeadSection;
	
	//Input Order Number
	@FindBy(xpath="//input[@id='main:orderNumber:orderNumber']")
	WebElement InputOrderNumber;
	
	//Input Valuation Date
	@FindBy(xpath="//input[@id='main:valuationDate:valuationDateInputDate']")
	WebElement InputValuationDate;
	
	//Date Widget	
	@FindBy(xpath=".//*[@id='main:valuationDate:valuationDate']/tbody")
	WebElement ValuationDateWidget;
	
	//Input Valuer First Name
	@FindBy(xpath="//input[@id='main:valuerFirstName:valuerFirstName']")
	WebElement InputValuerFirstName;
	
	//Input Valuer Last Name
	@FindBy(xpath="//input[@id='main:valuerLastName:valuerLastName']")
	WebElement InputValuerLastName;
	
	//Input Valuer Firm
	@FindBy(xpath="//input[@id='main:valuerFirm:valuerFirm']")
	WebElement InputValuerFirm;
	
	//Input Zone Name
	@FindBy(xpath="//input[@id='main:zone:zone']")
	WebElement InputZone;
	
	//Land Value
	@FindBy(xpath="//input[@id='main:landValue:landValue']")
	WebElement InputLandValue;
	
	//Existing Improvements Value
	@FindBy(xpath="//input[@id='main:existingImprovements:existingImprovements']")
	WebElement InputExistingImprovementValue;
	
	//Insurance Replacement Value
	@FindBy(xpath="//input[@id='main:insuranceReplacementValue:insuranceReplacementValue']")
	WebElement InputInsuranceReplacementValue;
	
	//Valuation Valid From
	@FindBy(xpath="//input[@id='main:valuationValidFrom:valuationDateInputDate']")
	WebElement InputValuationValidFrom;
	
	@FindBy(xpath=".//*[@id='main:valuationValidFrom:valuationDate']/tbody")
	WebElement ValuationValidFromDateWidget;
	
	//Date of Inspection
	@FindBy(xpath="//input[@id='main:inspectionDate:valuationDateInputDate']")
	WebElement InputInspectionDate;
	
	@FindBy(xpath=".//*[@id='main:inspectionDate:valuationDate']/tbody")
	WebElement ValuationInspectionDateWidget;
	
	//Select Local Economy
	@FindBy(xpath="//select[@id='main:risk_LocalEconomy:risk_LocalEconomy']")
	WebElement SelectLocalEconomy;
	
	//Select Market Segment
	@FindBy(xpath="//select[@id='main:risk_MarketSegment:risk_MarketSegment']")
	WebElement SelectMarketSegment;
	
	//Select Market Volatility
	@FindBy(xpath="//select[@id='main:risk_MarketVolatility:risk_MarketVolatility']")
	WebElement SelectMarketVolatility;
	
	//Select Recent Market Direction
	@FindBy(xpath="//select[@id='main:risk_ReducedValue:risk_ReducedValue']")
	WebElement SelectMarketDirection;
	
	//Environmental
	@FindBy(xpath="//select[@id='main:risk_Environmental:risk_Environmental']")
	WebElement SelectEnvironmental;
	
	//Improvements
	@FindBy(xpath="//select[@id='main:risk_Improvements:risk_Improvements']")
	WebElement SelectImprovement;
	
	//Land
	@FindBy(xpath="//select[@id='main:risk_Land:risk_Land']")
	WebElement SelectLand;
	
	//Neighbourhood
	@FindBy(xpath="//select[@id='main:risk_LocationNeighbourhood:risk_LocationNeighbourhood']")
	WebElement SelectNeighbourhood;
	
	//Input Unfurnished Rental
	@FindBy(xpath="//input[@id='main:estimatedRentalAmount:estimatedRentalAmount']")
	WebElement InputRental;
	
	//Input Site Area
	@FindBy(xpath="//input[@id='main:siteArea:siteArea']")
	WebElement InputSiteArea;
	
	//Input Living Area
	@FindBy(xpath="//input[@id='main:livingArea:livingArea']")
	WebElement InputLivingArea;
	
	//Declaration - Radio Acceptable
	@FindBy(xpath="//input[@id='main:isAcceptable:isAcceptable:0']")
	WebElement RadioAcceptable;
	
	//Declaration - Radio UnAcceptable
	@FindBy(xpath="//input[@id='main:isAcceptable:isAcceptable:1']")
	WebElement RadioUnAcceptable;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
		
	//Constructor
	public SecuritiesValuationDetails()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
	
	//Get The Current Day
    private String getCurrentDay ()
    {
        //Create a Calendar Object
        Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
 
        //Get Current Day as a number
        int todayInt = calendar.get(Calendar.DAY_OF_MONTH);
        System.out.println("Today Int: " + todayInt +"\n");
 
        //Integer to String Conversion
        String todayStr = Integer.toString(todayInt);
        System.out.println("Today Str: " + todayStr + "\n");
 
        return todayStr;
    }
							
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Valuation details");		
		return HeadSectionResult;
	}
	
	//Credit Analysis - Input Order Number
	public void InputOrderNumberText(String OrderNumber) throws InterruptedException
	{
		//Input Order Number
		funclib.DelayTime();
		InputOrderNumber.clear();
		
		funclib.DelayTime();
		InputOrderNumber.sendKeys(OrderNumber);
		funclib.DelayTime();		
		
		System.out.println("Order Number: " + OrderNumber);	 
	}
	
	//Credit Analysis - Input Valuation Date
	public void InputValuationDateText() throws InterruptedException
	{
		//Input Valuation Date	
		funclib.DelayTime();
		InputValuationDate.click();
		
		funclib.DelayTime();
		
		today = getCurrentDay();	
		
		 List<WebElement> columns = ValuationDateWidget.findElements(By.tagName("td"));
		 
		 for (WebElement cell: columns) 
		 {
			 //Select Today's Date
			// System.out.println("Date:" +cell.getText());
	         if (cell.getText().equals(today)) 
	         {          	 	        	 
	        	 funclib.DelayTime();
	        	 cell.click();
	        	 
	        	 if(InputValuationDate.getText() .equals(cell.getText()))
		        	 break;	         
	         }	         
	     }
		
		funclib.DelayTime();	
	}
	
	//Credit Analysis - Input Valuer First Name
	public void InputValuerFirstNameText(String ValuerFirstName) throws InterruptedException
	{
		//Input Valuer First Name
		funclib.DelayTime();
		InputValuerFirstName.clear();
		
		funclib.DelayTime();
		InputValuerFirstName.sendKeys(ValuerFirstName);
		funclib.DelayTime();		
		
		System.out.println("Valuer First Name: " + ValuerFirstName);	 
	}
	
	//Credit Analysis - Input Valuer Last Name
	public void InputValuerLastNameText(String ValuerLastName) throws InterruptedException
	{
		//Input Valuer Last Name
		funclib.DelayTime();
		InputValuerLastName.clear();
			
		funclib.DelayTime();
		InputValuerLastName.sendKeys(ValuerLastName);
		funclib.DelayTime();		
			
		System.out.println("Valuer Last Name: " + ValuerLastName);	 
	}
	
	//Credit Analysis - Input Valuer Last Name
	public void InputValuerFirmText(String ValuerFirm) throws InterruptedException
	{
		//Input Valuer Firm
		funclib.DelayTime();
		InputValuerFirm.clear();
			
		funclib.DelayTime();
		InputValuerFirm.sendKeys(ValuerFirm);
		funclib.DelayTime();		
				
		System.out.println("Valuer Firm: " + ValuerFirm);	 
	}
	
	//Credit Analysis - Input Valuer Zone
	public void InputZoneText(String Zone) throws InterruptedException
	{
		//Input Valuer Zone
		funclib.DelayTime();
		InputZone.clear();
			
		funclib.DelayTime();
		InputZone.sendKeys(Zone);
		funclib.DelayTime();		
			
		System.out.println("Zone Name: " + Zone);	 
	}
	
	//Credit Analysis - Input Land Value
	public void InputLandValueText(String LandValue) throws InterruptedException
	{
		//Input Land Value
		funclib.DelayTime();
		InputLandValue.clear();
				
		funclib.DelayTime();
		InputLandValue.sendKeys(LandValue);
		funclib.DelayTime();		
			
		System.out.println("Land Value: " + LandValue);	 
	}
	
	//Credit Analysis - Existing Improvements
	public void InputExistingImprovementText(String ExistingImprovement) throws InterruptedException
	{
		//Input Existing Improvements Value
		funclib.DelayTime();
		InputExistingImprovementValue.clear();
				
		funclib.DelayTime();
		InputExistingImprovementValue.sendKeys(ExistingImprovement);
		funclib.DelayTime();		
				
		System.out.println("Existing Improvement Value: " + ExistingImprovement);	 
	}
	
	//Credit Analysis - Input Insurance Replacement Value
	public void InputInsuranceReplacementText(String InsuranceReplacement) throws InterruptedException
	{
		//Input Insurance Replacement Value
		funclib.DelayTime();
		InputInsuranceReplacementValue.clear();
				
		funclib.DelayTime();
		InputInsuranceReplacementValue.sendKeys(InsuranceReplacement);
		funclib.DelayTime();		
				
		System.out.println("Insurance Replacement Value: " + InsuranceReplacement);	 
	}
	
	//Credit Analysis - Input Valuation Valid From
	public void InputvaluationValidFromText() throws InterruptedException
	{
		//Input Valuation Valid From Value
		funclib.DelayTime();
		InputValuationValidFrom.click();
		
		funclib.DelayTime();
		
		today = getCurrentDay();	
		
		 List<WebElement> columns = ValuationValidFromDateWidget.findElements(By.tagName("td"));
		 
		 for (WebElement cell: columns) 
		 {
			 //Select Today's Date
			 //System.out.println("Date:" +cell.getText());
	         if (cell.getText().equals(today)) 
	         {        	 
	        	 funclib.DelayTime();
	        	 cell.click();
	        	 
	        	 if(InputValuationValidFrom.getText() .equals(cell.getText()))
	        		 break;
	         }
	     }
		
		funclib.DelayTime();			 
	}
	
	//Credit Analysis - Input Date Of Inspection Value
	public void InputDateOfInspectionText() throws InterruptedException
	{
		//Input Date of Inspection Value
		funclib.DelayTime();
		InputInspectionDate.click();
		
		funclib.DelayTime();
		
		today = getCurrentDay();	
		
		 List<WebElement> columns = ValuationInspectionDateWidget.findElements(By.tagName("td"));
		 
		 for (WebElement cell: columns) 
		 {
			 //Select Today's Date
			 //System.out.println("Date:" +cell.getText());
	         if (cell.getText().equals(today)) 
	         {        	 
	        	 funclib.DelayTime();
	        	 cell.click();
	        	 
	        	 if(InputInspectionDate.getText() .equals(cell.getText()))
	        		 break;
	         }
	     }
		
		funclib.DelayTime(); 
	}	
	
	//Credit Analysis - Select Local Economy
	public String SelectLocalEconomyType(String LocalEconomy)
	{
		String SelectOption = LocalEconomy;
		String SelectLocalEconomyResult = funclib.DropdownListSelect(SelectOption, SelectLocalEconomy);
		return SelectLocalEconomyResult;
	}
	
	//Credit Analysis - Select Market Segment
	public String SelectMarketSegmentType(String MarketSegment)
	{
		String SelectOption = MarketSegment;
		String SelectMarketSegmentResult = funclib.DropdownListSelect(SelectOption, SelectMarketSegment);
		return SelectMarketSegmentResult;
	}
	
	//Credit Analysis - Select Market Volatility
	public String SelectMarketVolatilityType(String MarketVolatility)
	{
		String SelectOption = MarketVolatility;
		String SelectMarketVolatilityResult = funclib.DropdownListSelect(SelectOption, SelectMarketVolatility);
		return SelectMarketVolatilityResult;
	}
	
	//Credit Analysis - Select Market Direction
	public String SelectMarketDirectionType(String MarketDirection)
	{
		String SelectOption = MarketDirection;
		String SelectMarketDirectionResult = funclib.DropdownListSelect(SelectOption, SelectMarketDirection);
		return SelectMarketDirectionResult;
	}
	
	//Credit Analysis - Select Environmental
	public String SelectEnvironmentalType(String Environmental)
	{
		String SelectOption = Environmental;
		String SelectEnvironmentalResult = funclib.DropdownListSelect(SelectOption, SelectEnvironmental);
		return SelectEnvironmentalResult;
	}
	
	//Credit Analysis - Select Improvements
	public String SelectImprovementsType(String Improvements)
	{
		String SelectOption = Improvements;
		String SelectImprovementsResult = funclib.DropdownListSelect(SelectOption, SelectImprovement);
		return SelectImprovementsResult;
	}
	
	//Credit Analysis - Select Land
	public String SelectLandType(String LandType)
	{
		String SelectOption = LandType;
		String SelectLandTypeResult = funclib.DropdownListSelect(SelectOption, SelectLand);
		return SelectLandTypeResult;
	}
	
	//Credit Analysis - Select Neighbourhood
	public String SelectNeighbourhoodType(String Neighbourhood)
	{
		String SelectOption = Neighbourhood;
		String SelectNeighbourhoodResult = funclib.DropdownListSelect(SelectOption, SelectNeighbourhood);
		return SelectNeighbourhoodResult;
	}
	
	//Credit Analysis - Input Unfurnished Rental Value
	public void InputUnfurnishedRentalText(String UnfurnishedRentalValue) throws InterruptedException
	{
		//Input Unfurnished Rental Value
		funclib.DelayTime();
		InputRental.clear();
				
		funclib.DelayTime();
		InputRental.sendKeys(UnfurnishedRentalValue);
		funclib.DelayTime();		
						
		System.out.println("Unfurnished Rental Value: " + UnfurnishedRentalValue);	 
	}
	
	//Credit Analysis - Input Site Area
	public void InputSiteAreaText(String SiteArea) throws InterruptedException
	{
		//Input Site Area Value
		funclib.DelayTime();
		InputSiteArea.clear();
				
		funclib.DelayTime();
		InputSiteArea.sendKeys(SiteArea);
		funclib.DelayTime();		
						
		System.out.println("Site Area Value: " + SiteArea);	 
	}
	
	//Credit Analysis - Input Date Of Inspection Value
	public void InputLivingAreaText(String LivingArea) throws InterruptedException
	{
		//Input Living Area Value
		funclib.DelayTime();
		InputLivingArea.clear();
				
		funclib.DelayTime();
		InputLivingArea.sendKeys(LivingArea);
		funclib.DelayTime();		
						
		System.out.println("Living Area Value: " + LivingArea);	 
	}
	
	//Select Declaration Type	
	public String SelDeclarationType(String Declare) throws InterruptedException
	{		
		String OptionValue = Declare;		
		String DeclarationResult= funclib.SelOptionValue(RadioAcceptable, RadioAcceptable.getAttribute("value"),RadioUnAcceptable,RadioUnAcceptable.getAttribute("value"),OptionValue);
		System.out.println("Declaration Type: " + DeclarationResult);
		return DeclarationResult;		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}

}
