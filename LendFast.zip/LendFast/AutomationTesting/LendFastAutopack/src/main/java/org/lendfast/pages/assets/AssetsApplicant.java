package org.lendfast.pages.assets;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AssetsApplicant extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
				
	//Defining WebElements
				
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Assets')]")
	WebElement HeadSection;
	
	//Select Purchase Description
	@FindBy(xpath="//select[@id='main:assettype:assettype']")
	WebElement SelectAssetType;
	
	//Define Add Asset Button
	@FindBy(xpath="//input[@id='main:addBtn']")
	WebElement AddAssetClick;
	
	//Select Modify Link
	@FindBy(linkText="Modify")
	WebElement ModifyClick;
	
	//Constructor
	public AssetsApplicant()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Assets");		
		return HeadSectionResult;
	}
	
	//Select Purchase Description
	public String SelAssetType(String AssetType)
	{
		String SelectOption = AssetType;
		String SelAssetType = funclib.DropdownListSelect(SelectOption, SelectAssetType);
		return SelAssetType;		
	}
	
	//Click on Add Asset
	public void AddAssetBut() throws InterruptedException
	{		
		funclib.DelayTime();
		AddAssetClick.click();	
	}
	
	//Click on Modify Link
	public void ModifyLink() throws InterruptedException
	{		
		funclib.DelayTime();
		ModifyClick.click();	
	}
	
}
