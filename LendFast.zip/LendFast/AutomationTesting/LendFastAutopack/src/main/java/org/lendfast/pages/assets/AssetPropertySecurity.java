package org.lendfast.pages.assets;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AssetPropertySecurity extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
							
	//Defining WebElements
							
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Property Security')]")
	WebElement HeadSection;
	
	//Proposed Mortgage Type -  FIRST
	@FindBy(xpath="//input[@id='main:assetmortgageType:assetmortgageType:0']")
	WebElement RadioMortgageFirst;
	
	//Proposed Mortgage Type -  FOLLOWING
	@FindBy(xpath="//input[@id='main:assetmortgageType:assetmortgageType:1']")
	WebElement RadioMortgageFollowing;
	
	//Input Rates Notice UnImproved Value
	@FindBy(xpath="//input[@id='main:assetrateableValue:assetrateableValue']")
	WebElement InputRateValue;
	
	//Select Property Zone
	@FindBy(xpath="//select[@id='main:assetpropertyZone:assetpropertyZone']")
	WebElement SelectPropertyZone;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public AssetPropertySecurity()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Property Security");		
		return HeadSectionResult;
	}
	
	//Select Proposed Mortgage Type
	public String SelMortgageType(String MortgageType) throws InterruptedException
	{		
		String OptionValue = MortgageType;		
		String MortgageResult= funclib.SelOptionValue(RadioMortgageFirst, RadioMortgageFirst.getAttribute("value"),RadioMortgageFollowing,RadioMortgageFollowing.getAttribute("value"),OptionValue);	
		return MortgageResult;		
	}
	
	//Select Property Zone
	public String SelPropertyZone(String PropertyZone)
	{
		String SelectOption = PropertyZone;
		String SelZone = funclib.DropdownListSelect(SelectOption, SelectPropertyZone);
		return SelZone;		
	}
	
	//Input Rates Notice/UnImproved Value
	public void InputRateValue(String RateValue) throws InterruptedException
	{
		InputRateValue.clear();
		funclib.DelayTime();	
		InputRateValue.sendKeys(RateValue);
		funclib.DelayTime();
	}
	
	//Click on Next Link
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}	
	
}
