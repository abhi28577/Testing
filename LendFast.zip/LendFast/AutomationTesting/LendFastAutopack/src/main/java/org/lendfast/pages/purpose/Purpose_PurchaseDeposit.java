package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_PurchaseDeposit extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;		
						
	//Defining WebElements
				
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Purchase Real Estate - Deposits')]")
	WebElement HeadSection;
	
	//Define Add Deposit Button
	@FindBy(xpath="//input[@id='main:_addDepositBtn:addDepositBtn']")
	WebElement AddDepositClick;
	
	//Constructor
	public Purpose_PurchaseDeposit()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
	
	
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Purchase Real Estate - Deposits");		
		return HeadSectionResult;
	}
	
	
	//Navigate to Add Deposit Page
	public void AddDepositPage() throws InterruptedException
	{		
		funclib.DelayTime();
		AddDepositClick.click();	
	}
}
