package org.lendfast.pages.extraproducts;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ExtraProductsHomePage extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
					
	//Defining WebElements
				
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Service Nomination')]")
	WebElement HeadSection;
	
	//Nominate Person - Yes
	@FindBy(xpath="//input[@id='main:apphasServiceNom:apphasServiceNom:0']")
	WebElement RadioNominateYes;
		
	//Nominate Person - No
	@FindBy(xpath="//input[@id='main:apphasServiceNom:apphasServiceNom:1']")
	WebElement RadioNominateNo;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public ExtraProductsHomePage()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
				
		
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Service Nomination");		
		return HeadSectionResult;
	}
	
	//Select Nominate Person - Yes/No
	public String SelNominatePerson(String NominatePerson) throws InterruptedException
	{		
		String OptionValue = NominatePerson;		
		String NominatePersonResult= funclib.SelOptionValue(RadioNominateYes, RadioNominateYes.getAttribute("value"),RadioNominateNo,RadioNominateNo.getAttribute("value"),OptionValue);	
		return NominatePersonResult;		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
