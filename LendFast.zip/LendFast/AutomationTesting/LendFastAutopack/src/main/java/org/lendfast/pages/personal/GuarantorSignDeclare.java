package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GuarantorSignDeclare extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
			
	//Defining WebElements
			
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Signed Guarantor Consent for Guarantor')]")
	WebElement HeadSection;
	
	//Party Declaration - Yes
	@FindBy(xpath="//input[@id='main:partysignedDec:partysignedDec:0']")
	WebElement RadioPartySignYes;
	
	//Party Declaration - No
	@FindBy(xpath="//input[@id='main:partysignedDec:partysignedDec:1']")
	WebElement RadioPartySignNo;
	
	//Guarantor Declaration - Yes
	@FindBy(xpath="//input[@id='main:partyisConsentImaged:partyisConsentImaged:0']")
	WebElement RadioGuarantorSignYes;
		
	//Guarantor Declaration - No
	@FindBy(xpath="//input[@id='main:partyisConsentImaged:partyisConsentImaged:1']")
	WebElement RadioGuarantorSignNo;
	
	//Select Identification Type
	@FindBy(xpath="//select[@id='main:partyidType:partyidType']")
	WebElement SelectIdentityType;
	
	//Select State
	@FindBy(xpath="//select[@id='main:partylicenceState:partylicenceStateSelect']")
	WebElement SelectState;
	
	//Input Identification Number
	@FindBy(xpath="//input[@id='main:partyidNum:partyidNum']")
	WebElement IdentificationNumber;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public GuarantorSignDeclare()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
				
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Signed Guarantor Consent for Guarantor");
		
		return HeadSectionResult;
	}
	
	//Select Guarantor Declaration
	public String SelDeclarationType(String PartySigned) throws InterruptedException
	{		
		String OptionValue = PartySigned;		
		String OptionResult= funclib.SelOptionValue(RadioPartySignYes, RadioPartySignYes.getAttribute("value"),RadioPartySignNo,RadioPartySignNo.getAttribute("value"),OptionValue);	
		return OptionResult;		
	}
	
	//Select Guarantor Consent Form
	public String SelConsentForm(String Consent) throws InterruptedException
	{		
		String OptionValue = Consent;		
		String OptionResult= funclib.SelOptionValue(RadioGuarantorSignYes, RadioGuarantorSignYes.getAttribute("value"),RadioGuarantorSignNo,RadioGuarantorSignNo.getAttribute("value"),OptionValue);	
		return OptionResult;		
	}
		
	//Select Identification Type
	public String SelIdentityType(String IdentityType)
	{
		String SelectOption = IdentityType;
		String SelIdentity = funclib.DropdownListSelect(SelectOption, SelectIdentityType);
		return SelIdentity;		
	}
	
	//Select State
	public String SelStateType(String StateType)
	{
		String SelectOption = StateType;
		String SelState = funclib.DropdownListSelect(SelectOption, SelectState);
		return SelState;		
	}
	
	//Input Identification Number
	public void InputIdentificationNumber(String IdentityNumber) throws InterruptedException
	{
		funclib.DelayTime();
		IdentificationNumber.clear();
		funclib.DelayTime();
		IdentificationNumber.sendKeys(IdentityNumber);
		funclib.DelayTime();
	}
	
	public void NextPage() throws InterruptedException
	{
		//Navigate to Next Page
		funclib.DelayTime();
		NextClick.click();	
	}

}
