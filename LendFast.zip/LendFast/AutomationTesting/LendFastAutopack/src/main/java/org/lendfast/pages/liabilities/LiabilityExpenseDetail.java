package org.lendfast.pages.liabilities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LiabilityExpenseDetail extends ParentPage
{
	// Initialize Functions
		CommonFuncLib funclib;
		String Liability1="1";
		String Liability2="2";
		String Liability3="3";
		String Liability4="4";
		String Liability5="5";
		String Liability6="6";
		String Liability7="7";
		String Liability8="8";
		String Liability9="9";
		String Liability10="10";
		
					
	//Defining WebElements
				
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Liabilities and Expenses')]")
	WebElement HeadSection;
	
	//Define Heading Expenses Section
	@FindBy(xpath="//div[contains(text(),'General Living Expenses Details')]")
	WebElement HeadExpenseSection;
	
	//Select Expense Type
	@FindBy(xpath="//select[@id='main:expenseType:expenseType']")
	WebElement SelectExpenseType;
		
	//Define Add Expense Button
	@FindBy(xpath="//input[@id='main:addAppExpenseBtn']")
	WebElement AddExpenseClick;
	
	//Input General Living Expenses
	@FindBy(xpath="//input[@id='main:livingCostamount:livingCostamount']")
	WebElement InputCostAmount;
	
	//Select Frequency Type
	@FindBy(xpath="//select[@id='main:livingCostFrequency:repaymentFrequency']")
	WebElement SelectFrequencyType;
	
	//Party Type1
	@FindBy(xpath="//td[@id='main:linkedPartiesList:0:j_id819']")
	WebElement Party1;
	
	//Approve Liable1
	@FindBy(xpath="//a[@id='main:linkedPartiesList:0:toggleOwnershipBtn']")
	WebElement Liable1;
	
	
	//Party Type2
	@FindBy(xpath="//td[@id='main:linkedPartiesList:1:j_id819']")
	WebElement Party2;	
	
	//Approve Liable2
	@FindBy(xpath="//a[@id='main:linkedPartiesList:1:toggleOwnershipBtn']")
	WebElement Liable2;
	
	
	//Party Type3
	@FindBy(xpath="//td[@id='main:linkedPartiesList:2:j_id819']")
	WebElement Party3;
		
	//Approve Liable3
	@FindBy(xpath="//a[@id='main:linkedPartiesList:2:toggleOwnershipBtn']")
	WebElement Liable3;
		
		
	//Party Type4
	@FindBy(xpath="//td[@id='main:linkedPartiesList:3:j_id819']")
	WebElement Party4;	
		
	//Approve Liable4
	@FindBy(xpath="//a[@id='main:linkedPartiesList:3:toggleOwnershipBtn']")
	WebElement Liable4;
	
	//Party Type5
	@FindBy(xpath="//td[@id='main:linkedPartiesList:4:j_id819']")
	WebElement Party5;	
			
	//Approve Liable5
	@FindBy(xpath="//a[@id='main:linkedPartiesList:4:toggleOwnershipBtn']")
	WebElement Liable5;
	
	//Party Type6
	@FindBy(xpath="//td[@id='main:linkedPartiesList:5:j_id819']")
	WebElement Party6;	
			
	//Approve Liable6
	@FindBy(xpath="//a[@id='main:linkedPartiesList:5:toggleOwnershipBtn']")
	WebElement Liable6;
	
	
	//Party Type7
	@FindBy(xpath="//td[@id='main:linkedPartiesList:6:j_id819']")
	WebElement Party7;	
			
	//Approve Liable7
	@FindBy(xpath="//a[@id='main:linkedPartiesList:6:toggleOwnershipBtn']")
	WebElement Liable7;
	
	//Party Type8
	@FindBy(xpath="//td[@id='main:linkedPartiesList:7:j_id819']")
	WebElement Party8;	
			
	//Approve Liable8
	@FindBy(xpath="//a[@id='main:linkedPartiesList:7:toggleOwnershipBtn']")
	WebElement Liable8;
		
	//Party Type9
	@FindBy(xpath="//td[@id='main:linkedPartiesList:8:j_id819']")
	WebElement Party9;	
		
	//Approve Liable9
	@FindBy(xpath="//a[@id='main:linkedPartiesList:8:toggleOwnershipBtn']")
	WebElement Liable9;
		
	//Party Type10
	@FindBy(xpath="//td[@id='main:linkedPartiesList:9:j_id819']")
	WebElement Party10;	
		
	//Approve Liable10
	@FindBy(xpath="//a[@id='main:linkedPartiesList:9:toggleOwnershipBtn']")
	WebElement Liable10;	
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public LiabilityExpenseDetail()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Liabilities and Expenses");		
		return HeadSectionResult;
	}
	
	//Capturing Head Section
	public String CaptureExpenseHeadSection()
	{
		String HeadExpenseSectionResult = funclib.HeadingSection(HeadExpenseSection.getText(), "General Living Expenses Details");		
		return HeadExpenseSectionResult;
	}
	
	//Select Add Expense Type
	public String SelExpenseType(String ExpenseType)
	{
		String SelectOption = ExpenseType;
		String SelExpenseType = funclib.DropdownListSelect(SelectOption, SelectExpenseType);
		return SelExpenseType;		
	}
	
	//Click on Add Expense Link
	public void AddExpense() throws InterruptedException
	{		
		funclib.DelayTime();
		AddExpenseClick.click();	
	}
		
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
	
	public void GeneralLivingExpense(String Liability, String LivingExpense, String LivingPayFreq, String PartyType, String IsLiable) throws InterruptedException
	{		
		
		//Initialize Is Liable Option
		String Liable = "Yes";		
		
		//Validate PartyType and Liability against each PartyType		
		
		//Input General Living Expense			
		InputCostAmount.clear();
		InputCostAmount.sendKeys(LivingExpense);
		funclib.DelayTime();
		
		//Select Frequency Type
		String SelectOption = LivingPayFreq;
		funclib.DropdownListSelect(SelectOption, SelectFrequencyType);
		funclib.DelayTime();
		
		//Expenses for Party Type
		if(Liable .equals(IsLiable))
		{
			System.out.println("Party Type Matches:" + PartyType);
			
			//Click on Is Liable? Option	
			
			if(Liability .equals(Liability1))
				Liable1.click();
			
			if(Liability .equals(Liability2))
				Liable2.click();
			
			if(Liability .equals(Liability3))
				Liable3.click();
			
			if(Liability .equals(Liability4))
				Liable4.click();
			
			if(Liability .equals(Liability5))
				Liable5.click();
			
			if(Liability .equals(Liability6))
				Liable6.click();
			
			if(Liability .equals(Liability7))
				Liable7.click();
			
			if(Liability .equals(Liability8))
				Liable8.click();
			
			if(Liability .equals(Liability9))
				Liable9.click();
			
			if(Liability .equals(Liability10))
				Liable10.click();
		}
		else
			System.out.println("Party Type Matches:" + PartyType);
					
			
			//Navigate to Next Page			
			funclib.DelayTime();
			NextClick.click();			
				
	}		
}


