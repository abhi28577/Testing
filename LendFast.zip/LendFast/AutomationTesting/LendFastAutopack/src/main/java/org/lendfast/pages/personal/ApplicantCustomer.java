package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.utils.PageWaitUtil;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicantCustomer extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
	PageWaitUtil pageload;
	
	//Defining WebElements
	
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Existing Customer')]")
	WebElement HeadSection;
	
	//Define Radio Button Options (Party Type - Applicant)
	@FindBy(xpath="//input[@id='main:partytype:partytype:0']")
	WebElement RadioPartyApplicant;
			
	//Define Radio Button Options (Party Type - Guarantor)
	@FindBy(xpath="//input[@id='main:partytype:partytype:1']")
	WebElement RadioPartyGuarantor;
	
	//Define Radio Button Options (Applicant - Individual)
	@FindBy(xpath="//input[@id='main:partysubType:partysubType:0']")
	WebElement RadioAppIndividual;
				
	//Define Radio Button Options (Applicant - Company/Association)
	@FindBy(xpath="//input[@id='main:partysubType:partysubType:1']")
	WebElement RadioAppCompany;
	
	//Define Radio Button Options (Existing NPBS - Yes)
	@FindBy(xpath="//input[@id='main:partyisExistingCustomer:partyisExistingCustomer:0']")
	WebElement RadioNPBSYes;
					
	//Define Radio Button Options (Existing NPBS - No)
	@FindBy(xpath="//input[@id='main:partyisExistingCustomer:partyisExistingCustomer:1']")
	WebElement RadioNPBSNo;
	
	//Define Account/Customer Number
	@FindBy(xpath="//input[@id='main:searchid:searchid']")
	WebElement AccountNumber;
	
	//Define Search Account/Customer Number
	@FindBy(xpath="//input[@id='main:searchBtn:searchBtn']")
	WebElement SearchAccount;
	
	//define Select Link against Account/Customer Number
	@FindBy(xpath="//a[@id='main:partyresultList:0:Select']")
	WebElement CustomerSelectedLink;	
	
	
	//Constructor
	public ApplicantCustomer()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
		pageload = new PageWaitUtil();
	}
		
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Existing Customer");
		
		return HeadSectionResult;
	}
	
	//Select Party Type
	public String SelPartyType(String PartyType) throws InterruptedException
	{		
		String OptionValue = PartyType;		
		String PartyResult= funclib.SelOptionValue(RadioPartyApplicant, RadioPartyApplicant.getAttribute("value"),RadioPartyGuarantor,RadioPartyGuarantor.getAttribute("value"),OptionValue);	
		return PartyResult;		
	}
	
	//Select Applicant Type
	public String SelApplicantType(String ApplicantType) throws InterruptedException
	{		
		String OptionValue = ApplicantType;		
		String ApplicantResult= funclib.SelOptionValue(RadioAppIndividual, RadioAppIndividual.getAttribute("value"),RadioAppCompany,RadioAppCompany.getAttribute("value"),OptionValue);	
		return ApplicantResult;		
	}
		
	//NPBS Existing Customer???
	public String SelNPBSCustomerType(String ExistNPBS) throws InterruptedException
	{		
		String OptionValue = ExistNPBS;		
		String CustomerResult= funclib.SelOptionValue(RadioNPBSYes, RadioNPBSYes.getAttribute("value"),RadioNPBSNo,RadioNPBSNo.getAttribute("value"),OptionValue);	
		return CustomerResult;		
	}	
	
	//Input Account Number/Customer Number
	public void InputAccountNumber(String CustomerNumber) throws InterruptedException
	{
		AccountNumber.sendKeys(CustomerNumber);
		funclib.DelayTime();
		
		//Click on Search Button
		SearchAccount.click();
		//pageload.waitForPageLoaded();
		Thread.sleep(4000);
	}
	
	//Selecting Customer using Select Link
	public void SelectCustomerNumber() throws InterruptedException
	{
		funclib.DelayTime();			
		CustomerSelectedLink.click();			
		pageload.waitForPageLoaded();		
	}

}
