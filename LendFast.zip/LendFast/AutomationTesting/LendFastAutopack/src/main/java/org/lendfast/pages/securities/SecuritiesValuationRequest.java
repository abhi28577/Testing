package org.lendfast.pages.securities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SecuritiesValuationRequest extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;	
								
	//Defining WebElements
							
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Valuation Request')]")
	WebElement HeadSection;
	
	//Select Preferred Contact Method
	@FindBy(xpath="//select[@id='main:accessPreferredContactMethod:accessPreferredContactMethod']")
	WebElement SelectContactMethod;
	
	//Input Mobile Number
	@FindBy(xpath="//input[@id='main:accessMobileNumber:number:accessMobileNumberPhoneNumber']")
	WebElement InputMobileNumber;
	
	//Click on Status Link
	@FindBy(xpath="//td[contains(text(),'Manual Valuation')]/following-sibling::td[7]/a[contains(text(),'Status')]")
	WebElement StatusClick;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public SecuritiesValuationRequest()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
						
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Valuation Request");		
		return HeadSectionResult;
	}
	
	//Credit Analysis - Valuation Request - Preferred Contact Method
	public String SelectPreferredMethodType(String PreferredMethod)
	{
		String SelectOption = PreferredMethod;
		String SelectPreferredResult = funclib.DropdownListSelect(SelectOption, SelectContactMethod);
		return SelectPreferredResult;
	}
	
	//Credit Analysis - Input Mobile Number
	public void InputMobileNumText(String MobileNumber) throws InterruptedException
	{
		//Input Mobile Number
		funclib.DelayTime();
		InputMobileNumber.clear();
		
		funclib.DelayTime();
		InputMobileNumber.sendKeys(MobileNumber);
		funclib.DelayTime();	
		
		System.out.println("Mobile Number:" + MobileNumber);		 
	}
	
	//Credit Analysis - Click On Status Link against Manual Valuation
	public void StatusLinkClick() throws InterruptedException
	{
		//Click on Status Link
		funclib.DelayTime();
		StatusClick.click();
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}

}
