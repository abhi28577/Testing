package org.lendfast.pages.productselection;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductLoanInfo extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
						
	//Defining WebElements
					
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Loan Information')]")
	WebElement HeadSection;
	
	//Loan Duration - Term
	@FindBy(xpath="//input[@id='main:loanDuration:loanDuration:0']")
	WebElement RadioLoanDurationTerm;
		
	//Loan Duration - Revolving
	@FindBy(xpath="//input[@id='main:loanDuration:loanDuration:1']")
	WebElement RadioLoanDurationRevolve;
	
	//Input Loan Tenure - Years
	@FindBy(xpath="//input[@id='main:loanComploanTermYearsonFirstScreen:loanComploanTermYearsonFirstScreen']")
	WebElement InputLoanTenureYears;
	
	//Input Loan Tenure - Months
	@FindBy(xpath="//input[@id='main:loanComploanTermMonthsonFirstScreen:loanComploanTermMonthsonFirstScreen']")
	WebElement InputLoanTenureMonths;
	
	//Interest Type - Fixed
	@FindBy(xpath="//input[@id='main:loanCompinterestTypeonFirstScreen:loanCompinterestTypeonFirstScreen:0']")
	WebElement RadioInterestFixed;
			
	//Interest Type - Variable
	@FindBy(xpath="//input[@id='main:loanCompinterestTypeonFirstScreen:loanCompinterestTypeonFirstScreen:1']")
	WebElement RadioInterestVariable;
	
	//Repayment Method  - Interest Only
	@FindBy(xpath="//input[@id='main:loanComprepaymentMethodonFirstScreen:loanComprepaymentMethodonFirstScreen:0']")
	WebElement RadioRepaymentInterest;
	
	//Repayment Method - Principal & Interest
	@FindBy(xpath="//input[@id='main:loanComprepaymentMethodonFirstScreen:loanComprepaymentMethodonFirstScreen:1']")
	WebElement RadioRepaymentPrincipal;
	
	//Funds for Investment Purpose - True
	@FindBy(xpath="//input[@id='main:loanCompforInvestmentPurposesonFirstScreen:loanCompforInvestmentPurposesonFirstScreen:0']")
	WebElement RadioInvestmentPurposeYes;
	
	//Funds for Investment Purpose - False
	@FindBy(xpath="//input[@id='main:loanCompforInvestmentPurposesonFirstScreen:loanCompforInvestmentPurposesonFirstScreen:1']")
	WebElement RadioInvestmentPurposeNo;
	
	//Select Predominant Purpose
	@FindBy(xpath="//select[@id='main:apppurposeCode:apppurposeCode']")
	WebElement SelectPurposeType;
	
	//Select Amount for Product
	@FindBy(xpath="//select[@id='main:allocation:allocation']")
	WebElement SelectProductAmount;
	
	//Input Specified Amount
	@FindBy(xpath="//input[@id='main:allocatedAmount:allocatedAmount']")
	WebElement InputSpecifiedAmount;
	
	//Package
	@FindBy(xpath="//select[@id='main:package:package']")
	WebElement SelectPackage;
	
	//Campaign
	@FindBy(xpath="//select[@id='main:campaignDef:campaign']")
	WebElement SelectCampaign;
	
	//Discretionary Margin
	@FindBy(xpath="//input[@id='main:initialDiscretionaryMarginManual:initialDiscretionaryMarginManual']")
	WebElement InputDiscretionaryMargin;
	
	//Discretionary Subsequent
	@FindBy(xpath="//input[@id='main:subsequentDiscretionaryMarginManual:subsequentDiscretionaryMarginManual']")
	WebElement InputDiscretionarySubsequent;
	
	//Discretionary Reason
	@FindBy(xpath="//select[@id='main:initialDiscretionaryReason:initialDiscretionaryReason']")
	WebElement SelectDiscretionaryReason;
	
	//Offset Facility - Yes
	@FindBy(xpath="//input[@id='main:loanComphasOffSetAccount:loanComphasOffSetAccount:0']")
	WebElement RadioOffsetYes;
			
	//Offset Facility - No
	@FindBy(xpath="//input[@id='main:loanComphasOffSetAccount:loanComphasOffSetAccount:1']")
	WebElement RadioOffsetNo;
	
	//Show Products Button/Link
	@FindBy(xpath="//input[@id='main:showProductsBtn']")
	WebElement ShowProductClick;
	
	//Select Product Type
	@FindBy(xpath="//select[@id='main:loanCompproductType:loanCompproductType']")
	WebElement SelectProductType;
	
	//Repayment Frequency 
	@FindBy(xpath="//select[@id='main:repaymentFrequency:repaymentFrequency']")
	WebElement SelectRepaymentFrequency;
	
	//First Repayment Day
	@FindBy(xpath="//select[@id='main:repaymentDay:repaymentDay']")
	WebElement SelectFirstRepaymentDay;
	
	//Repayment Method
	@FindBy(xpath="//select[@id='main:repaymentMethod:repaymentMethod']")
	WebElement SelectRepaymentMethod;
	
	//Add Product Link
	@FindBy(xpath="//input[@id='main:loanCompAddBtn']")
	WebElement AddProductClick;
	
	//Define Back Button
	@FindBy(xpath="//input[@id='main:back']")
	WebElement BackClick;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public ProductLoanInfo()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
				
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Loan Information");		
		return HeadSectionResult;
	}
	
	//Select Duration
	public String SelDuration(String Duration) throws InterruptedException
	{		
		String OptionValue = Duration;		
		String DurationResult= funclib.SelOptionValue(RadioLoanDurationTerm, RadioLoanDurationTerm.getAttribute("value"),RadioLoanDurationRevolve,RadioLoanDurationRevolve.getAttribute("value"),OptionValue);	
		return DurationResult;		
	}
	
	//Input Loan Term - Years
	public void InputLoanTermYears(String LoanTermY) throws InterruptedException
	{
		InputLoanTenureYears.clear();
		InputLoanTenureYears.sendKeys(LoanTermY);
		funclib.DelayTime();		
	}
	
	//Input Loan Term - Months
	public void InputLoanTermMonths(String LoanTermM) throws InterruptedException
	{
		InputLoanTenureMonths.clear();
		InputLoanTenureMonths.sendKeys(LoanTermM);
		funclib.DelayTime();		
	}
	
	//Select Interest Type
	public String SelInterestType(String InterestType) throws InterruptedException
	{		
		String OptionValue = InterestType;		
		String InterestResult= funclib.SelOptionValue(RadioInterestFixed, RadioInterestFixed.getAttribute("value"),RadioInterestVariable,RadioInterestVariable.getAttribute("value"),OptionValue);	
		return InterestResult;		
	}
	
	//Select RePayment Method
	public String SelRepaymentMethod(String Repayment) throws InterruptedException
	{		
		String OptionValue = Repayment;		
		String RepaymentResult= funclib.SelOptionValue(RadioRepaymentInterest, RadioRepaymentInterest.getAttribute("value"),RadioRepaymentPrincipal,RadioRepaymentPrincipal.getAttribute("value"),OptionValue);	
		return RepaymentResult;		
	}
	
	//Select Investment Purpose
	public String SelInvestmentPurpose(String Investment) throws InterruptedException
	{		
		String OptionValue = Investment;		
		String PredominantResult= funclib.SelOptionValue(RadioInvestmentPurposeYes, RadioInvestmentPurposeYes.getAttribute("value"),RadioInvestmentPurposeNo,RadioInvestmentPurposeNo.getAttribute("value"),OptionValue);	
		return PredominantResult;		
	}
	
	//Select Predominant Purpose
	public String SelPredominant(String Predominant)
	{
		String SelectOption = Predominant;
		String SelPredominantType = funclib.DropdownListSelect(SelectOption, SelectPurposeType);
		return SelPredominantType;		
	}
	
	//Select Product Amount
	public String SelProductAmount(String ProductAmount)
	{
		String SelectOption = ProductAmount;
		String SelProductAmount = funclib.DropdownListSelect(SelectOption, SelectProductAmount);
		return SelProductAmount;		
	}
	
	//Input Specified Amount
	public void InputSpecifiedAmount(String SpecificAmount) throws InterruptedException
	{
		InputSpecifiedAmount.clear();
		funclib.DelayTime();
		InputSpecifiedAmount.sendKeys(SpecificAmount);
		funclib.DelayTime();		
	}
	
	//Show Products
	public void ShowProducts() throws InterruptedException
	{		
		funclib.DelayTime();
		ShowProductClick.click();	
	}
	
	//Select Product Type
	public String SelProductType(String Product)
	{
		String SelectOption = Product;
		String SelProductType = funclib.DropdownListSelectSpecific(SelectOption, SelectProductType);
		return SelProductType;		
	}
	
	//Input Discretionary Margin
	public void InputDiscretionaryMargin(String DiscretionaryMargin) throws InterruptedException
	{
		InputDiscretionaryMargin.clear();
		funclib.DelayTime();
		InputDiscretionaryMargin.sendKeys(DiscretionaryMargin);
		funclib.DelayTime();		
	}
	
	//Input Discretionary Subsequent
	public void InputDiscretionarySubsequent(String DiscretionarySubsequent) throws InterruptedException
	{
		InputDiscretionarySubsequent.clear();
		funclib.DelayTime();
		InputDiscretionarySubsequent.sendKeys(DiscretionarySubsequent);
		funclib.DelayTime();		
	}
	
	//Select Package Type
	public String SelPackageType(String PackageType)
	{
		String SelectOption = PackageType;
		String SelPackageType = funclib.DropdownListSelect(SelectOption, SelectPackage);
		return SelPackageType;		
	}
	
	//Select Campaign Type
	public String SelCampaignType(String CampaignType)
	{
		String SelectOption = CampaignType;
		String SelCampaignType = funclib.DropdownListSelect(SelectOption, SelectCampaign);
		return SelCampaignType;		
	}
	
	//Select Discretionary Reason
	public String SelDiscretionaryReason(String DiscretionaryReason)
	{
		String SelectOption = DiscretionaryReason;		
		String SelDiscretionaryReason = funclib.DropdownListSelect(SelectOption, SelectDiscretionaryReason);
		return SelDiscretionaryReason;	
	}
	
	//Select Offset Facility
	public String SelOffsetFacility(String Offset) throws InterruptedException
	{		
		String OptionValue = Offset;		
		String OffsetFacilityResult= funclib.SelOptionValue(RadioOffsetYes, RadioOffsetYes.getAttribute("value"),RadioOffsetNo,RadioOffsetNo.getAttribute("value"),OptionValue);	
		return OffsetFacilityResult;		
	}
	
	//Navigate to Back Page
	public void BackPage() throws InterruptedException
	{		
		funclib.DelayTime();
		BackClick.click();	
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
	
	//Select Repayment Frequency
	public String SelRepaymentFrequency(String RepaymentFrequency)
	{
		String SelectOption = RepaymentFrequency;
		String SelRepaymentFrequencyVal = funclib.DropdownListSelect(SelectOption, SelectRepaymentFrequency);
		return SelRepaymentFrequencyVal;		
	}
	
	//Select First Repayment Date
	public String SelFirstRepaymentDate(String RepaymentDate)
	{
		String SelectOption = RepaymentDate;
		String SelRepaymentDateVal = funclib.DropdownListSelect(SelectOption, SelectFirstRepaymentDay);
		return SelRepaymentDateVal;		
	}
	
	//Select Repayment Method Type
	public String SelRepaymentMethodType(String RepaymentMethod)
	{
		String SelectOption = RepaymentMethod;
		String SelRepaymentMethodType = funclib.DropdownListSelect(SelectOption, SelectRepaymentMethod);
		return SelRepaymentMethodType;		
	}
	
	//Navigate to Product Selection Page
	public void AddProductPage() throws InterruptedException
	{		
		funclib.DelayTime();
		AddProductClick.click();	
	}
	
}
