package org.lendfast.utils;

public interface IButton {
	public void click();

	public boolean isDisplayed();

	public boolean isEnabled();


}
