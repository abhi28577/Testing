package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_ConstructionBuilder extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
						
	//Defining WebElements
						
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Construction Builder Details')]")
	WebElement HeadSection;
	
	//Input Builder Name
	@FindBy(xpath="//input[@id='main:builderDetailsname:builderDetailsname']")
	WebElement InputBuilderName;
	
	//Input Builder Address
	@FindBy(xpath="//input[@id='main:builderDetailsaddress_Decorate:adr_streetSearch']")
	WebElement InputBuilderAddress;
	
	//Input Builder ABN
	@FindBy(xpath="//input[@id='main:builderDetailsABN:builderDetailsABN']")
	WebElement InputBuilderABN;
	
	//Input Builder Licence Number
	@FindBy(xpath="//input[@id='main:builderDetailslicenceNumber:builderDetailslicenceNumber']")
	WebElement InputBuilderLicence;
	
	//Select State of Issue
	@FindBy(xpath="//select[@id='main:builderDetailslicenceIssueState:builderDetailslicenceIssueState']")
	WebElement SelStateType;
	
	//Input Builder Area Code
	@FindBy(xpath="//input[@id='main:builderDetailsbuilderPhone:number:workAreaCode']")
	WebElement InputBuilderAreaCode;
	
	//Input Builder Area Phone Number
	@FindBy(xpath="//input[@id='main:builderDetailsbuilderPhone:number:workPhoneNumber']")
	WebElement InputBuilderAreaPhoneNumber;
	
	//Input Builder Fax Area Code
	@FindBy(xpath="//input[@id='main:builderDetailsbuilderFax:number:faxAreaCode']")
	WebElement InputBuilderFaxAreaCode;
	
	//Input Builder Fax Number
	@FindBy(xpath="//input[@id='main:builderDetailsbuilderFax:number:faxPhoneNumber']")
	WebElement InputBuilderFaxNumber;
	
	//Input Builder Email Address
	@FindBy(xpath="//input[@id='main:builderDetailsemailAddress:builderDetailsemailAddress']")
	WebElement InputBuilderEmail;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	
	//Manual Address - Australian Address - Yes
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_isAustralian:qasadr_isAustralian:0']")
	WebElement AustralianAddressYes;
					
	//Manual Address - Australian Address - No
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_isAustralian:qasadr_isAustralian:1']")
	WebElement AustralianAddressNo;
			
	//Manual Address - Property Name
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_bldgName:qasadr_bldgName']")
	WebElement InputPropertyName;
			
	//Manual Address - Unit/Flat
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_unitNumber:qasadr_unitNumber']")
	WebElement InputPropertyUnit;
			
	//Manual Address - Unit Level
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_floorNumber:qasadr_floorNumber']")
	WebElement InputPropertyLevel;
			
	//Manual Address - House Number
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_streetNumber:qasadr_streetNumber']")
	WebElement InputHouseNum;
			
	//Manual Address - Street Name
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_streetName:qasadr_streetName']")
	WebElement InputStreetName;
			
	//Manual Address - Street Type
	@FindBy(xpath="//select[@id='addressTabs:addrDetailsForm:qasadr_streetType:qasadr_streetType']")
	WebElement SelectStreetType;
			
	//Manual Address - Street Suffix
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_streetTypeSuffix:qasadr_streetTypeSuffix']")
	WebElement SelectStreetSuffix;
			
	//Manual Address - Suburb
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_suburb:qasadr_suburb']")
	WebElement InputSuburb;
			
	//Manual Address - State
	@FindBy(xpath="//select[@id='addressTabs:addrDetailsForm:qasadr_state:qasadr_state']")
	WebElement SelectState;
			
	//Manual Address - Postal Code
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_postcode:qasadr_postcode']")
	WebElement InputPostalCode;
			
	//Manual Address - OK
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:okBtn']")
	WebElement OkClick;
		
	//Manual Address - Cancel
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:cancelBtn']")
	WebElement CancelClick;
	
	
	//Constructor
	public Purpose_ConstructionBuilder()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
				
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Construction Builder Details");		
		return HeadSectionResult;
	}
	
	//Input Builder Name
	public void InputName(String BuilderName) throws InterruptedException
	{
		InputBuilderName.clear();
		funclib.DelayTime();
		InputBuilderName.sendKeys(BuilderName);
		funclib.DelayTime();		
	}
	
	//Input Builder Address Manually
	public void InputAddress(String BuilderAddress) throws InterruptedException
	{
		InputBuilderAddress.clear();
		funclib.DelayTime();
		Actions action = new Actions(driver);
		//Actions action = new Actions(driver.get());
		InputBuilderAddress.sendKeys(BuilderAddress);
		funclib.DelayTime();
		
		action.sendKeys(Keys.ARROW_DOWN).build().perform();
		Thread.sleep(4000);
		action.sendKeys(Keys.ENTER).build().perform();
		funclib.DelayTime();
	}
	
	//Input Manual Address Details
	public void InputManualAddressDetails(String AustralianAddress, String PropertyName, String HouseNum,String Unit, String Level,  String StreetName, String StreetType, String StreetSuffix, String Suburb, String State, String PostalCode) throws InterruptedException
	{		
		String StrAusAddress = AustralianAddress;
		String StrProperty = PropertyName;
		String StrUnit=Unit;
		String StrLevel = Level;		
		String StrHouseNum = HouseNum;
		String StrName = StreetName;
		String StrType = StreetType;
		String StrSuffix = StreetSuffix;
		String StrSuburb = Suburb;
		String StrState = State;
		String StrPostalCode = PostalCode;
			
		funclib.ManualAddressDetails(StrAusAddress,AustralianAddressYes,AustralianAddressNo,StrProperty,InputPropertyName,StrUnit,InputPropertyUnit,StrLevel,InputPropertyLevel,StrHouseNum, InputHouseNum,StrName,InputStreetName, StrType,SelectStreetType,StrSuffix, SelectStreetSuffix, StrSuburb,InputSuburb, StrState, SelectState,StrPostalCode, InputPostalCode);
		funclib.DelayTime();
		OkClick.click();		
	}
	
	//Input Builder ABN
	public void InputABN(String BuilderABN) throws InterruptedException
	{
		InputBuilderABN.clear();
		funclib.DelayTime();
		InputBuilderABN.sendKeys(BuilderABN);
		funclib.DelayTime();		
	}
	
	//Input Builder Licence Number
	public void InputLicenceNumber(String BuilderLicence) throws InterruptedException
	{
		InputBuilderLicence.clear();
		funclib.DelayTime();
		InputBuilderLicence.sendKeys(BuilderLicence);
		funclib.DelayTime();		
	}
	
	//Select State of Issue
	public String SelState(String State)
	{
		String SelectOption = State;
		String SelectStateType = funclib.DropdownListSelect(SelectOption, SelStateType);
		return SelectStateType;		
	}	
	
	//Input Builder Area Code
	public void InputAreaCode(String BuilderAreaCode) throws InterruptedException
	{
		InputBuilderAreaCode.clear();
		funclib.DelayTime();
		InputBuilderAreaCode.sendKeys(BuilderAreaCode);
		funclib.DelayTime();		
	}
	
	//Input Builder Area Phone Number
	public void InputAreaPhoneNumber(String BuilderAreaPhoneNumber) throws InterruptedException
	{
		InputBuilderAreaPhoneNumber.clear();
		funclib.DelayTime();
		InputBuilderAreaPhoneNumber.sendKeys(BuilderAreaPhoneNumber);
		funclib.DelayTime();		
	}
	
	//Input Builder Fax Area Code
	public void InputFaxAreaCode(String BuilderFaxAreaCode) throws InterruptedException
	{
		InputBuilderFaxAreaCode.clear();
		funclib.DelayTime();
		InputBuilderFaxAreaCode.sendKeys(BuilderFaxAreaCode);
		funclib.DelayTime();		
	}
	
	//Input Builder Fax Number
	public void InputFaxNumber(String BuilderFaxNumber) throws InterruptedException
	{
		InputBuilderFaxNumber.clear();
		funclib.DelayTime();
		InputBuilderFaxNumber.sendKeys(BuilderFaxNumber);
		funclib.DelayTime();		
	}
	
	//Input Builder Email Address
	public void InputEmail(String BuilderEmail) throws InterruptedException
	{
		InputBuilderEmail.clear();
		funclib.DelayTime();
		InputBuilderEmail.sendKeys(BuilderEmail);
		funclib.DelayTime();		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
