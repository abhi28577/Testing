package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicantCurrentEmployment extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
							
	//Defining WebElements
							
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Current Employment Details for Individual')]")
	WebElement HeadSection;
	
	//Select Employment Status
	@FindBy(xpath="//select[@id='main:employstatus:employstatus']")
	WebElement SelectEmpStatus;
	
	//Select Business Entity Type
	@FindBy(xpath="//select[@id='main:employBusinessEntity:employBusinessEntity']")
	WebElement SelBusinessEntity;
	
	//Input Income Percentage
	@FindBy(xpath="//input[@id='main:employincomepercentage:employincomepercentage']")
	WebElement IncomePercentage;
	
	//Select Employer Type
	@FindBy(xpath="//select[@id='main:employemployerType:employemployerType']")
	WebElement SelEmployerType;	
	
	//Input Business Name
	@FindBy(xpath="//input[@id='main:employname:employname']")
	WebElement BusinessName;
	
	//Input ABN Value
	@FindBy(xpath="//input[@id='main:employabn:employabn']")
	WebElement ABNValue;
	
	//Input Position
	@FindBy(xpath="//input[@id='main:employposition:employposition']")
	WebElement PositionValue;
	
	//Input Employer Address
	@FindBy(xpath="//input[@id='main:employadr_Decorate:adr_streetSearch']")
	WebElement EmployerAddress;
	
	//Input # of Years in Industry 
	@FindBy(xpath="//input[@id='main:employperiodLabel:employyears']")
	WebElement IndustryYears;
		
	//Input # of Months in Industry
	@FindBy(xpath="//input[@id='main:employmonths:employmonths']")
	WebElement IndustryMonths;
	
	//Select Release Info to NPBS - Yes
	@FindBy(xpath="//input[@id='main:employagentReleaseToInst:employagentReleaseToInst:0']")
	WebElement RadioReleaseNPBSYes;
	
	//Select Release Info to NPBS - No
	@FindBy(xpath="//input[@id='main:employagentReleaseToInst:employagentReleaseToInst:1']")
	WebElement RadioReleaseNPBSNo;
	
	//Select Applicant Under Probation - Yes
	@FindBy(xpath="//input[@id='main:applicantUnderProbation:applicantUnderProbation:0']")
	WebElement RadioProbationYes;
		
	//Select Applicant Under Probation - No
	@FindBy(xpath="//input[@id='main:applicantUnderProbation:applicantUnderProbation:1']")
	WebElement RadioProbationNo;
	
	//Input Salary/Drawings
	@FindBy(xpath="//input[@id='main:employincomeamount:employincomeamount']")
	WebElement IncomeSalary;
	
	//Select Gross/Net
	@FindBy(xpath="//select[@id='main:employincometaxStatus:employincometaxStatus']")
	WebElement SelGrossNet;
	
	//Select Frequency Period
	@FindBy(xpath="//select[@id='main:employincomefrequency:employincomefrequency']")
	WebElement SelFrequency;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public ApplicantCurrentEmployment()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
								
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Current Employment Details for Individual");
		
		return HeadSectionResult;
	}
	
	//Select Employment Status
	public String SelEmpStatusType(String EmpStat)
	{
		String SelectOption = EmpStat;
		String SelEmpStatus = funclib.DropdownListSelect(SelectOption, SelectEmpStatus);
		return SelEmpStatus;		
	}
	
	//Select Business Entity Type
	public String SelBusinessType(String BusinessEntity)
	{
		String SelectOption = BusinessEntity;
		String SelBusiness = funclib.DropdownListSelect(SelectOption, SelBusinessEntity);
		return SelBusiness;		
	}
	
	//Select Employer Type
	public String SelEmployerType(String EmployerType)
	{
		String SelectOption = EmployerType;
		String SelBusiness = funclib.DropdownListSelect(SelectOption, SelEmployerType);
		return SelBusiness;		
	}	
	
	//Input Income Percentage
	public void InputIncomePercentage(String IncomePercent) throws InterruptedException
	{
		IncomePercentage.sendKeys(IncomePercent);
		funclib.DelayTime();
	}
	
	//Input Business Name
	public void InputBusinessName(String BusinessNme) throws InterruptedException
	{
		BusinessName.sendKeys(BusinessNme);
		funclib.DelayTime();
	}
	
	//Input ABN
	public void InputABNValue(String ABNVal) throws InterruptedException
	{
		ABNValue.sendKeys(ABNVal);
		funclib.DelayTime();
	}
	
	//Input Position
	public void InputPositionValue(String PositionType) throws InterruptedException
	{
		PositionValue.sendKeys(PositionType);
		funclib.DelayTime();
	}	
	
	//Input Employer Address
	public void InputEmpAddress(String EmpAddress) throws InterruptedException
	{
		EmployerAddress.sendKeys(EmpAddress);
		funclib.DelayTime();
	}
	
	//Input Years in Industry
	public void InputIndustryYears(String IndusYears) throws InterruptedException
	{
		IndustryYears.clear();
		IndustryYears.sendKeys(IndusYears);
		funclib.DelayTime();
	}
	
	//Input Months in Industry
	public void InputIndustryMonths(String IndusMonths) throws InterruptedException
	{
		IndustryMonths.clear();
		IndustryMonths.sendKeys(IndusMonths);
		funclib.DelayTime();
	}
	
	//Select Applicant Postal Address same as Residential Address
	public String SelReleaseNPBS(String ReleaseNPBS) throws InterruptedException
	{		
		String OptionValue = ReleaseNPBS;		
		String OptionResult= funclib.SelOptionValue(RadioReleaseNPBSYes, RadioReleaseNPBSYes.getAttribute("value"),RadioReleaseNPBSNo,RadioReleaseNPBSNo.getAttribute("value"),OptionValue);	
		return OptionResult;		
	}
	
	//Select Applicant Under Probation
	public String SelProbation(String Probation) throws InterruptedException
	{		
		String OptionValue = Probation;		
		String OptionResult= funclib.SelOptionValue(RadioProbationYes, RadioProbationYes.getAttribute("value"),RadioProbationNo,RadioProbationNo.getAttribute("value"),OptionValue);	
		return OptionResult;		
	}
	
	//Input Salary/Drawings
	public void InputSalaryIncome(String SalaryVal) throws InterruptedException
	{
		IncomeSalary.sendKeys(SalaryVal);
		funclib.DelayTime();
	}
	
	//Select gross/Net
	public String SelGrossNetType(String GrossNet)
	{
		String SelectOption = GrossNet;
		String SelGrossNetValue = funclib.DropdownListSelect(SelectOption, SelGrossNet);
		return SelGrossNetValue;		
	}
	
	//Select Frequency
	public String SelFrequencyType(String FrequencyType)
	{
		String SelectOption = FrequencyType;
		String SelFrequencyValue = funclib.DropdownListSelect(SelectOption, SelFrequency);
		return SelFrequencyValue;		
	}
	
	public void NextPage() throws InterruptedException
	{
	//Navigate to Next Page
		funclib.DelayTime();
	NextClick.click();	
	}

}
