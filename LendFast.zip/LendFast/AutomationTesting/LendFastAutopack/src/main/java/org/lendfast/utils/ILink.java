package org.lendfast.utils;

public interface ILink {
	public void click();

	public boolean isDisplayed();

	public boolean isEnabled();

}
