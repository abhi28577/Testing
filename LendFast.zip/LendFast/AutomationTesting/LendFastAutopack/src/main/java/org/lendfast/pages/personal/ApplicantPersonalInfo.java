package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicantPersonalInfo extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
		
	//Defining WebElements
		
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Personal Detail for Applicant')]")
	WebElement HeadSection;
	
	//Acting as Trustee - Yes
	@FindBy(xpath="//input[@id='main:actingAsTrustee:actingAsTrustee:0']")
	WebElement RadioTrusteeYes;
	
	//Acting as Trustee - No
	@FindBy(xpath="//input[@id='main:actingAsTrustee:actingAsTrustee:1']")
	WebElement RadioTrusteeNo;
	
	//Spouse/Partner
	@FindBy(xpath="//select[@id='main:partypartnerStatus:partypartnerStatus']")
	WebElement SelectPartner;
	
	//Dependents of Applicant - Yes
	@FindBy(xpath="//input[@id='main:partyhasDependents:partyhasDependents:0']")
	WebElement RadioDependentYes;
	
	//Dependents of Applicant - No
	@FindBy(xpath="//input[@id='main:partyhasDependents:partyhasDependents:1']")
	WebElement RadioDependentNo;
	
	//Input Ages of Depedents
	@FindBy(xpath="//input[@id='main:partyagesOfDependentPeople:partyagesOfDependentPeople']")
	WebElement InputDependentAge;
	
	//Pre-Completed Data Form of Applicant - Yes
	@FindBy(xpath="//input[@id='main:partyprecompleted:partyprecompleted:0']")
	WebElement RadioPreEnteredDataYes;
		
	//Pre-Completed Data Form of Applicant - No
	@FindBy(xpath="//input[@id='main:partyprecompleted:partyprecompleted:1']")
	WebElement RadioPreEnteredDataNo;
	
	//Signing Method
	@FindBy(xpath="//select[@id='main:signingBy:signingBy']")
	WebElement SelectSignMethod;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public ApplicantPersonalInfo()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Personal Detail for Applicant");
		
		return HeadSectionResult;
	}
	
	//Select Acting Trustee
	public String SelTrusteeType(String Trustee) throws InterruptedException
	{		
		String OptionValue = Trustee;		
		String TrusteeResult= funclib.SelOptionValue(RadioTrusteeYes, RadioTrusteeYes.getAttribute("value"),RadioTrusteeNo,RadioTrusteeNo.getAttribute("value"),OptionValue);	
		return TrusteeResult;		
	}
	
	//Select Spouse/Partner
	public String SelPartner(String Partner)
	{
		String SelectOption = Partner;
		String SelPartner = funclib.DropdownListSelect(SelectOption, SelectPartner);
		return SelPartner;		
	}
	
	//Select Dependents
	public String SelDependent(String Dependent) throws InterruptedException
	{		
		String OptionValue = Dependent;		
		String DependentResult= funclib.SelOptionValue(RadioDependentYes, RadioDependentYes.getAttribute("value"),RadioDependentNo,RadioDependentNo.getAttribute("value"),OptionValue);	
		return DependentResult;		
	}
	
	//Input Ages of Dependents
	public void InputAgeDependent(String AgeDependent) throws InterruptedException
	{
		InputDependentAge.clear();
		funclib.DelayTime();
		InputDependentAge.sendKeys(AgeDependent);
		funclib.DelayTime();
	}
	
	//Select Pre-Completed Form
	public String SelPreComplete(String PreCompleteForm) throws InterruptedException
	{		
		String OptionValue = PreCompleteForm;		
		String PreCompleteResult= funclib.SelOptionValue(RadioPreEnteredDataYes, RadioPreEnteredDataYes.getAttribute("value"),RadioPreEnteredDataNo,RadioPreEnteredDataNo.getAttribute("value"),OptionValue);
		return PreCompleteResult;		
	}
	
	//Select Signing Method
	public String SelSignMethod(String SignMethod) throws InterruptedException
	{
		String SelectOption = SignMethod;
		String SelSign = funclib.DropdownListSelect(SelectOption, SelectSignMethod);		
		return SelSign;		
	}
	
	public void NextPage() throws InterruptedException
	{
		//Navigate to Next Page
		funclib.DelayTime();
		NextClick.click();	
	}

}
