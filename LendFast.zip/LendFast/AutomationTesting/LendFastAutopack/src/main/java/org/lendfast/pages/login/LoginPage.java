package org.lendfast.pages.login;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends ParentPage 
{			
	CommonFuncLib funclib;
	
	//Define Username
	@FindBy(xpath="//input[@name='uas_username']")
	WebElement Username;
	
	//Define Password
	@FindBy(xpath="//input[@name='uas_password']")
	WebElement Password;
	
	//Define Logon Button
	@FindBy(xpath="//input[@name='submit']")
	WebElement SubmitLogin;
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
	
	public String PageTitle() 
	{			
		return driver.getTitle();
		//return driver.get().getTitle();
	}
	
	public HomePage LoginCredentials(String User, String Pwd) throws InterruptedException
	{		
		//Input UserName
		Username.sendKeys(User);		
		funclib.DelayTime();

		//Input Password
		Password.sendKeys(Pwd);
		funclib.DelayTime();

		//Submit Login Credentials			
		SubmitLogin.click();
		funclib.DelayTime();

		return new HomePage();

	}
}
