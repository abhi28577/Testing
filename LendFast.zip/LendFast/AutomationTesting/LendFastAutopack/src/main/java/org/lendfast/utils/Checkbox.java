package org.lendfast.utils;


import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebElement;

public class Checkbox  implements ICheckbox
{
	private WebElement element;

	public Checkbox(WebElement element) 
	{
		this.element = element;
		if (!isCheckBox())
			throw new RuntimeException("not a Check box");
		if (!this.isEnabled())
			throw new RuntimeException("Check Box not enabled!");
	}

	private boolean isCheckBox() {
		List<String> tags = Arrays.asList("input");
		return tags.contains(this.element.getTagName());
	}

	public boolean isChecked() {
		return this.element.isSelected();
	}

	public void click() {
		this.element.click();

	}

	private boolean isEnabled() {
		return this.element.isEnabled();
	}


}
