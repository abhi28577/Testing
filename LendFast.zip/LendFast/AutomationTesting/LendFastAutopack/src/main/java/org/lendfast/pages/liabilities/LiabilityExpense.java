package org.lendfast.pages.liabilities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LiabilityExpense extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;		
				
	//Defining WebElements
			
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Existing NPBS Liability Details')]")
	WebElement HeadSection;	
	
	//Define Modify Link
	//@FindBy(xpath="//a[contains(text(),'Modify')]/preceding-sibling::td[contains(text(),'VALUE+')]")
	@FindBy(xpath="//td[contains(text(),'VALUE+')]/following-sibling::td/a[contains(text(),'Modify')]")
	WebElement ModifyClick;	
	
	//Debt Repaid - Fully
	@FindBy(xpath="//input[@id='main:liabbeingRepaid:liabbeingRepaid:0']")
	WebElement RadioDebtRepaidFull;
	
	//Debt Repaid - Partially
	@FindBy(xpath="//input[@id='main:liabbeingRepaid:liabbeingRepaid:1']")
	WebElement RadioDebtRepaidPartial;
		
	//Debt Repaid - Not At All
	@FindBy(xpath="//input[@id='main:liabbeingRepaid:liabbeingRepaid:2']")
	WebElement RadioDebtRepaidNA;
	
	//Debt Cleared - Fully
	@FindBy(xpath="//input[@id='main:liabbeingCleared:liabbeingCleared:0']")
	WebElement RadioDebtClearedFull;
		
	//Debt Cleared - Partially
	@FindBy(xpath="//input[@id='main:liabbeingCleared:liabbeingCleared:1']")
	WebElement RadioDebtClearedPartial;
			
	//Debt Cleared - Not At All
	@FindBy(xpath="//input[@id='main:liabbeingCleared:liabbeingCleared:2']")
	WebElement RadioDebtClearedNA;
	
	//Limit - Cancelled
	@FindBy(xpath="//input[@id='main:liablimitBeingChanged:liablimitBeingChanged:0']")
	WebElement RadioLimitCancel;
			
	//Limit - Reduced
	@FindBy(xpath="//input[@id='main:liablimitBeingChanged:liablimitBeingChanged:1']")
	WebElement RadioLimitReduced;
			
	//Limit - Same
	@FindBy(xpath="//input[@id='main:liablimitBeingChanged:liablimitBeingChanged:2']")
	WebElement RadioLimitSame;	
	
	//Input New Limit
	@FindBy(xpath="//input[@id='main:liabnewLimit:liabnewLimit']")
	WebElement InputNewLimit;	
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public LiabilityExpense()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
			
	
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Existing NPBS Liability Details");		
		return HeadSectionResult;
	}
	
	//Click on Modify Button
	public void ClickModify() throws InterruptedException
	{
		//Modifying Applicant Details
		funclib.DelayTime();
		ModifyClick.click();
		funclib.DelayTime();	
	}
	
	//Modify Applicant
	public void ModifyApplicant(String LiabList, String LiabRepaid, String LiabCleared, String LiabChanged, String LiabLimit) throws InterruptedException	
	{	
		//Navigate to Existing NPBS Liability Details	
		
		String Check1="FULL";
		String Check2 = "PARTIAL";
		String Check3="NONE";
		
		String Status1 = "CANCELLED";
		String Status2 = "REDUCED";
		String Status3 = "NO_CHANGE";
		
			
		//Debt Repaid
		funclib.DelayTime();
		if(LiabRepaid .equals(Check1))
			RadioDebtRepaidFull.click();
		
		if(LiabRepaid .equals(Check2))
			RadioDebtRepaidPartial.click();
		
		if(LiabRepaid .equals(Check3))
			RadioDebtRepaidNA.click();
		
// ************************************************************************************************************
		
		funclib.DelayTime();
		//Debt Cleared
		
		if(LiabCleared .equals(Check1))
			RadioDebtClearedFull.click();
		
		if(LiabCleared .equals(Check2))
			RadioDebtClearedPartial.click();
		
		if(LiabCleared .equals(Check3))
			RadioDebtClearedNA.click();

// *************************************************************************************************************
			
		funclib.DelayTime();
		//Limit
		
		if(LiabChanged .equals(Status1))
			RadioLimitCancel.click();
		
		if(LiabChanged .equals(Status2))
		{	
			RadioLimitReduced.click();
			funclib.DelayTime();
			
			//	Input New Limit	
			InputNewLimit.clear();
			funclib.DelayTime();
			InputNewLimit.sendKeys(LiabLimit);
		}	
		
		if(LiabChanged .equals(Status3))
			RadioLimitSame.click();

// *************************************************************************************************************
			
		//Capture Screenshot
		funclib.CaptureScreenShot();
						
		//Navigate to Liabilities/Expenses Page
		funclib.DelayTime();
		NextClick.click();
	}	
}	
	
	

