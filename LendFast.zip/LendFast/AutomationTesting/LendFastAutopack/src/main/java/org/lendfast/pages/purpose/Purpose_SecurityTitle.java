package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_SecurityTitle extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;		
									
	//Defining WebElements
							
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Security Title')]")
	WebElement HeadSection;
	
	//Title Registered - Yes
	@FindBy(xpath="//input[@id='main:assetisTitleRegistered:assetisTitleRegistered:0']")
	WebElement RadioTitleRegisterYes;
				
	//Title Registered - No
	@FindBy(xpath="//input[@id='main:assetisTitleRegistered:assetisTitleRegistered:1']")
	WebElement RadioTitleRegisterNo;
	
	//Title Property Button
	@FindBy(xpath="//input[@id='main:assetaddPropTitleBtn']")
	WebElement InputPropertyTitleButton;
	
	//Title Reference
	@FindBy(xpath="//input[@id='main:proptitletitleRef:proptitletitleRef']")
	WebElement InputTitleReference;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Purpose_SecurityTitle()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
				
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Security Title");		
		return HeadSectionResult;
	}
	
	//Select Title Registration
	public String SelTitleRegister(String TitleRegister) throws InterruptedException
	{		
		String OptionValue = TitleRegister;		
		String TitleRegisterResult= funclib.SelOptionValue(RadioTitleRegisterYes, RadioTitleRegisterYes.getAttribute("value"),RadioTitleRegisterNo,RadioTitleRegisterNo.getAttribute("value"),OptionValue);	
		return TitleRegisterResult;		
	}
	
	//Add Property Title
	public void AddPropertyTitle() throws InterruptedException
	{		
		funclib.DelayTime();
		InputPropertyTitleButton.click();	
	}
	
	// Add Property Title
	public void InputPropertyTitle(String PropertyTitle) throws InterruptedException
	{		
		funclib.DelayTime();
		InputTitleReference.sendKeys(PropertyTitle);
		funclib.DelayTime();		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
	
}
