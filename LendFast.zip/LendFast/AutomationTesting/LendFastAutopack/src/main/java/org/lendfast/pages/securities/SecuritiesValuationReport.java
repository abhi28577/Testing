package org.lendfast.pages.securities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SecuritiesValuationReport extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;	
							
	//Defining WebElements
						
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Valuation Reports')]")
	WebElement HeadSection;
	
	//Define Assess1 Link
	@FindBy(xpath="//a[@id='main:valuationList:0:Assess']")
	WebElement Assess1;
	
	//Define Assess2 Link
	@FindBy(xpath="//a[@id='main:valuationList:1:Assess']")
	WebElement Assess2;
		
	//Define Assess3 Link
	@FindBy(xpath="//a[@id='main:valuationList:2:Assess']")
	WebElement Assess3;
		
	//Define Assess1 Link
	@FindBy(xpath="//a[@id='main:valuationList:3:Assess']")
	WebElement Assess4;
	
	//Record Valuation Declaration - Yes
	@FindBy(xpath="//input[@id='main:isAcceptable:isAcceptable:0']")
	WebElement RadioRecordValuationYes;
					
	//Record Valuation Declaration - No
	@FindBy(xpath="//input[@id='main:isAcceptable:isAcceptable:1']")
	WebElement RadioRecordValuationNo;
	
	//Add Valuation Type
	@FindBy(xpath="//select[@id='main:valnvaluationType:valnvaluationType']")
	WebElement SelectValType;
	
	//Add Valuation Click
	@FindBy(xpath="//input[@id='main:requestValBtn']")
	WebElement AddValuationClick;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Initializing NULL
	String NullType="null";
	String Counter1="1";
	String Counter2="2";
	String Counter3="3";
	String Counter4="4";
	
	//Constructor
	public SecuritiesValuationReport()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Valuation Reports");		
		return HeadSectionResult;
	}
		
	//Click on Valuation Link
	
	public void ValuationReport(String Counter) throws InterruptedException
	{		
		if(Counter .equals(Counter1))
		{
			funclib.DelayTime();
			Assess1.click();				
		}
			
		if(Counter .equals(Counter2))
		{
			funclib.DelayTime();
			Assess2.click();
		}
			
		if(Counter .equals(Counter3))
		{
			funclib.DelayTime();
			Assess3.click();
		}
			
		if(Counter .equals(Counter4))
		{
			funclib.DelayTime();
			Assess4.click();
		}
	}
	
	//Credit Analysis - Add Valuation Type
	public String SelectValuationType(String ValuationType)
	{
		String SelectOption = ValuationType;
		String SelectValuationResult = funclib.DropdownListSelect(SelectOption, SelectValType);
		return SelectValuationResult;
	}
	
	//Credit Analysis - Click on Add Valuation
	public void AddValuation() throws InterruptedException 
	{
		//Click on Add Valuation Button
		funclib.DelayTime();
		AddValuationClick.click();
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
