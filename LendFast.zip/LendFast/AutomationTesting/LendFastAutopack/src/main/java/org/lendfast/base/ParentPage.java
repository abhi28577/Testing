package org.lendfast.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.lendfast.utils.PageWaitUtil;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class ParentPage 
{	
	
	public static WebDriver driver; // Running Tests on Local Node
	//public static ThreadLocal<RemoteWebDriver> driver = new ThreadLocal<>(); // Running Tests on Grid Driver
	public static Properties prop;
	
	
	public ParentPage()
	{		
		try
		{				
			//Importing Properties from Config File
			prop=new Properties();
			String LendFastPath = System.getProperty("user.dir");			
			 
			FileInputStream IP = new FileInputStream(LendFastPath + "\\src\\main\\java\\org\\lendfast\\configuration\\config.properties");
			//FileInputStream IP = new FileInputStream("C:\\Users\\abhishek.paspuleti\\eclipse-workspace\\LendFastAutopack\\src\\main\\java\\org\\lendfast\\configuration\\config.properties");
			prop.load(IP);
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
			
	}
	
	public static void initialization() throws MalformedURLException
	{		
		
		//Parameters populating from Config File. Config File needs to be changed for Browser(Chrome/FireFox)
		String BrowserName = prop.getProperty("browser");
		String BrowserPath = System.getProperty("user.dir");
		
		if(BrowserName.equals("chrome"))
		{
			//Path of Chrome Driver
			System.setProperty("webdriver.chrome.driver", BrowserPath + "\\..\\Tools\\Driver\\chromedriver.exe");			
			//System.setProperty("webdriver.chrome.driver", "C:\\Users\\abhishek.paspuleti\\eclipse-workspace\\Tools\\Driver\\chromedriver.exe");
			ChromeOptions Options = new ChromeOptions();
			Options.setPageLoadStrategy(PageLoadStrategy.NONE);
			driver = new ChromeDriver(Options);		
		}		
		
		// Defining Properties of Browser
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();		
		driver.manage().timeouts().pageLoadTimeout(PageWaitUtil.PAGE_LOAD_TIMEOUT,TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(PageWaitUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		
		driver.get(prop.getProperty("url"));
		
	}
//------------------------------------------------------------------------------------------------------------------------------------------------------------
/*	public void GridBrowserSetUp() throws MalformedURLException
	{
		// Grid Driver Run
		
		//Defining the Path of Parent URL (https://www.ebay.com.au)
		//Desired Capabilities
		DesiredCapabilities Cap = new DesiredCapabilities();
		Cap.setBrowserName("chrome");
		Cap.setPlatform(Platform.LINUX);
		
		//Chrome Options
		ChromeOptions Options = new ChromeOptions();
		Options.setPageLoadStrategy(PageLoadStrategy.NONE);
		
		Options.addArguments("start-maximized");
		Options.addArguments("no-sandbox");	
		Options.addArguments("display=:0");
		Options.merge(Cap);
		
		
		String HubUrl = "http://172.26.28.76:80/wd/hub";		
		driver.set(new RemoteWebDriver(new URL(HubUrl), Options));
		//driver = new RemoteWebDriver(new URL(HubUrl),Options);
		//driver.get(prop.getProperty("url"));
		driver.get().navigate().to(prop.getProperty("url"));	
	}	
*/
}
