package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_PurchasePropertyContract extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
			
	//Defining WebElements
			
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Purchase Property Contract Details')]")
	WebElement HeadSection;	
	
	//Approval Type - Full Approval
	@FindBy(xpath="//input[@id='main:purposeisForPreapproval:purposeisForPreapproval:0']")
	WebElement RadioPurchaseApprovalYes;
		
	//Approval Type - Pre-Approval
	@FindBy(xpath="//input[@id='main:purposeisForPreapproval:purposeisForPreapproval:1']")
	WebElement RadioPurchaseApprovalNo;
	
	//Purchase Security Type - Yes
	@FindBy(xpath="//input[@id='main:purposeisSecurity:purposeisSecurity:0']")
	WebElement RadioPurchaseSecurityYes;
			
	//Purchase Security Type - No
	@FindBy(xpath="//input[@id='main:purposeisSecurity:purposeisSecurity:1']")
	WebElement RadioPurchaseSecurityNo;
	
	//Property Found - Yes
	@FindBy(xpath="//input[@id='main:purposefoundProperty:purposefoundProperty:0']")
	WebElement RadioPropertyFoundYes;
				
	//Property Found - No
	@FindBy(xpath="//input[@id='main:purposefoundProperty:purposefoundProperty:1']")
	WebElement RadioPropertyFoundNo;
	
	//Address Text
	@FindBy(xpath="//input[@id='main:locateAddress_Decorate:adr_streetSearch']")
	WebElement InputPropertyAddress;
	
	//Manual Address - Australian Address - Yes
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_isAustralian:qasadr_isAustralian:0']")
	WebElement AustralianAddressYes;
			
	//Manual Address - Australian Address - No
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_isAustralian:qasadr_isAustralian:1']")
	WebElement AustralianAddressNo;
	
	//Manual Address - Property Name
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_bldgName:qasadr_bldgName']")
	WebElement InputPropertyName;
	
	//Manual Address - Unit/Flat
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_unitNumber:qasadr_unitNumber']")
	WebElement InputPropertyUnit;
	
	//Manual Address - Unit Level
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_floorNumber:qasadr_floorNumber']")
	WebElement InputPropertyLevel;
	
	//Manual Address - House Number
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_streetNumber:qasadr_streetNumber']")
	WebElement InputHouseNum;
	
	//Manual Address - Street Name
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_streetName:qasadr_streetName']")
	WebElement InputStreetName;
	
	//Manual Address - Street Type
	@FindBy(xpath="//select[@id='addressTabs:addrDetailsForm:qasadr_streetType:qasadr_streetType']")
	WebElement SelectStreetType;
	
	//Manual Address - Street Suffix
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_streetTypeSuffix:qasadr_streetTypeSuffix']")
	WebElement SelectStreetSuffix;
	
	//Manual Address - Suburb
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_suburb:qasadr_suburb']")
	WebElement InputSuburb;
	
	//Manual Address - State
	@FindBy(xpath="//select[@id='addressTabs:addrDetailsForm:qasadr_state:qasadr_state']")
	WebElement SelectState;
	
	//Manual Address - Postal Code
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_postcode:qasadr_postcode']")
	WebElement InputPostalCode;
	
	//Manual Address - OK
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:okBtn']")
	WebElement OkClick;
	
	//Manual Address - Cancel
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:cancelBtn']")
	WebElement CancelClick;
	
	//Property Zone
	@FindBy(xpath="//select[@id='main:assetpropertyZone:assetpropertyZone']")
	WebElement SelectPropertyZone;
	
	//Contract of Sale - Yes
	@FindBy(xpath="//input[@id='main:purposehasContract:purposehasContract:0']")
	WebElement RadioContractSaleYes;
					
	//Contract of Sale - No
	@FindBy(xpath="//input[@id='main:purposehasContract:purposehasContract:1']")
	WebElement RadioContractSaleNo;
	
	//Contract Copy - Yes
	@FindBy(xpath="//input[@id='main:purposecontractAvail:purposecontractAvail:0']")
	WebElement RadioContractCopyYes;
						
	//Contract Copy - No
	@FindBy(xpath="//input[@id='main:purposecontractAvail:purposecontractAvail:1']")
	WebElement RadioContractCopyNo;
	
	//Party Contract Signature - Yes
	@FindBy(xpath="//input[@id='main:purposeisSignedByAll:purposeisSignedByAll:0']")
	WebElement RadioContractSignYes;
							
	//Party Contract Signature - No
	@FindBy(xpath="//input[@id='main:purposeisSignedByAll:purposeisSignedByAll:1']")
	WebElement RadioContractSignNo;
	
	//Contract Date
	@FindBy(xpath="//input[@id='main:purposecontractDate:purposecontractDateInputDate']")
	WebElement InputContractDate;
	
	//Vendor Name
	@FindBy(xpath="//input[@id='main:purposevendorNames:purposevendorNames']")
	WebElement InputVendorName;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Purpose_PurchasePropertyContract()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
	
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Purchase Property Contract Details");		
		return HeadSectionResult;
	}
	
	//Select Approval Type
	public String SelApprovalType(String ApprovalType) throws InterruptedException
	{		
		String OptionValue = ApprovalType;		
		String ApprovalResult= funclib.SelOptionValue(RadioPurchaseApprovalYes, RadioPurchaseApprovalYes.getAttribute("value"),RadioPurchaseApprovalNo,RadioPurchaseApprovalNo.getAttribute("value"),OptionValue);	
		return ApprovalResult;		
	}
	
	//Select Property Security
	public String SelPropertySecurityType(String PropertySecurityType) throws InterruptedException
	{		
		String OptionValue = PropertySecurityType;		
		String PropertySecurityResult= funclib.SelOptionValue(RadioPurchaseSecurityYes, RadioPurchaseSecurityYes.getAttribute("value"),RadioPurchaseSecurityNo,RadioPurchaseSecurityNo.getAttribute("value"),OptionValue);	
		return PropertySecurityResult;	
	}
	
	//Select Property Found
	public String SelPropertyFoundType(String PropertyFoundType) throws InterruptedException
	{		
		String OptionValue = PropertyFoundType;		
		String PropertyFoundResult= funclib.SelOptionValue(RadioPropertyFoundYes, RadioPropertyFoundYes.getAttribute("value"),RadioPropertyFoundNo,RadioPropertyFoundNo.getAttribute("value"),OptionValue);	
		return PropertyFoundResult;		
	}
	
	//Input Manual Address
	public void InputManualAddress(String ManualAddress) throws InterruptedException
	{
		Actions action = new Actions(driver);
		//Actions action = new Actions(driver.get());
		InputPropertyAddress.sendKeys(ManualAddress);
		funclib.DelayTime();
		
		action.sendKeys(Keys.ARROW_DOWN).build().perform();
		Thread.sleep(4000);
		action.sendKeys(Keys.ENTER).build().perform();
		funclib.DelayTime();
	}
	
	//Input Manual Address Details
	public void InputManualAddressDetails(String AustralianAddress, String PropertyName, String HouseNum,String Unit, String Level,  String StreetName, String StreetType, String StreetSuffix, String Suburb, String State, String PostalCode) throws InterruptedException
	{		
		String StrAusAddress = AustralianAddress;
		String StrProperty = PropertyName;
		String StrUnit=Unit;
		String StrLevel = Level;		
		String StrHouseNum = HouseNum;
		String StrName = StreetName;
		String StrType = StreetType;
		String StrSuffix = StreetSuffix;
		String StrSuburb = Suburb;
		String StrState = State;
		String StrPostalCode = PostalCode;
		
		funclib.ManualAddressDetails(StrAusAddress,AustralianAddressYes,AustralianAddressNo,StrProperty,InputPropertyName,StrUnit,InputPropertyUnit,StrLevel,InputPropertyLevel,StrHouseNum, InputHouseNum,StrName,InputStreetName, StrType,SelectStreetType,StrSuffix, SelectStreetSuffix, StrSuburb,InputSuburb, StrState, SelectState,StrPostalCode, InputPostalCode);
		funclib.DelayTime();
		OkClick.click();		
	}
	
	//Select Property Zone
	public String SelPropertyZone(String PropertyZone)
	{
		String SelectOption = PropertyZone;
		String SelPropZone = funclib.DropdownListSelect(SelectOption, SelectPropertyZone);
		return SelPropZone;		
	}
	
	//Select Contract Sale
	public String SelContractSaleType(String ContractSale) throws InterruptedException
	{		
		String OptionValue = ContractSale;		
		String ContractSaleResult= funclib.SelOptionValue(RadioContractSaleYes, RadioContractSaleYes.getAttribute("value"),RadioContractSaleNo,RadioContractSaleNo.getAttribute("value"),OptionValue);	
		return ContractSaleResult;		
	}
	
	//Select Contract Copy
	public String SelContractCopyType(String ContractCopy) throws InterruptedException
	{		
		String OptionValue = ContractCopy;		
		String ContractCopyResult= funclib.SelOptionValue(RadioContractCopyYes, RadioContractCopyYes.getAttribute("value"),RadioContractCopyNo,RadioContractCopyNo.getAttribute("value"),OptionValue);	
		return ContractCopyResult;		
	}
	
	//Select Contract Sign
	public String SelContractSignType(String ContractSign) throws InterruptedException
	{		
		String OptionValue = ContractSign;		
		String ContractSignResult= funclib.SelOptionValue(RadioContractSignYes, RadioContractSignYes.getAttribute("value"),RadioContractSignNo,RadioContractSignNo.getAttribute("value"),OptionValue);	
		return ContractSignResult;		
	}

	//Input Contract Date
	public void InputContractDate(String ContractDate)
	{
		InputContractDate.sendKeys(ContractDate);
	}
	
	//Input Vendor Name
	public void InputVendorName(String VendorName)
	{
		InputVendorName.sendKeys(VendorName);
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
	
}
