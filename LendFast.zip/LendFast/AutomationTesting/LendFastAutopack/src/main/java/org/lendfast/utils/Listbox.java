package org.lendfast.utils;

import java.util.Random;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;

public class Listbox implements IListbox 
{
	private Select list;
	private WebElement element;

	public Listbox(WebElement e) 
	{
		this.element = e;
		String tag = e.getTagName();

		if (tag.equalsIgnoreCase("select") == false)
			throw new UnexpectedTagNameException("select", tag);

		this.list = new Select(e);
	}

	
	public void select(String text) 
	{
		this.selectByVisibleText(text);
	}

	
	public void select(int i) 
	{
		this.selectByIndex(i);
	}

	
	public void select() 
	{
		Random r = new Random();
		int from = 0;
		int to = size() - 1;
		if (isFirstOptionEmpty())
			from = 1;
		this.selectByIndex(r.nextInt(to - from) + from);

	}

	
	public boolean isFirstOptionEmpty() 
	{
		WebElement option = this.list.getOptions().get(0);
		return option.getText().trim().isEmpty();
	}

	
	public void selectByVisibleText(String text) 
	{
		this.list.selectByVisibleText(text);

	}

	
	public void selectByIndex(int index) 
	{
		this.list.selectByIndex(index);
	}

	
	public String getFirstSelectedText() 
	{
		return this.list.getFirstSelectedOption().getText().toLowerCase();
	}

	
	public int size()
	{
		return this.list.getOptions().size();
	}

	
	public boolean isDisplayed() 
	{
		return this.element.isDisplayed();
	}
}
