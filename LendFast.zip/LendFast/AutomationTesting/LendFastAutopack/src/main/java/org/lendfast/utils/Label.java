package org.lendfast.utils;

public class Label 
{
	

}
