package org.lendfast.pages.checklist;

import java.util.List;
import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ChecklistCreditAnalysis extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
									
	//Defining WebElements
								
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Check List')]")
	WebElement HeadSection;
	
	//Logout
	@FindBy(linkText="Logout")
	WebElement LogOutClick;
	
	//Define Image Link	
	@FindBy(linkText="Image")
	WebElement ImageClick;
	
	//Define Complete Link	
	@FindBy(linkText="Complete")
	WebElement CompleteClick;	

	//Define Defunc Items
	@FindBy(xpath="//input[@id='main:cklstexcludeCompleted:cklstexcludeCompleted']")
	WebElement CheckDefunctList;
	
	//Define Mandatory Checkbox Submission List
	@FindBy(xpath="//input[@id='main:cklstexcludeNonMandatory:cklstexcludeNonMandatory']")
	WebElement CheckMandateList;
	
	//Submission Position
	@FindBy(xpath="//td[@id = 'main:checkList:0:j_id835']")
	WebElement SubmissionPosition;
		
	//Select Identification Document
	@FindBy(xpath="//select[@id='main:docType:docType']")
	WebElement SelectIdentityType;
	
	//Upload File
	@FindBy(xpath="//input[@id='main:fileUpload:upload:file']")
	WebElement UploadFile;
	
	//Select Submission Process
	@FindBy(xpath="//select[@id='main:docSource:docSource']")
	WebElement SelectSubmissionType;
	
	//Define Add Document Button
	@FindBy(xpath="//input[@id='main:addDocumentBtn']")
	WebElement AddDocClick;
	
	//Define Select Link
	@FindBy(xpath="//input[@id='main:docRelatedTo:selectBtn']")
	WebElement SelectLinkClick;
	
	//Define Ok Button
	@FindBy(xpath="//input[@id='docReqChooserForm:okBtn']")
	WebElement SelectOkClick;
	
	//Select Link
	@FindBy(xpath="//input[@id='main:docRelatedTo:selectBtn']")
	WebElement SelectListClick;	
	
	//Checkbox Verification
	@FindBy(xpath="//input[@id='main:docRelatedTo:requirementsVerified']")
	WebElement CheckboxVerify;
	
	//Document Verification
	@FindBy(xpath="//select[@id='main:statusCbo']")
	WebElement SelectDocumentVerify;	
	
	//Applicant Insurance Verification
	@FindBy(xpath="//textarea[@id='main:cklstverificationNote:cklstverificationNote']")
	WebElement InputApplicantInsuranceVerify;
	
	//Additional Information/Comments
	@FindBy(xpath="//textarea[@id='main:appsubmitComment:appsubmitComment']")
	WebElement InputAdditionalInfo;
	
	//Save Additional Information/Comments
	@FindBy(xpath="//input[@id='main:saveCommentsBtn:saveCommentsBtn']")
	WebElement SaveAdditionalInfoClick;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Yes Button
	@FindBy(xpath="//input[@id='yes']")
	WebElement YesClick;
	
	//Submit Button
	@FindBy(xpath="//input[@id='main:submitbutton']")
	WebElement SubmitClick;
	
	//Status Tab
	@FindBy(xpath="//div[@id = 'docReqChooserForm:docRelatedTo:j_id1169header:sortDiv']")
	WebElement StatusLink;
	
	//Constructor
	public ChecklistCreditAnalysis()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
				
		
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Check List");		
		return HeadSectionResult;
	}	
	
	//Select Non-Mandatory List
	public void NonMandatory() throws InterruptedException
	{
		funclib.DelayTime();
		CheckDefunctList.click();
		funclib.DelayTime();
		CheckMandateList.click();
	}
	
	//Submission Position
	public void SubmissionPos() throws InterruptedException
	{		
		String CompleteType="Complete";
		String ImageType="Image";	
		
		
		WebDriverWait wait = new WebDriverWait(driver, 25);
		Actions action = new Actions(driver);	
		
		//WebDriverWait wait = new WebDriverWait(driver.get(), 25);
		//Actions action = new Actions(driver.get());	
		
		//Complete Click - Refer to Assessor (Security)
		java.util.List<WebElement> CompleteLink=driver.findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Refer to Assessor (Security)')]"));
		//java.util.List<WebElement> CompleteLink=driver.get().findElements(By.xpath("//td/a[contains(text(),'Complete')]/../preceding-sibling::td/span[contains(text(),'Refer to Assessor (Security)')]"));
		
		if(!CompleteLink.isEmpty())
		{
			String CompleteClickResult = funclib.HeadingSection(CompleteClick.getText(), "Complete");
			
			funclib.DelayTime();
			WebElement CompClick = wait.until(ExpectedConditions.elementToBeClickable(CompleteClick));				
			
		
			// Count of 'Complete' Text
			System.out.println("Complete Count: " + CompleteLink.size());
			
			if(CompleteLink.size() >0)
			{
				for(int CompleteCounter=1;CompleteCounter<=CompleteLink.size();CompleteCounter++)
				{			
				
					if (CompleteClickResult .equals(CompleteType))
					{
						funclib.DelayTime();
						action.moveToElement(CompClick).doubleClick(CompClick).perform();
						funclib.DelayTime();
				
						//Input Applicant Insurance Verification
						InputApplicantInsuranceVerify.clear();
						funclib.DelayTime();
						InputApplicantInsuranceVerify.sendKeys("Verified Successfully");
						funclib.DelayTime();
			
						//Capture Screenshot
						funclib.CaptureScreenShot();
					
						//Navigate Next Page
						funclib.DelayTime();
						NextClick.click();						
					}					
				}
			}
		}
		
		//Image Click - Conditional Approval and Approval	
		java.util.List<WebElement> ImageLink=driver.findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Conditional Approval and Approval')]"));
		//java.util.List<WebElement> ImageLink=driver.get().findElements(By.xpath("//td/a[contains(text(),'Image')]/../preceding-sibling::td/span[contains(text(),'Conditional Approval and Approval')]"));
		
		if(!ImageLink.isEmpty())
		{
			funclib.DelayTime();
			String ImageClickResult = funclib.HeadingSection(ImageClick.getText(), "Image");
			
			WebElement ImgClick = wait.until(ExpectedConditions.elementToBeClickable(ImageClick));
			
		
			// Count of 'Image' Text	
			System.out.println("Image Count: " + ImageLink.size());
			
			if(ImageLink.size()>0)
			{
				if (ImageClickResult .equals(ImageType))
				{
					funclib.DelayTime();
					action.moveToElement(ImgClick).doubleClick(ImgClick).perform();				
				
					//Click on Add Document Link
					funclib.DelayTime();
					AddDocClick.click();
					funclib.DelayTime();				
				 
					//Clicking on Select Link
					funclib.DelayTime();
					SelectLinkClick.click();
					funclib.DelayTime();
					
					//Click on Status Link
					StatusLink.click();
					funclib.DelayTime();
				
					//Checking all Checkboxes
					String CheckboxPath = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//input";
					String Summary = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[2]";
					String StatusCheck = "//tbody[contains(@id,'docReqChooserForm:docRelatedTo:tb')]//tr//td[3]//span";				
					
					List<WebElement> checkBoxes = driver.findElements(By.xpath(CheckboxPath));
					List<WebElement> SummaryChecks = driver.findElements(By.xpath(Summary));
					List<WebElement> StatusChecks = driver.findElements(By.xpath(StatusCheck));
					
					//List<WebElement> checkBoxes = driver.get().findElements(By.xpath(CheckboxPath));
					//List<WebElement> SummaryChecks = driver.get().findElements(By.xpath(Summary));
					//List<WebElement> StatusChecks = driver.get().findElements(By.xpath(StatusCheck));
					
					String OutStandingValue="Outstanding";			
					
					//CheckMark each
					funclib.DelayTime();
					System.out.println("Status Check Count:" + StatusChecks.size());
					for(int i=0;i<StatusChecks.size();i++)
					{					
						if(StatusChecks.get(i).getText() .equals(OutStandingValue))
						{
							System.out.println("Status:" + StatusChecks.get(i).getText());
							if(!checkBoxes.get(i).isSelected())
								checkBoxes.get(i).click();
							funclib.DelayTime();
						}
						else
						{
							System.out.println("Summary Check:" + SummaryChecks.get(i).getText());
							System.out.println("Status:" + StatusChecks.get(i).getText());
							System.out.println("Loop Counter: " +i);
						}
					}		     
					
					//Click on OK Button
					System.out.println("Status Check Count:" + StatusChecks.size());
					funclib.DelayTime();
					SelectOkClick.click();
					
					//Checking all Reference Textboxes
					String TextboxPath = "//tbody[contains(@id,'main:docRelatedTo:docRelatedTo:tb')]//input";
					List<WebElement> TextBoxes = driver.findElements(By.xpath(TextboxPath));
					//List<WebElement> TextBoxes = driver.get().findElements(By.xpath(TextboxPath));
					for(WebElement textbox: TextBoxes)
					{				        
						funclib.DelayTime();
						if(!textbox.isSelected())				    	
							textbox.sendKeys("Verified");				    				    	
					}
					
					//Checkbox on Verified Documents
					funclib.DelayTime();
					CheckboxVerify.click();
				 
					//Select Predominant Purpose
					funclib.DelayTime();
					String SelectIdentity= "Identification";
					funclib.DropdownListSelect(SelectIdentity, SelectIdentityType);
				 
					//Select Submission Process
					funclib.DelayTime();
					String SelectSubmission= "Upload";
					funclib.DropdownListSelect(SelectSubmission, SelectSubmissionType);
					
					//Upload File
					funclib.DelayTime();					
					UploadFile.sendKeys("C:\\Users\\abhishek.paspuleti\\eclipse-workspace\\Sample.pdf");				
					
					//Capture Screenshot
					funclib.CaptureScreenShot();
					
					//Navigate Next Page
					funclib.DelayTime();
					NextClick.click();
					
					//Select Verification Status
					funclib.DelayTime();
					String SelectDocumentationVerify= "Verified";
					funclib.DropdownListSelect(SelectDocumentationVerify,SelectDocumentVerify);
				
					//Capture Screenshot
					funclib.CaptureScreenShot();
						
					//Navigate Next Page
					funclib.DelayTime();
					NextClick.click();
					
					//Capture Screenshot
					funclib.CaptureScreenShot();
				}				
			}			
		}
		
		//Close Browser/Logging Out
		Thread.sleep(5000);
		LogOutClick.click();
		Thread.sleep(5000);
		//driver.close();
		//driver.get().close();
	}
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
		
		funclib.DelayTime();	
	}
}