package org.lendfast.pages.schedule;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MortgageLoanBreakups extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
	
	//Defining WebElements
	
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Mortgage Loan Disbursement Breakups')]")
	WebElement HeadSection;
	
	//Modify Link
	@FindBy(linkText="Modify")
	WebElement ModifyClick;
	
	//Maximum Link
	@FindBy(linkText="Maximum")
	WebElement MaximumClick;
	
	//Payable Type
	@FindBy(xpath="//textarea[@id='main:disbursepayableTo:disbursepayableTo']")
	WebElement InputPayableTo;
	
	//Payable To
	@FindBy(xpath="//select[@id='main:disbursepayableType:disbursepayableType']")
	WebElement SelectPayableType;
	
	//Input Customer Account Number
	@FindBy(xpath="//input[@id='main:disbursememAcctNum:disbursememAcctNum']")
	WebElement InputCustomerAccount;
	
	//Input Amount
	@FindBy(xpath="//input[@id='main:disburseamount:disburseamount']")
	WebElement InputAmountValue;
	
	//Proceed under Progress Payment
	@FindBy(xpath="//select[@id='main:progressPayment:progressPayment']")
	WebElement SelectProgressPayType;
	
	//Purchase Real Estate Authorise - Purchase Builder 
	@FindBy(xpath="//td/a[@id = 'main:disbList_constructpurpose:1:modifyBrkUpBtn']")
	WebElement PurchaseBuilderClick;
	
	//Purchase Real Estate Authorise - Construction Builder
	@FindBy(xpath="//td/a[@id = 'main:disbList_constructpurpose:0:modifyBrkUpBtn']")
	WebElement ConstructionBuilderClick;
	
	//First Draw - Yes
	@FindBy(xpath="//input[@id = 'main:disburseisFirstConstructionDraw:disburseisFirstConstructionDraw:0']")
	WebElement RadioFirstDrawYes;
	
	//First Draw - No
	@FindBy(xpath="//input[@id = 'main:disburseisFirstConstructionDraw:disburseisFirstConstructionDraw:1']")
	WebElement RadioFirstDrawNo;
	
	//Final Draw - Yes
	@FindBy(xpath="//input[@id = 'main:disburseisFinalDraw:disburseisFinalDraw:0']")
	WebElement RadioFinalDrawYes;	
	
	//Final Draw - No
	@FindBy(xpath="//input[@id = 'main:disburseisFinalDraw:disburseisFinalDraw:1']")
	WebElement RadioFinalDrawNo;
	
	//Construction Authorise
	@FindBy(xpath="//td/a[@id = 'main:disbList_constructpurpose:0:authoriseBrkUpBtn']")
	WebElement ConstructionAuthoriseClick;
	
	//Purchase Authorise
	@FindBy(xpath="//td/a[@id = 'main:disbList_constructpurpose:1:authoriseBrkUpBtn']")
	WebElement PurchaseAuthoriseClick;
	
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
		
	//Constructor
	public MortgageLoanBreakups()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Mortgage Loan Disbursement Breakups");		
		return HeadSectionResult;
	}
	
	//Proposed Disbursement Details
	public void DisbursementMaximumItemMethod() throws InterruptedException
	{
		//Click on Modify Link
		ModifyClick.click();
		funclib.DelayTime();
		
		//Maximum Click
		WebDriverWait wait = new WebDriverWait(driver, 25);
		Actions action = new Actions(driver);	
		
		//WebDriverWait wait = new WebDriverWait(driver.get(), 25);
		//Actions action = new Actions(driver.get());
		
		WebElement MaxClick = wait.until(ExpectedConditions.elementToBeClickable(MaximumClick));
		java.util.List<WebElement> MaxLink=driver.findElements(By.linkText("Maximum"));	
		//java.util.List<WebElement> MaxLink=driver.get().findElements(By.linkText("Maximum"));
		
		for(int MaximumCounter=1;MaximumCounter<=MaxLink.size();MaximumCounter++)
		{
			funclib.DelayTime();
			action.moveToElement(MaxClick).doubleClick(MaxClick).perform();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
		}
		
		//Navigate Next Page
		funclib.DelayTime();
		NextClick.click();		
	}
	
	//Account Information for Disbursement Details
	public String AccountDisbursementDetails(String PayableType) throws InterruptedException
	{
		//Click on Modify Link
		ModifyClick.click();
		funclib.DelayTime();
		
		//Navigate Next Page
		funclib.DelayTime();
		NextClick.click();
		
		//Select Payable Type
		String SelectOption = PayableType;
		String SelPayableType = funclib.DropdownListSelect(SelectOption, SelectPayableType);
		return SelPayableType;		
	}
	
	// Input Customer Account Number
	public void InputCustAccountNumber(String CustomerAccountNumber) throws InterruptedException
	{
		funclib.DelayTime();
		
		//Input Customer Account Number
		InputCustomerAccount.clear();
		funclib.DelayTime();
		InputCustomerAccount.sendKeys(CustomerAccountNumber);
		funclib.DelayTime();
		System.out.println("Customer Account Number" + CustomerAccountNumber);
	}
	
	// Input Amount (Customer Account Number)
	public void InputCustAmount(String CustomerAmount) throws InterruptedException
	{
		funclib.DelayTime();
		
		//Input Customer Amount
		InputAmountValue.clear();
		funclib.DelayTime();
		InputAmountValue.sendKeys(CustomerAmount);		
		funclib.DelayTime();
		System.out.println("Amount Value" + CustomerAmount);
	}
	
	public String DisbursementPayableTypeMethod(String PayableType)
	{
		//Select Payable Type
		String SelectOption = PayableType;
		String SelPayableType = funclib.DropdownListSelect(SelectOption, SelectPayableType);
		return SelPayableType;		
	}
	
	public void DisbursementPayableToMethod(String PayableTo) throws InterruptedException
	{
		//Select Payable To
		InputPayableTo.clear();
		funclib.DelayTime();
		
		InputPayableTo.sendKeys(PayableTo);
		funclib.DelayTime();
		
		System.out.println("Payable To:" + PayableTo);
	}
	
	//Proceed under Progress Payment
	public String ProgressPaymentTypeMethod(String ProgressPayType)
	{
		//Select Progress Payment Type
		String SelectOption = ProgressPayType;
		String SelProgressPayType = funclib.DropdownListSelect(SelectOption, SelectProgressPayType);
		return SelProgressPayType;		
	}
	
	//Purchase Builder Click
	public void ModifyPurchaseBuilderClick() throws InterruptedException
	{
		funclib.DelayTime();
		PurchaseBuilderClick.click();
	}
	
	//Purchase Authorise Click
	public void AuthorisePurchaseBuilderClick() throws InterruptedException
	{
		funclib.DelayTime();
		PurchaseAuthoriseClick.click();
	}
	
	//Construction Builder Click
	public void ModifyConstructionBuilderClick() throws InterruptedException
	{
		funclib.DelayTime();
		ConstructionBuilderClick.click();
	}
	
	//Construction Authorise Click
	public void AuthoriseConstructionBuilderClick() throws InterruptedException
	{
		funclib.DelayTime();
		ConstructionAuthoriseClick.click();
	}
	
	//Select First Construction Draw
	public String SelFirstConstructDraw(String FirstDraw) throws InterruptedException
	{		
		String OptionValue = FirstDraw;		
		String FirstDrawResult= funclib.SelOptionValue(RadioFirstDrawYes, RadioFirstDrawYes.getAttribute("value"),RadioFirstDrawNo,RadioFirstDrawNo.getAttribute("value"),OptionValue);	
		return FirstDrawResult;		
	}
	
	//Select Final Construction Draw
	public String SelFinalConstructDraw(String FinalDraw) throws InterruptedException
	{		
		String OptionValue = FinalDraw;		
		String FinalDrawResult= funclib.SelOptionValue(RadioFinalDrawYes, RadioFinalDrawYes.getAttribute("value"),RadioFinalDrawNo,RadioFinalDrawNo.getAttribute("value"),OptionValue);	
		return FinalDrawResult;		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
