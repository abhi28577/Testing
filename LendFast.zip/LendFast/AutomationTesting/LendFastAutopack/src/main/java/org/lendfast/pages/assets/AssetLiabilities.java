package org.lendfast.pages.assets;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AssetLiabilities extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
						
	//Defining WebElements
						
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Asset / Liabilities')]")
	WebElement HeadSection;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Modify Link 1
	@FindBy(xpath="//a[@id='main:liabilityList:0:modifyBtn']")
	WebElement ModifyClick1;
	
	//Modify Link 2
	@FindBy(xpath="//a[@id='main:liabilityList:1:modifyBtn']")
	WebElement ModifyClick2;		
		
	//Modify Link 3
	@FindBy(xpath="//a[@id='main:liabilityList:2:modifyBtn']")
	WebElement ModifyClick3;
	
	//Modify Link 4
	@FindBy(xpath="//a[@id='main:liabilityList:3:modifyBtn']")
	WebElement ModifyClick4;
	
	//Modify Link 5
	@FindBy(xpath="//a[@id='main:liabilityList:4:modifyBtn']")
	WebElement ModifyClick5;
	
	//Modify Link 6
	@FindBy(xpath="//a[@id='main:liabilityList:5:modifyBtn']")
	WebElement ModifyClick6;
	
	//Advance Payment Value
	@FindBy(xpath="//input[@id='main:liabadvancePayment:liabadvancePayment']")
	WebElement CheckAdvancePayment;
	
	//Advance Payment Interested - Yes
	@FindBy(xpath="//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:0']")
	WebElement RadioAdvancePaymentYes;	
	
	//Advance Payment Interested - No
	@FindBy(xpath="//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:1']")
	WebElement RadioAdvancePaymentNo;	
	
	//Debt Repaid - Fully
	@FindBy(xpath="//input[@id='main:liabbeingRepaid:liabbeingRepaid:0']")
	WebElement RadioDebtRepaidFull;
		
	//Debt Repaid - Partially
	@FindBy(xpath="//input[@id='main:liabbeingRepaid:liabbeingRepaid:1']")
	WebElement RadioDebtRepaidPartial;
			
	//Debt Repaid - Not At All
	@FindBy(xpath="//input[@id='main:liabbeingRepaid:liabbeingRepaid:2']")	
	WebElement RadioDebtRepaidNA;
	
	//Debt Cleared - Fully
	@FindBy(xpath="//input[@id='main:liabbeingCleared:liabbeingCleared:0']")
	WebElement RadioDebtClearedFull;
			
	//Debt Cleared - Partially
	@FindBy(xpath="//input[@id='main:liabbeingCleared:liabbeingCleared:1']")
	WebElement RadioDebtClearedPartial;
				
	//Debt Cleared - Not At All
	@FindBy(xpath="//input[@id='main:liabbeingCleared:liabbeingCleared:2']")
	WebElement RadioDebtClearedNA;
	
	//Constructor
	public AssetLiabilities()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
				
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Asset / Liabilities");		
		return HeadSectionResult;
	}
	
	//Modify Each Party Type
	public void ModifyParty(String LiabRepaid, String LiabCleared) throws InterruptedException
	{
		//Initializing Variables
		String Check1="FULL";
		String Check2 = "PARTIAL";
		String Check3="NONE";
		
		//Check if Advance Payment > $0.00
		String AdvancePay = "$0.00";
		
		//Modifying Existing NPBS Liability Details
		java.util.List<WebElement> ModifyLink=driver.findElements(By.linkText("Modify"));
		//java.util.List<WebElement> ModifyLink=driver.get().findElements(By.linkText("Modify"));
		
		System.out.println("Modify Count: " + ModifyLink.size());
		
		for(int ModifyCounter=1; ModifyCounter<=ModifyLink.size(); ModifyCounter++)
		{
			//If Modify Link exists in First Row
			if(ModifyCounter==1)
			{
				ModifyClick1.click();
				funclib.DelayTime();
			}
			
			//If Modify Link exists in Second Row
			if(ModifyCounter==2)
			{
				ModifyClick2.click();
				funclib.DelayTime();
			}
			
			//If Modify Link exists in Third Row
			if(ModifyCounter==3)
			{
				ModifyClick3.click();
				funclib.DelayTime();
			}
			
			//If Modify Link exists in Fourth Row
			if(ModifyCounter==4)
			{
				ModifyClick4.click();
				funclib.DelayTime();
			}
						
			//If Modify Link exists in Fifth Row
			if(ModifyCounter==5)
			{
				ModifyClick5.click();
				funclib.DelayTime();
			}
				
			
			//If Modify Link exists in Sixth Row
			if(ModifyCounter==6)
			{
				ModifyClick6.click();
				funclib.DelayTime();
			}			
						
			//Advance Payment
			int CheckAdvancePayCount = driver.findElements(By.xpath("//input[@id='main:liabadvancePayment:liabadvancePayment']")).size();
			
			if(CheckAdvancePayCount> 0)
			{
				if(!AdvancePay .equals(CheckAdvancePayment.getAttribute("value")))
				{
					if(RadioAdvancePaymentYes.isDisplayed())
					{
						funclib.DelayTime();
						RadioAdvancePaymentYes.click();
					}
				}
			}
			
			//Debt Repaid
			if(LiabRepaid .equals(Check1))
			{
				funclib.DelayTime();
				RadioDebtRepaidFull.click();
			}
			
			if(LiabRepaid .equals(Check2))
			{
				funclib.DelayTime();
				RadioDebtRepaidPartial.click();
			}		
				
			
			if(LiabRepaid .equals(Check3))
			{
				funclib.DelayTime();				
				RadioDebtRepaidNA.click();
			}
			
			funclib.DelayTime();
			
			//Debt Cleared
			
			if(LiabCleared .equals(Check1))
			{
				funclib.DelayTime();
				RadioDebtClearedFull.click();
			}
			
			if(LiabCleared .equals(Check2))
			{
				funclib.DelayTime();
				RadioDebtClearedPartial.click();
			}
			
			if(LiabCleared .equals(Check3))
			{
				funclib.DelayTime();
				RadioDebtClearedNA.click();
			}
			
			//Next Page
			funclib.DelayTime();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			funclib.DelayTime();
			NextClick.click();
			funclib.DelayTime();			
		}
	}	
	
	//Click on Next Link
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}	
	
}
