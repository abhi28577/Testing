package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_BuilderRisk extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
							
	//Defining WebElements
							
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Builder All Risk Details')]")
	WebElement HeadSection;
	
	//Copy of Builder's Risk Insurance - Yes
	@FindBy(xpath="//input[@id='main:purposebuildInsinsPolpolicyNewExisting:purposebuildInsinsPolpolicyNewExisting:0']")
	WebElement RadioRiskInsuranceYes;
	
	//Copy of Builder's Risk Insurance - No
	@FindBy(xpath="//input[@id='main:purposebuildInsinsPolpolicyNewExisting:purposebuildInsinsPolpolicyNewExisting:1']")
	WebElement RadioRiskInsuranceNo;
	
	//Select Insurance Company Code
	@FindBy(xpath="//select[@id='main:purposebuildInsinsPolcompanyCode:purposebuildInsinsPolcompanyCode']")
	WebElement SelectInsuranceCode;
	
	//Select Insurance Type
	@FindBy(xpath="//select[@id='main:purposebuildInsinsPolinsType:purposebuildInsinsPolinsType']")
	WebElement SelectInsuranceType;
	
	//Input Policy Number
	@FindBy(xpath="//input[@id='main:purposebuildInsinsPolpolicyNum:purposebuildInsinsPolpolicyNum']")
	WebElement InputPolicyNumber;
	
	//Input Expiry Date
	@FindBy(xpath="//input[@id='main:purposebuildInsinsPolexpiryDate:purposebuildInsinsPolexpiryDateInputDate']")
	WebElement InputExpiryDate;
	
	//Input Comments
	@FindBy(xpath="//input[@id='main:purposebuildInsinsPolcomments:purposebuildInsinsPolcomments']")
	WebElement InputComments;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	
	//Constructor
	public Purpose_BuilderRisk()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Builder All Risk Details");		
		return HeadSectionResult;
	}
	
	//Select Copy of Builder's Risk Insurance
	public String SelBuilderInsurance(String BuilderInsurance) throws InterruptedException
	{		
		String OptionValue = BuilderInsurance;		
		String BuilderInsuranceResult= funclib.SelOptionValue(RadioRiskInsuranceYes, RadioRiskInsuranceYes.getAttribute("value"),RadioRiskInsuranceNo,RadioRiskInsuranceNo.getAttribute("value"),OptionValue);	
		return BuilderInsuranceResult;		
	}
	
	//Select Insurance Company Code
	public String SelInsuranceCode(String InsuranceCode)
	{
		String SelectOption = InsuranceCode;
		String SelInsuranceCode = funclib.DropdownListSelect(SelectOption, SelectInsuranceCode);
		return SelInsuranceCode;		
	}
	
	//Select Insurance Type
	public String SelInsuranceType(String InsuranceType)
	{
		String SelectOption = InsuranceType;
		String SelInsuranceType = funclib.DropdownListSelect(SelectOption, SelectInsuranceType);
		return SelInsuranceType;		
	}
	
	//Input Insurance Policy Number
	public void InputPolicyNumber(String PolicyNumber) throws InterruptedException
	{
		InputPolicyNumber.sendKeys(PolicyNumber);
		funclib.DelayTime();		
	}
	
	//Input Expiry Date
	public void InputExpiryDate(String ExpiryDate) throws InterruptedException
	{
		InputExpiryDate.sendKeys(ExpiryDate);
		funclib.DelayTime();		
	}
	
	//Input Comments
	public void InputComments(String Comments) throws InterruptedException
	{
		InputComments.sendKeys(Comments);
		funclib.DelayTime();		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
