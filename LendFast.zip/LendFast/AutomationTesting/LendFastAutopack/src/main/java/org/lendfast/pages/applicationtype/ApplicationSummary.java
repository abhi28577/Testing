package org.lendfast.pages.applicationtype;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicationSummary extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
		
	//Define WebElements
		
	//Define Application Type
	@FindBy(xpath="//div[contains(text(),'Application Summary')]")
	WebElement HeadSection;
	
	//Search Application Id
	@FindBy(xpath="//input[@id='main:searchAppRegionInputtempValue']")
	WebElement SearchApplicationId;
	
	//Take Ownership Link
	@FindBy(linkText="Take ownership")
	WebElement OwnershipClick;
	
	//Open Click
	@FindBy(linkText="Open")
	WebElement OpenClick;
	
	//Securities Click
	@FindBy(linkText="Securities")
	WebElement SecuritiesClick;
	
	//Solicitors Click
	@FindBy(linkText="Solicitors")
	WebElement SolicitorsClick;
	
	//Checklist Click
	@FindBy(linkText="Checklist")
	WebElement ChecklistClick;
	
	//Returned Documents Click
	@FindBy(linkText="Returned Documents")
	WebElement ReturnDocClick;
	
	//Schedule Click
	@FindBy(linkText="Schedule")
	WebElement ScheduleClick;
	
	//Action Click
	@FindBy(xpath = "//a[@id='main:navMenu:13:menulink']")
	WebElement ActionClick;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public ApplicationSummary()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}	
	
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Application Summary");		
		return HeadSectionResult;
	}
	
	//Searching Application Id
	public void SearchApplication(String ApplicationId) throws InterruptedException
	{
		//Input Application Id
		Thread.sleep(2000);		
		SearchApplicationId.clear();
		Thread.sleep(2000);
		SearchApplicationId.sendKeys(ApplicationId);
		Thread.sleep(2000);
		
		Actions action = new Actions(driver);
		//Actions action = new Actions(driver.get());
		Thread.sleep(1000);
		action.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(5000);
	}
	
	//Click on Take Ownership Link
	public void TakeOwnership() throws InterruptedException
	{	
		OwnershipClick.click();
		//OpenClick.click();		
		funclib.DelayTime();
		Thread.sleep(2000);
		//SecuritiesClick.click();
		//ScheduleClick.click();
		//ActionClick.click();
		//ChecklistClick.click();
		//ReturnDocClick.click();
		//SolicitorsClick.click();
		funclib.DelayTime();
	}
	
	//Click on Open Link
	public void OpenApp() throws InterruptedException
	{			
		OpenClick.click();
		funclib.DelayTime();		
		funclib.DelayTime();
	}
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();		
	}

}
