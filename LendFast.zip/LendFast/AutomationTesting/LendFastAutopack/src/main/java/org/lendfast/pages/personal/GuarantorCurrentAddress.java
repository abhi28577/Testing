package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GuarantorCurrentAddress extends ParentPage 
{
	// Initialize Functions
		CommonFuncLib funclib;
						
		//Defining WebElements
						
		//Define Heading Section
		@FindBy(xpath="//div[contains(text(),'Current Address for Guarantor')]")
		WebElement HeadSection;
		
		//Select Residential Status
		@FindBy(xpath="//select[@id='main:partyresidenceStatus:partyresidenceStatus']")
		WebElement SelectResidentialStatus;
		
		//Input Resident Stay Years
		@FindBy(xpath="//input[@id='main:partyresadrHistyears:partyresadrHistyears']")
		WebElement ResidentYear;
		
		//Input Resident Stay Months
		@FindBy(xpath="//input[@id='main:partyresadrHistmonths:partyresadrHistmonths']")
		WebElement ResidentMonth;
		
		//Postal Address Same as Resident Address - Yes
		@FindBy(xpath="//input[@id='main:samePostalAddress:samePostalAddress:0']")
		WebElement RadioPostalAddrYes;
		
		//Postal Address Same as Resident Address - No
		@FindBy(xpath="//input[@id='main:samePostalAddress:samePostalAddress:1']")
		WebElement RadioPostalAddrNo;
		
		//Select Residency Status
		@FindBy(xpath="//select[@id='main:partyresidencyStatus:partyresidencyStatus']")
		WebElement SelectResidencyStatus;
		
		//Next Click
		@FindBy(xpath="//input[@id='main:next']")
		WebElement NextClick;
		
		//Constructor
		public GuarantorCurrentAddress()
		{			
			PageFactory.initElements(driver, this);
			//PageFactory.initElements(driver.get(), this);
			funclib=new CommonFuncLib();
		}
							
		//Capturing Head Section
		public String CaptureHeadSection()
		{
			String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Current Address for Guarantor");
			
			return HeadSectionResult;
		}
		
		//Select Residential Type
		public String SelResidentialType(String ResidentialStat)
		{
			String SelectOption = ResidentialStat;
			String SelResidentialStatus = funclib.DropdownListSelect(SelectOption, SelectResidentialStatus);
			return SelResidentialStatus;		
		}
		
		//Input Stay at Same Residence in Years
		public void InputAddressYears(String ResidentialYears) throws InterruptedException
		{
			ResidentYear.clear();
			ResidentYear.sendKeys(ResidentialYears);
			funclib.DelayTime();
		}
		
		//Input Stay at Same Residence in Months
		public void InputAddressMonths(String ResidentialMonths) throws InterruptedException
		{
			ResidentMonth.clear();
			ResidentMonth.sendKeys(ResidentialMonths);
			funclib.DelayTime();
		}
		
		//Select Applicant Postal Address same as Residential Address
		public String SelPostalAddressType(String PostalAddressSame) throws InterruptedException
		{		
			String OptionValue = PostalAddressSame;		
			String OptionResult= funclib.SelOptionValue(RadioPostalAddrYes, RadioPostalAddrYes.getAttribute("value"),RadioPostalAddrNo,RadioPostalAddrNo.getAttribute("value"),OptionValue);	
			return OptionResult;		
		}
		
		//Select Residency Status
		public String SelResidencyStatus(String ResidencyStat) throws InterruptedException
		{
			String SelectOption = ResidencyStat;
			String SelResidencyStatus = funclib.DropdownListSelect(SelectOption, SelectResidencyStatus);		
			return SelResidencyStatus;		
		}
		
		public void NextPage() throws InterruptedException
		{
			//Navigate to Next Page
			funclib.DelayTime();
			NextClick.click();	
		}
}
