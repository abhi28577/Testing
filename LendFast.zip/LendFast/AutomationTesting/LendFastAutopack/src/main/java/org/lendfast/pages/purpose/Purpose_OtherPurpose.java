package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_OtherPurpose extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
									
	//Defining WebElements
							
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Other Purpose')]")
	WebElement HeadSection;
	
	//Select Other Purpose
	@FindBy(xpath="//select[@id='main:purposepurp:purposepurp']")
	WebElement SelectOtherPurpose;
	
	//Select Payment Type
	@FindBy(xpath="//select[@id='main:purposepayableType:purposepayableType']")
	WebElement SelectPaymentType;
	
	//Input Payable To
	@FindBy(xpath="//textarea[@id='main:purposepayableTo:purposepayableTo']")
	WebElement InputPayableTo;
	
	//Input Account Number
	@FindBy(xpath="//input[@id='main:purposememAccNum:purposememAccNum']")
	WebElement InputAccountNumber;
	
	//Input Amount Required
	@FindBy(xpath="//input[@id='main:purposeamount:purposeamount']")
	WebElement InputAmountRequired;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Purpose_OtherPurpose()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Other Purpose");		
		return HeadSectionResult;
	}
	
	//Select Other Purpose Type
	public String SelOtherPurpose(String OtherPurpose)
	{
	
		String SelectOption = OtherPurpose;
		String SelOtherPurposeType = funclib.DropdownListSelect(SelectOption, SelectOtherPurpose);
		return SelOtherPurposeType;		
	}
	
	//Select Payment Type
	public String SelPayment(String Payment)
	{
	
		String SelectOption = Payment;
		String SelPaymentType = funclib.DropdownListSelect(SelectOption, SelectPaymentType);
		return SelPaymentType;		
	}
	
	//Input Payable To
	public void InputPayableTo(String PayableTo) throws InterruptedException
	{
		InputPayableTo.clear();
		funclib.DelayTime();
		InputPayableTo.sendKeys(PayableTo);
		funclib.DelayTime();		
	}
	
	//Input Account Number
	public void InputAccountNumber(String CustAccountNumber) throws InterruptedException
	{
		InputAccountNumber.clear();
		funclib.DelayTime();
		InputAccountNumber.sendKeys(CustAccountNumber);
		funclib.DelayTime();		
	}
	
	//Input Amount Required
	public void InputAmountRequired(String Amount) throws InterruptedException
	{
		InputAmountRequired.clear();
		funclib.DelayTime();
		InputAmountRequired.sendKeys(Amount);
		funclib.DelayTime();		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
