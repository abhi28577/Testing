package org.lendfast.pages.securities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SecuritiesRecordValuation extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
								
	//Defining WebElements
							
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Record Accept Valuation Details')]")
	WebElement HeadSection;
		
	//Record Valuation Declaration - Yes
	@FindBy(xpath="//input[@id='main:isAcceptable:isAcceptable:0']")
	WebElement RadioRecordValuationYes;
					
	//Record Valuation Declaration - No
	@FindBy(xpath="//input[@id='main:isAcceptable:isAcceptable:1']")
	WebElement RadioRecordValuationNo;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
		
	//Constructor
	public SecuritiesRecordValuation()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Record Accept Valuation Details");		
		return HeadSectionResult;
	}
	
	//Select Declaration
	public String SelDeclarationType(String Declare) throws InterruptedException
	{		
		String OptionValue = Declare;		
		String DeclarationResult= funclib.SelOptionValue(RadioRecordValuationYes, RadioRecordValuationYes.getAttribute("value"),RadioRecordValuationNo,RadioRecordValuationNo.getAttribute("value"),OptionValue);	
		return DeclarationResult;		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}

}
