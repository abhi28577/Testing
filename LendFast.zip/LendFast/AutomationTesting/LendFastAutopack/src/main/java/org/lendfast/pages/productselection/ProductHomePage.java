package org.lendfast.pages.productselection;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductHomePage extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
					
	//Defining WebElements
				
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Products Summary')]")
	WebElement HeadSection;
	
	//Add Product Link
	@FindBy(xpath="//input[@id='main:loanCompAddBtn']")
	WebElement AddProductClick;
	
	//Constructor
	public ProductHomePage()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
						
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Products Summary");
		
		return HeadSectionResult;
	}
	
	//Navigate to Product Selection Page
	public void AddProductPage() throws InterruptedException
	{		
		funclib.DelayTime();
		AddProductClick.click();	
	}
	
	
}
