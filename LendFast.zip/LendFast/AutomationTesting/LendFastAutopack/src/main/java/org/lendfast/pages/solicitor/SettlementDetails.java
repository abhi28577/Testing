package org.lendfast.pages.solicitor;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SettlementDetails extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
	
	//Defining WebElements
	
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Settlement Details')]")
	WebElement HeadSection;
	
	//Settlement Status
	@FindBy(xpath="//select[@id='main:SettlementStatus:SettlementStatus']")
	WebElement SelectSettlementStatus;
	
	//Expected Settlement Date
	@FindBy(xpath="//input[@id='main:SettlementDate:settlementDateInputDate']")
	WebElement InputSettlementDate;
	
	//Settlement Time
	@FindBy(xpath="//input[@id='main:actualSettlementTime:actualSettlementTime']")
	WebElement InputSettlementTime;
	
	//Place
	@FindBy(xpath="//input[@id='main:placeOfSettlement:placeOfSettlement']")
	WebElement InputPlace;
	
	//Lender Representation Type
	@FindBy(xpath="//select[@id='main:agentTypeChoice:agentTypeChoice']")
	WebElement SelectLenderType;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
		
	//Constructor
	public SettlementDetails()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Settlement Details");		
		return HeadSectionResult;
	}
	
	//Select Settlement Status
	public String SettlementStat(String SettlementStatus)
	{
		String SelectOption = SettlementStatus;
		String SelectSettlement = funclib.DropdownListSelect(SelectOption, SelectSettlementStatus);
		return SelectSettlement;
	}
	
	//Input Expected Settlement Date
	public void InputSettlementDate(String SettlementDate) throws InterruptedException
	{
		InputSettlementDate.clear();
		funclib.DelayTime();
		InputSettlementDate.sendKeys(SettlementDate);
		funclib.DelayTime();		
	}
	
	//Input Expected Settlement Time
	public void InputSettlementTime(String SettlementTime) throws InterruptedException
	{
		InputSettlementTime.clear();
		funclib.DelayTime();
		InputSettlementTime.sendKeys(SettlementTime);
		funclib.DelayTime();	
	}
	
	//Input Place
	public void InputSettlementPlace(String SettlementPlace) throws InterruptedException
	{
		InputPlace.clear();
		funclib.DelayTime();
		InputPlace.sendKeys(SettlementPlace);
		funclib.DelayTime();	
	}
	
	//Select Lender Representation Type
	public String SelLenderType(String LenderType)
	{
		String SelectOption = LenderType;
		String SelectSettlement = funclib.DropdownListSelect(SelectOption, SelectLenderType);
		return SelectSettlement;
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
