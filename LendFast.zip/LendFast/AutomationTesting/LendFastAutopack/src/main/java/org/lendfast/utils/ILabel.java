package org.lendfast.utils;

public interface ILabel {
	public String getText();

	public boolean isDisplayed();

	public boolean isEnabled();

}
