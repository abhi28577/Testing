package org.lendfast.pages.schedule;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MortgageLoanSchedule extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
	
	//Defining WebElements
	
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Mortgage Loan Funding Schedule')]")
	WebElement HeadSection;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
		
	//Constructor
	public MortgageLoanSchedule()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Mortgage Loan Funding Schedule");		
		return HeadSectionResult;
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
