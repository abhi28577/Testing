package org.lendfast.pages.assets;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AssetPropertyDetail extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
					
	//Defining WebElements
					
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Enter Property asset details')]")
	WebElement HeadSection;
		
	//Address Text
	@FindBy(xpath="//input[@id='main:propertyAddress_Decorate:adr_streetSearch']")
	WebElement InputPropertyAddress;
		
	//Property Security Type - Yes
	@FindBy(xpath="//input[@id='main:assetisSecurity:assetisSecurity:0']")
	WebElement RadioPropertySecurityYes;
				
	//Property Security Type - No
	@FindBy(xpath="//input[@id='main:assetisSecurity:assetisSecurity:1']")
	WebElement RadioPropertySecurityNo;
	
	//Estimated Value
	@FindBy(xpath="//input[@id='main:assetvalue:assetvalue']")
	WebElement InputEstimatedValue;
	
	//Insured With
	@FindBy(xpath="//input[@id='main:assetinsurer:assetinsurer']")
	WebElement InputInsuranceCompany;
	
	//Investment Property - Yes
	@FindBy(xpath="//input[@id='main:assetisInvestment:assetisInvestment:0']")
	WebElement RadioInvestmentPropertyYes;
					
	//Investment Property - No
	@FindBy(xpath="//input[@id='main:assetisInvestment:assetisInvestment:1']")
	WebElement RadioInvestmentPropertyNo;
	
	//Amount Owe - Yes
	@FindBy(xpath="//input[@id='main:assethasAmountOwing:assethasAmountOwing:0']")
	WebElement RadioAmountOweYes;
						
	//Amount Owe - No
	@FindBy(xpath="//input[@id='main:assethasAmountOwing:assethasAmountOwing:1']")
	WebElement RadioAmountOweNo;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Manual Address - Australian Address - Yes
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_isAustralian:qasadr_isAustralian:0']")
	WebElement AustralianAddressYes;
				
	//Manual Address - Australian Address - No
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_isAustralian:qasadr_isAustralian:1']")
	WebElement AustralianAddressNo;
		
	//Manual Address - Property Name
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_bldgName:qasadr_bldgName']")
	WebElement InputPropertyName;
		
	//Manual Address - Unit/Flat
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_unitNumber:qasadr_unitNumber']")
	WebElement InputPropertyUnit;
		
	//Manual Address - Unit Level
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_floorNumber:qasadr_floorNumber']")
	WebElement InputPropertyLevel;
		
	//Manual Address - House Number
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_streetNumber:qasadr_streetNumber']")
	WebElement InputHouseNum;
		
	//Manual Address - Street Name
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_streetName:qasadr_streetName']")
	WebElement InputStreetName;
		
	//Manual Address - Street Type
	@FindBy(xpath="//select[@id='addressTabs:addrDetailsForm:qasadr_streetType:qasadr_streetType']")
	WebElement SelectStreetType;
		
	//Manual Address - Street Suffix
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_streetTypeSuffix:qasadr_streetTypeSuffix']")
	WebElement SelectStreetSuffix;
		
	//Manual Address - Suburb
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_suburb:qasadr_suburb']")
	WebElement InputSuburb;
		
	//Manual Address - State
	@FindBy(xpath="//select[@id='addressTabs:addrDetailsForm:qasadr_state:qasadr_state']")
	WebElement SelectState;
		
	//Manual Address - Postal Code
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:qasadr_postcode:qasadr_postcode']")
	WebElement InputPostalCode;
		
	//Manual Address - OK
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:okBtn']")
	WebElement OkClick;
		
	//Manual Address - Cancel
	@FindBy(xpath="//input[@id='addressTabs:addrDetailsForm:cancelBtn']")
	WebElement CancelClick;
	
	
	//Constructor
	public AssetPropertyDetail()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Enter Property asset details");		
		return HeadSectionResult;
	}
	
	//Input Manual Address
		public void InputManualAddress(String ManualAddress) throws InterruptedException
		{
			Actions action = new Actions(driver);
			//Actions action = new Actions(driver.get());
			InputPropertyAddress.sendKeys(ManualAddress);
			funclib.DelayTime();
			
			action.sendKeys(Keys.ARROW_DOWN).build().perform();
			Thread.sleep(4000);
			action.sendKeys(Keys.ENTER).build().perform();
			funclib.DelayTime();
		}
		
	//Input Manual Address Details
	public void InputManualAddressDetails(String AustralianAddress, String PropertyName, String HouseNum,String Unit, String Level,  String StreetName, String StreetType, String StreetSuffix, String Suburb, String State, String PostalCode) throws InterruptedException
	{		
		String StrAusAddress = AustralianAddress;
		String StrProperty = PropertyName;
		String StrUnit=Unit;
		String StrLevel = Level;		
		String StrHouseNum = HouseNum;
		String StrName = StreetName;
		String StrType = StreetType;
		String StrSuffix = StreetSuffix;
		String StrSuburb = Suburb;
		String StrState = State;
		String StrPostalCode = PostalCode;
		
		funclib.ManualAddressDetails(StrAusAddress,AustralianAddressYes,AustralianAddressNo,StrProperty,InputPropertyName,StrUnit,InputPropertyUnit,StrLevel,InputPropertyLevel,StrHouseNum, InputHouseNum,StrName,InputStreetName, StrType,SelectStreetType,StrSuffix, SelectStreetSuffix, StrSuburb,InputSuburb, StrState, SelectState,StrPostalCode, InputPostalCode);
		funclib.DelayTime();
		OkClick.click();		
	}
	
	//Select Property Security Type
	public String SelPropertySecurityType(String Security) throws InterruptedException
	{		
		String OptionValue = Security;		
		String ApprovalResult= funclib.SelOptionValue(RadioPropertySecurityYes, RadioPropertySecurityYes.getAttribute("value"),RadioPropertySecurityNo,RadioPropertySecurityNo.getAttribute("value"),OptionValue);	
		return ApprovalResult;		
	}
	
	//Input Estimated Value
	public void InputEstimatedValue(String AssetValue)
	{
		InputEstimatedValue.sendKeys(AssetValue);
	}
	
	//Input Insurance Company
	public void InputInsuranceValue(String Insurer)
	{
		InputInsuranceCompany.sendKeys(Insurer);
	}
	
	//Select Investment Property Type
	public String SelInvestmentPropertyType(String Investment) throws InterruptedException
	{		
		String OptionValue = Investment;		
		String ApprovalResult= funclib.SelOptionValue(RadioInvestmentPropertyYes, RadioInvestmentPropertyYes.getAttribute("value"),RadioInvestmentPropertyNo,RadioInvestmentPropertyNo.getAttribute("value"),OptionValue);	
		return ApprovalResult;
	}
	
	//Select Amount Owe Type
	public String SelAmountOweType(String AmountOwe) throws InterruptedException
	{		
		String OptionValue = AmountOwe;		
		String ApprovalResult= funclib.SelOptionValue(RadioAmountOweYes, RadioAmountOweYes.getAttribute("value"),RadioAmountOweNo,RadioAmountOweNo.getAttribute("value"),OptionValue);	
		return ApprovalResult;
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();
	}	
}
