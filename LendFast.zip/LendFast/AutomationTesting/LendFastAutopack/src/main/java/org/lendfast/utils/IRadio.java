package org.lendfast.utils;

public interface IRadio {
	public void click();

	public boolean isEnabled();

}
