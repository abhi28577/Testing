package org.lendfast.utils;

public interface IListbox {
	public void select(String text);

	public void select(int i);

	public void select();

	public boolean isFirstOptionEmpty();
	public void selectByVisibleText(String text);

	public void selectByIndex(int index);


	public String getFirstSelectedText();

	public int size();

	public boolean isDisplayed();


}
