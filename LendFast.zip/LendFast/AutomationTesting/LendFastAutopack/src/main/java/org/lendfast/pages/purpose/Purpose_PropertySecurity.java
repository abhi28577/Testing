package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_PropertySecurity extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
	String ProposedNames="";
					
	//Defining WebElements
				
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Property Security')]")
	WebElement HeadSection;
	
	//Select Purchase Contract Listed - Yes
	@FindBy(xpath="//input[@id='main:purposearePurchasersParties:purposearePurchasersParties:0']")
	WebElement RadioPurchaseContListedYes;
		
	//Select Purchase Contract Listed - No
	@FindBy(xpath="//input[@id='main:purposearePurchasersParties:purposearePurchasersParties:1']")
	WebElement RadioPurchaseContListedNo;
	
	//Capture Applicant Name
	@FindBy(xpath="//td[@id='main:linkedParties:0:j_id716']")
	WebElement ApplicantName;
	
	//Capture Guarantor Name
	@FindBy(xpath="//td[@id='main:linkedParties:1:j_id716']")
	WebElement GuarantorName;
	
	//Applicant Purchase Approver
	@FindBy(xpath="//a[@id='main:linkedParties:0:ownerBtn']")
	WebElement LinkApplicantApprove;
	
	//Applicant Purchaser?
	@FindBy(xpath="//td[@id='main:linkedParties:0:j_id719']")
	WebElement ApplicantPurchaseApprove;	
	
	//Guarantor Purchase Approver
	@FindBy(xpath="//a[@id='main:linkedParties:1:ownerBtn']")
	WebElement LinkGuarantorApprove;
	
	//Guarantor Purchaser?
	@FindBy(xpath="//td[@id='main:linkedParties:1:j_id719']")
	WebElement GuarantorPurchaseApprove;
	
	//Proposed Applicant/GuarantorName
	@FindBy(xpath="//textarea[@id='main:assettitleNames:assettitleNames']")
	WebElement ProposedName;
		
	//Proposed Owners Listed - Yes
	@FindBy(xpath="//input[@id='main:securityareAllOwnersParties:securityareAllOwnersParties:0']")
	WebElement RadioListedOwnerYes;	
	
	//Proposed Owners Listed - No
	@FindBy(xpath="//input[@id='main:securityareAllOwnersParties:securityareAllOwnersParties:1']")
	WebElement RadioListedOwnerNo;
	
	//Select SpellCheck Borrower - Yes
	@FindBy(xpath="//input[@id='main:purposeisNameMismatch:purposeisNameMismatch:0']")
	WebElement RadioSpellCheckYes;
	
	//Select SpellCheck Applicant - Yes
	@FindBy(xpath="//input[@id='main:securityhasRatesNameMismatch:securityhasRatesNameMismatch:0']")
	WebElement RadioApplicantSpellCheckYes;
	
	//Select SpellCheck Borrower - No
	@FindBy(xpath="//input[@id='main:purposeisNameMismatch:purposeisNameMismatch:1']")
	WebElement RadioSpellCheckNo;
	
	//Select SpellCheck Applicant - No
	@FindBy(xpath="//input[@id='main:securityhasRatesNameMismatch:securityhasRatesNameMismatch:1']")
	WebElement RadioApplicantSpellCheckNo;
	
	//Select Purchase through Real Agent - Yes
	@FindBy(xpath="//input[@id='main:purposeisViaREAgent:purposeisViaREAgent:0']")
	WebElement RadioRealAgentYes;
				
	//Select Purchase through Real Agent - No
	@FindBy(xpath="//input[@id='main:purposeisViaREAgent:purposeisViaREAgent:1']")
	WebElement RadioRealAgentNo;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Purpose_PropertySecurity()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Property Security");		
		return HeadSectionResult;
	}
	
	//Select Purchaser Contract List
	public String SelPurchaserContractList(String PurchaserContractList) throws InterruptedException
	{		
		String OptionValue = PurchaserContractList;		
		String PurchaserContractListResult= funclib.SelOptionValue(RadioPurchaseContListedYes, RadioPurchaseContListedYes.getAttribute("value"),RadioPurchaseContListedNo,RadioPurchaseContListedNo.getAttribute("value"),OptionValue);	
		return PurchaserContractListResult;		
	}
	
	//Click on Purchaser as Applicant and Capture Approver Text 	
	public String CaptureApplicantPurchaserApproval(String ApplicantPurchaser) throws InterruptedException
	{		
		String ApplicantPurchaseApproval = null;
		String ApprovalResult="Yes";
		String ApplicantPurchaserNo = "No";
		
		if((ApplicantPurchaser .equals(ApprovalResult)) && (ApplicantPurchaseApprove.getText() .equals(ApplicantPurchaserNo)))
		{
			LinkApplicantApprove.click();
			funclib.DelayTime();			
		}	
		
		if (ApplicantPurchaseApprove.getText() .equals(ApprovalResult))
		{
			ApplicantPurchaseApproval="Applicant Purchaser Approved: Passed";
			ProposedNames = ProposedNames + ApplicantName.getText();
		}	
		else		
			ApplicantPurchaseApproval="Applicant Purchaser Not Approved: Failed";			
		
		return  ApplicantPurchaseApproval;
	}	
	
	//Click on Purchaser as Guarantor and Capture Approver Text 	
	public String CaptureGuarantorPurchaserApproval(String GuarantorPurchaser) throws InterruptedException
	{
		String GuarantorPurchaseApproval = null;
		String ApprovalResult="Yes";
		
		if(GuarantorPurchaser .equals(ApprovalResult))
		{
			LinkGuarantorApprove.click();
			funclib.DelayTime();
		}
		
		if (GuarantorPurchaseApprove.getText() .equals(ApprovalResult))
		{
			GuarantorPurchaseApproval="Guarantor Purchaser Approved: Passed";
			ProposedNames = ProposedNames + " " + "and" + " " + GuarantorName.getText();
		}	
		else
			GuarantorPurchaseApproval="Guarantor Purchaser Not Approved: Passed";
		
		return  GuarantorPurchaseApproval;
	}
	
	//Validate Applicant Name matches with Proposed Applicant Name
	public String ApplicantGuarantorCompare()
	{
		String CompareResult=null;
		System.out.println("Proposed Name(s):" + ProposedNames);
		String ProposedNameActual = ProposedName.getText();
		if(ProposedNames .equals(ProposedNameActual))
			CompareResult = "Proposed Names: Match"; 
		else
			CompareResult = "Proposed Names: MisMatch";
		
		return CompareResult;
	}
	
	//Select Proposed Listed Owners
	public String SelListedProposedOwner(String ListedProposedOwner) throws InterruptedException
	{		
		String OptionValue = ListedProposedOwner;		
		String ProposedOwnerResult= funclib.SelOptionValue(RadioListedOwnerYes, RadioListedOwnerYes.getAttribute("value"),RadioListedOwnerNo,RadioListedOwnerNo.getAttribute("value"),OptionValue);	
		return ProposedOwnerResult;		
	}
	
	//Select SpellCheck Borrowers/Guarantors
	public String SelSpellCheck(String SpellCheck) throws InterruptedException
	{		
		String OptionValue = SpellCheck;		
		String SpellCheckResult= funclib.SelOptionValue(RadioSpellCheckYes, RadioSpellCheckYes.getAttribute("value"),RadioSpellCheckNo,RadioSpellCheckNo.getAttribute("value"),OptionValue);	
		return SpellCheckResult;		
	}
	
	//Select SpellCheck Applicant
	public String SelSpellCheckApplicant(String SpellCheck) throws InterruptedException
	{		
		String OptionValue = SpellCheck;		
		String SpellCheckResult= funclib.SelOptionValue(RadioApplicantSpellCheckYes, RadioApplicantSpellCheckYes.getAttribute("value"),RadioApplicantSpellCheckNo,RadioApplicantSpellCheckNo.getAttribute("value"),OptionValue);	
		return SpellCheckResult;		
	}
	
	//Select Purchase via Real Estate (Yes/No)
	public String SelPurchaseRealEstateAgent(String PurchaseRealEstateAgent) throws InterruptedException
	{		
		String OptionValue = PurchaseRealEstateAgent;		
		String RealEstateAgent= funclib.SelOptionValue(RadioRealAgentYes, RadioRealAgentYes.getAttribute("value"),RadioRealAgentNo,RadioRealAgentNo.getAttribute("value"),OptionValue);	
		return RealEstateAgent;		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
	
}
