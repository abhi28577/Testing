package org.lendfast.utils;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebElement;


public class Radio implements IRadio 
{
	private WebElement element;

	public Radio(WebElement element) 
	{
		this.element = element;
		if (!isRadioButton())
			throw new RuntimeException("not a button");
	}

	public void click() 
	{
		if (!this.isEnabled())
			throw new RuntimeException("button not enabled!");
		this.element.click();
	}

	private boolean isRadioButton() 
	{
		List<String> tags = Arrays.asList("input", "button");
		return tags.contains(this.element.getTagName());
	}

	public boolean isEnabled() 
	{
		return this.element.isEnabled();
	}

	public boolean isSelected() 
	{
		return this.element.isSelected();
	}

}
