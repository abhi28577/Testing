package org.lendfast.pages.decision;

import java.util.List;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Decision extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
					
	//Define WebElements
					
	//Define Application Type
	@FindBy(xpath="//div[contains(text(),'Decision')]")
	WebElement HeadSection;
	
	//Policy Result
	@FindBy(xpath="//td[@id='main:decisionList:0:j_id963']")
	WebElement PolicyResult;
	
	//Link Text OverRide
	@FindBy(linkText="Override")
	WebElement OverrideClick;
			
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
			
	//Constructor
	public Decision()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}	
				
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Decision");		
		return HeadSectionResult;
	}
	
	//Over-Ride Action
	public void DecisionOverride() throws InterruptedException
	{
		//String OverRideValue = "Override";
		//String OverRideFailValue = "Fail Override";	
		
		//Click on OverRide
		WebDriverWait wait = new WebDriverWait(driver, 25);
		Actions action = new Actions(driver);	
		
		//WebDriverWait wait = new WebDriverWait(driver.get(), 25);
		//Actions action = new Actions(driver.get());
		
		List<WebElement> MaxOverrideLink =driver.findElements(By.linkText("Override"));
		//List<WebElement> MaxOverrideLink =driver.get().findElements(By.linkText("Override"));
		if(!MaxOverrideLink.isEmpty())
		{
		
			WebElement OverRidClick = wait.until(ExpectedConditions.elementToBeClickable(OverrideClick));
			java.util.List<WebElement> MaxLink=driver.findElements(By.linkText("Override"));
			//java.util.List<WebElement> MaxLink=driver.get().findElements(By.linkText("Override"));
		
			if(MaxLink.size() > 0)
			{
				for(int OverRideCounter=1;OverRideCounter<=MaxLink.size();OverRideCounter++)
				{
					funclib.DelayTime();
					action.moveToElement(OverRidClick).doubleClick(OverRidClick).perform();
				
					System.out.println("Policy Result: Overridden");
			
					//Capture Screenshot
					funclib.CaptureScreenShot();
				}
			}
		}
		
		
		funclib.DelayTime();
		
	//	if(PolicyResult.getText() .equals(OverRideValue))
	//		OverrideClick.click();	
		
	//	if(PolicyResult.getText() .equals(OverRideFailValue))
	//		System.out.println("Policy Result: " + OverRideFailValue + " Matches");
	//	else
	//		System.out.println("Policy Result Already Matching!");
		
	}
			
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
}
