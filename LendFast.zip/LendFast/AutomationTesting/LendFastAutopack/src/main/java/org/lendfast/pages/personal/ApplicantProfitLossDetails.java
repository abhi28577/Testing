package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicantProfitLossDetails extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
								
	//Defining WebElements
								
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Profit and Loss Details')]")
	WebElement HeadSection;
	
	//Select Financial Year
	@FindBy(xpath="//select[@id='main:financialYearRepeat:0:financialYear:financialYearInput']")
	WebElement SelFinancialYear;
	
	//Select # of Months
	@FindBy(xpath="//select[@id='main:monthsRepeat:0:months:monthsInput']")
	WebElement SelMonths;
	
	//Select Audit Status
	@FindBy(xpath="//select[@id='main:auditStatusRepeat:0:auditStatus:auditStatusInput']")
	WebElement SelAuditStat;
	
	//Input TurnOver/Gross Sales
	@FindBy(xpath="//input[@id='main:grossTurnoverRepeat:0:grossTurnover:grossTurnoverInput']")
	WebElement GrossSalesValue;
	
	//Input Total Expenses
	@FindBy(xpath="//input[@id='main:totalExpensesRepeat:0:totalExpenses:totalExpensesInput']")
	WebElement TotalExpensesValue;
	
	//Input Depreciation
	@FindBy(xpath="//input[@id='main:depreciationRepeat:0:depreciation:depreciationInput']")
	WebElement DepreciationValue;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public ApplicantProfitLossDetails()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
									
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Profit and Loss Details");
		
		return HeadSectionResult;
	}
	
	//Select Financial Year
	public String SelFinanYearType(String FinYear)
	{
		String SelectOption = FinYear;
		String SelectFinancialYear = funclib.DropdownListSelect(SelectOption, SelFinancialYear);
		return SelectFinancialYear;		
	}
	
	//Select Financial Months
	public String SelFinanMonthsType(String FinMonths)
	{
		String SelectOption = FinMonths;
		String SelectFinancialMonths = funclib.DropdownListSelect(SelectOption, SelMonths);
		return SelectFinancialMonths;		
	}
	
	//Select Financial Audit
	public String SelFinanAuditType(String FinAudit)
	{
		String SelectOption = FinAudit;
		String SelectFinancialAudit = funclib.DropdownListSelect(SelectOption, SelAuditStat);
		return SelectFinancialAudit;		
	}
	
	//Input TurnOver/Gross Sales
	public void InputTurnOverSales(String FinTurnOver) throws InterruptedException
	{
		GrossSalesValue.sendKeys(FinTurnOver);
		funclib.DelayTime();
	}
	
	//Input Total Expenses
	public void InputTotalExpenses(String FinExpenses) throws InterruptedException
	{
		TotalExpensesValue.sendKeys(FinExpenses);
		funclib.DelayTime();
	}
	
	//Input Depreciation
	public void InputDepreciation(String FinDepreciation) throws InterruptedException
	{
		DepreciationValue.sendKeys(FinDepreciation);
		funclib.DelayTime();
	}
	
	public void NextPage() throws InterruptedException
	{
		//Navigate to Next Page
		funclib.DelayTime();
		NextClick.click();	
	}


}
