package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_ConstructionPurpose extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
								
	//Defining WebElements
								
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Construction Purpose')]")
	WebElement HeadSection;
	
	//Construction Purpose - Build
	@FindBy(xpath="//input[@id='main:purposeconstructionPurpose:purposeconstructionPurpose:0']")
	WebElement RadioConstructionBuild;
		
	//Construction Purpose - Major Renovation
	@FindBy(xpath="//input[@id='main:purposeconstructionPurpose:purposeconstructionPurpose:1']")
	WebElement RadioConstructionRenovation;
	
	//Select Construction Description
	@FindBy(xpath="//select[@id='main:purposeconstructionType:purposeconstructionType']")
	WebElement SelectConstructionType;
	
	//Input Construction Cost
	@FindBy(xpath="//input[@id='main:purposeconstructionCost:purposeconstructionCost']")
	WebElement InputConstructionCost;
	
	//Additional Improvement Costs - Yes
	@FindBy(xpath="//input[@id='main:anyAdditionalCosts:anyAdditionalCosts:0']")
	WebElement RadioAdditionalCostYes;
	
	//Additional Improvement Costs - No
	@FindBy(xpath="//input[@id='main:anyAdditionalCosts:anyAdditionalCosts:1']")
	WebElement RadioAdditionalCostNo;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Purpose_ConstructionPurpose()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
						
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Construction Purpose");		
		return HeadSectionResult;
	}
	
	//Select Construction Purpose
	public String SelConstructionPurpose(String ConstructionPurpose) throws InterruptedException
	{		
		String OptionValue = ConstructionPurpose;		
		String ConstructionPurposeResult= funclib.SelOptionValue(RadioConstructionBuild, RadioConstructionBuild.getAttribute("value"),RadioConstructionRenovation,RadioConstructionRenovation.getAttribute("value"),OptionValue);	
		return ConstructionPurposeResult;		
	}
	
	//Select Construction Description
	public String SelConstructionDescription(String ConstructionDescription)
	{
		String SelectOption = ConstructionDescription;
		String SelConstructionDesc = funclib.DropdownListSelect(SelectOption, SelectConstructionType);
		return SelConstructionDesc;		
	}
	
	//Input Construction Cost
	public void InputConstructionCost(String ConstructionCost) throws InterruptedException
	{
		InputConstructionCost.sendKeys(ConstructionCost);
		funclib.DelayTime();		
	}
	
	//Select Additional Improvement Costs
	public String SelAdditionalCost(String AdditionalCost) throws InterruptedException
	{		
		String OptionValue = AdditionalCost;		
		String ConstructionCostResult= funclib.SelOptionValue(RadioAdditionalCostYes, RadioAdditionalCostYes.getAttribute("value"),RadioAdditionalCostNo,RadioAdditionalCostNo.getAttribute("value"),OptionValue);	
		return ConstructionCostResult;		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
