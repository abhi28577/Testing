package org.lendfast.pages.action;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ActionHomePage extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
						
	//Define WebElements
						
	//Define Application Type
	@FindBy(xpath="//div[contains(text(),'Action')]")
	WebElement HeadSection;
	
	//Logout
	@FindBy(linkText="Logout")
	WebElement LogOutClick;
	
	//Select Cancel
	@FindBy(xpath="//input[@id='main:action:action:0']")
	WebElement CancelAction;
	
	//Select Assessment Status
	@FindBy(xpath="//input[@id='main:action:action:1']")
	WebElement AssessmentAction;
	
	//Select Decline
	@FindBy(xpath="//input[@id='main:action:action:2']")
	WebElement DeclineAction;
	
	//Select Full Approval
	@FindBy(xpath="//input[@id='main:action:action:3']")
	WebElement FullApprovalAction;
	
	//Select Complete outstanding checklist items
	@FindBy(xpath="//input[@id='main:action:action:3']")
	WebElement CompleteAction;
	
	//Select Change status to Contract Printed
	@FindBy(xpath="//input[@id='main:action:action:3']")
	WebElement ContractPrintedAction;
	
	//Select Documents Returned
	@FindBy(xpath="//input[@id='main:action:action:2']")
	WebElement DocumentsReturnedAction;
	
	//Select Change status to Ready For Settlement
	@FindBy(xpath="//input[@id='main:action:action:2']")
	WebElement SettlementReadyAction;
	
	//Select Load to Host / Fund Loan
	@FindBy(xpath="//input[@id='main:action:action:2']")
	WebElement LoadHostAction;
	
	//Select Load to Host / Fund Loan
	@FindBy(xpath="//input[@id='main:action:action:0']")
	WebElement LoadHostActionFinal;
	
	//Select Re-Submit
	@FindBy(xpath="//input[@id='main:action:action:4']")
	WebElement ResubmitAction;
	
	//Select Reset
	@FindBy(xpath="//input[@id='main:action:action:5']")
	WebElement ResetAction;
	
	//Select Transfer Ownership Group
	@FindBy(xpath="//input[@id='main:action:action:6']")
	WebElement TransferOwnershipAction;
	
	//Select Transfer Ownership Group
	@FindBy(xpath="//input[@id='main:action:action:1']")
	WebElement TransferOwnershipActionFinal;
				
	//Generate Contract Click Button
	@FindBy(xpath="//input[@id='main:genContractBtn']")
	WebElement GenerateContractClick;
	
	//Miscellaneous Document Link
	@FindBy(linkText="Documents")
	WebElement DocumentsLink;
	
	//Miscellaneous Upload Documents
	@FindBy(xpath="//span[@id = 'main:generateMiscellaneousDocuments:anchor']")
	WebElement UploadDocumentsLink;
	
	//Select Documents
	@FindBy(xpath="//input[@id = 'main:generateDocumentsButton']")
	WebElement GenerateDocument;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
				
	//Constructor
	public ActionHomePage()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}	
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Action");		
		return HeadSectionResult;
	}
	
	//Select Action Type
	public void ActionType(String ActionType) throws InterruptedException
	{
		//Select Action Type for Credit Analysis Submission
		String CancelActionType = "CANCEL";
		String AssessmentActionType = "REFER_TO_ASSESSOR_SECURITY";
		String DeclineActionType = "DECLINE";
		String FullApprovalActionType = "FULL_APPROVAL";
		String CompleteActionType = "COMP_CHECKLIST_ITEMS";
		String ContractPrintedActionType = "CHANGE_TO_PRINTED";
		String DocumentsReturnedActionType = "DOCUMENTS_RETURNED";
		String SettlementReadyActionType = "READY_FOR_SETTLEMENT";
		String LoadHostActionType = "LOAD_FUND_LOAN";
		String ResubmitActionType = "RE_SUBMIT";
		String ResetActionType = "RESET";
		String TransferOwnershipActionType = "TRANS_OWNER_TO_GROUP";
		
		funclib.DelayTime();
		//Action Type - Cancel
		if(ActionType .equals(CancelActionType))
			CancelAction.click();
		
		//Action Type - Change Status to Assessment
		if(ActionType .equals(AssessmentActionType))
			AssessmentAction.click();
		
		//Action Type - Decline
		if(ActionType .equals(DeclineActionType))
			DeclineAction.click();
		
		//Action Type - Full Approval
		if(ActionType .equals(FullApprovalActionType))
			FullApprovalAction.click();
		
		//Action Type - Complete outstanding checklist items
		if(ActionType .equals(CompleteActionType))
			CompleteAction.click();
		
		//Action Type - Change status to Contract Printed
		if(ActionType .equals(ContractPrintedActionType))
			ContractPrintedAction.click();
		
		//Action Type - Documents Returned
		if(ActionType .equals(DocumentsReturnedActionType))
			DocumentsReturnedAction.click();
		
		//Action Type - Change status to Ready For Settlement
		if(ActionType .equals(SettlementReadyActionType))
			SettlementReadyAction.click();
		
		//Action Type - Load to Host/Fund Loan
		if(ActionType .equals(LoadHostActionType))
			LoadHostAction.click();
		
		//Action Type - Re-Submit
		if(ActionType .equals(ResubmitActionType))
			ResubmitAction.click();
		
		//Action Type - Reset
		if(ActionType .equals(ResetActionType))
			ResetAction.click();
		
		//Action Type - Transfer Ownership to Group
		if(ActionType .equals(TransferOwnershipActionType))
			TransferOwnershipAction.click();
		
		funclib.DelayTime();
	}
	
	//Select Action Type
		public void ActionTypeHostUpload(String ActionType) throws InterruptedException
		{
			//Select Action Type for Credit Analysis Submission
			
			String LoadHostActionType = "LOAD_FUND_LOAN";						
			String TransferOwnershipActionType = "TRANS_OWNER_TO_GROUP";
			
			funclib.DelayTime();
			
			
			//Action Type - Load to Host/Fund Loan
			if(ActionType .equals(LoadHostActionType))
				LoadHostActionFinal.click();		
			
			//Action Type - Transfer Ownership to Group
			if(ActionType .equals(TransferOwnershipActionType))
				TransferOwnershipActionFinal.click();
			
			funclib.DelayTime();
		}
	
	
	//Click on Generate Contract
	public void GenerateContractButton() throws InterruptedException
	{
		//Click on Contract
		GenerateContractClick.click();
		funclib.DelayTime();
	}
	
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
		
		funclib.DelayTime();
		
		//Capture Screenshot
		funclib.CaptureScreenShot();		
						
		
	}
	
	//Click on Document Generation Tab
	public void DocGeneratorClick() throws InterruptedException
	{
		funclib.DelayTime();		
		//Click on Documents Link
		DocumentsLink.click();
		
		funclib.DelayTime();
		
		//Click on Miscellanous Documents Link
		UploadDocumentsLink.click();		
		funclib.DelayTime();
	}
	
	
	//Select Miscellaneous Documents
	public void MiscellaneousDocs(String DocList) throws InterruptedException
	{
		String DocType="null";
		//String SelectType="Select";		
		
		if(!DocList .equals(DocType))	
		{		
			//Select Document to be Generated against each Document Type
			WebElement SelectLink = driver.findElement(By.xpath("//td[contains(text(),'"+ DocList +"')]/following-sibling::td[3]/a[contains(text(),'Select')]"));
			//WebElement SelectLink = driver.get().findElement(By.xpath("//td[contains(text(),'"+ DocList +"')]/following-sibling::td[3]/a[contains(text(),'Select')]"));
			SelectLink.click();			
			funclib.DelayTime();
			
		}		
	}
	
	//Generate Documents
	public void GenerateDocuments() throws InterruptedException
	{
		funclib.DelayTime();
		
		//Generate Documents
		GenerateDocument.click();
		Thread.sleep(5000);
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Navigate to Next Page
		NextClick.click();
	}
	
	//User LogOut
	public void UserLogOut() throws InterruptedException
	{
		funclib.DelayTime();
		
		//Logging Out
		LogOutClick.click();
		
		funclib.DelayTime();
	}
}
