package org.lendfast.pages.topup;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TopUpLoanDetails extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
		
	//Defining WebElements
		
	//Define Origination Heading Section
	@FindBy(xpath="//div[contains(text(),'Mortgage Top Up Loan Details')]")
	WebElement HeadSection;
	
	//Advance Payment - Yes
	@FindBy(xpath="//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:0']")
	WebElement RadioAdvancePaymentYes;
	
	//Advance Payment - No
	@FindBy(xpath="//input[@id='main:loanCompmaintainAdvPayment:loanCompmaintainAdvPayment:1']")
	WebElement RadioAdvancePaymentNo;
	
	//Input New Term - Years
	@FindBy(xpath="//input[@id='main:loanComploanTermYears:loanComploanTermYears']")
	WebElement InputLoanTermYears;
	
	//Input New term - Months
	@FindBy(xpath="//input[@id='main:loanComploanTermMonths:loanComploanTermMonths']")
	WebElement InputLoanTermMonths;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	
	//Constructor
	public TopUpLoanDetails()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
		
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Mortgage Top Up Loan Details");		
		return HeadSectionResult;
	}
	
	//Select Advance Payments
	public String SelAdvancePayment(String AdvancePayment) throws InterruptedException
	{		
		String SelAdvancePaymentOption = funclib.SelOptionValue(RadioAdvancePaymentYes, RadioAdvancePaymentYes.getAttribute("value"),RadioAdvancePaymentNo,RadioAdvancePaymentNo.getAttribute("value"), AdvancePayment);		
		return SelAdvancePaymentOption;		
	}
	
	//Input Loan Term - Years
	public void InputLoanTermY(String LoanTermY) throws InterruptedException 
	{
		InputLoanTermYears.clear();
		funclib.DelayTime();
		InputLoanTermYears.sendKeys(LoanTermY);
		funclib.DelayTime();
	}
	
	//Input Loan Term - Months
	public void InputLoanTermM(String LoanTermM) throws InterruptedException 
	{
		InputLoanTermMonths.clear();
		funclib.DelayTime();
		InputLoanTermMonths.sendKeys(LoanTermM);
		funclib.DelayTime();
	}
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
	
}
