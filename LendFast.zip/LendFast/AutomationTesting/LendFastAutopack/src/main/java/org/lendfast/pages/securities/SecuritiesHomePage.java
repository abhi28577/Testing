package org.lendfast.pages.securities;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SecuritiesHomePage extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
						
	//Defining WebElements
					
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Securities')]")
	WebElement HeadSection;
	
	//Define Valuation Link
	@FindBy(xpath="//a[@id='main:securityList:0:mValuation']")
	WebElement ValuationClick;
	
	//Define Title Search Link
	@FindBy(xpath="//a[@id='main:securityList:0:mTitleSearch']")
	WebElement TitleSearchClick;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public SecuritiesHomePage()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
				
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Securities");		
		return HeadSectionResult;
	}
	
	//Click on Title Search Link
	public void TitleSearch() throws InterruptedException
	{			
		TitleSearchClick.click();
		funclib.DelayTime();
	}
	
	//Click on Valuation Link
	public void Valuation() throws InterruptedException
	{			
		ValuationClick.click();
		funclib.DelayTime();
	}
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
}
