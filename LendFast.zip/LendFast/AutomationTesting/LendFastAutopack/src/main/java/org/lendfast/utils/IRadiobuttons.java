package org.lendfast.utils;

public interface IRadiobuttons {

}
