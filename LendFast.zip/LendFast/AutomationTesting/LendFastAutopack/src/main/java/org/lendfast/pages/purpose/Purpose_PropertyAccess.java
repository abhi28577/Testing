package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_PropertyAccess extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;		
								
	//Defining WebElements
						
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Property Access')]")
	WebElement HeadSection;
	
	//Contact
	@FindBy(xpath="//select[@id='main:assetaccessContactType:assetaccessContactType']")
	WebElement SelectContactType;
	
	//Contact Name
	@FindBy(xpath="//input[@id='main:assetaccessContact:assetaccessContact']")
	WebElement InputContactName;
	
	//Business Phone Number - Area Code
	@FindBy(xpath="//input[@id='main:assetaccessPhoneNumber:number:assetaccessPhoneNumberAreaCode']")
	WebElement InputBusinessPhoneAreaCode;
	
	//Business Phone Number - Phone Number
	@FindBy(xpath="//input[@id='main:assetaccessPhoneNumber:number:assetaccessPhoneNumberPhoneNumber']")
	WebElement InputBusinessPhoneNumber;
	
	//Mobile Number
	@FindBy(xpath="//input[@id='main:assetaccessMobileNumber:number:assetaccessMobileNumberPhoneNumber']")
	WebElement InputMobileNumber;
	
	//Other Access Details
	@FindBy(xpath="//textarea[@id='main:assetaccess:assetaccess']")
	WebElement InputOtherAccessDet;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Purpose_PropertyAccess()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Property Access");		
		return HeadSectionResult;
	}
	
	//Select Contact Type
	public String SelContactType(String ContactType)
	{
		String SelectOption = ContactType;
		String SelContactType = funclib.DropdownListSelect(SelectOption, SelectContactType);
		return SelContactType;		
	}
	
	//Input Contact Name
	public void InputContactName(String ContactName) throws InterruptedException
	{
		InputContactName.clear();
		funclib.DelayTime();
		InputContactName.sendKeys(ContactName);
		funclib.DelayTime();		
	}
	
	//Input Business Phone Number - Area Code
	public void InputBusinessPhoneAreaCode(String AreaCode) throws InterruptedException
	{
		InputBusinessPhoneAreaCode.clear();
		funclib.DelayTime();
		InputBusinessPhoneAreaCode.sendKeys(AreaCode);
		funclib.DelayTime();		
	}
	
	//Input Business Phone Number - Phone Number
	public void InputBusinessPhoneNumber(String PhoneNum) throws InterruptedException
	{
		InputBusinessPhoneNumber.clear();
		funclib.DelayTime();
		InputBusinessPhoneNumber.sendKeys(PhoneNum);
		funclib.DelayTime();		
	}
	
	//Input Mobile Number
	public void InputMobileNumber(String MobileNum) throws InterruptedException
	{
		InputMobileNumber.clear();
		funclib.DelayTime();
		InputMobileNumber.sendKeys(MobileNum);
		funclib.DelayTime();		
	}
	
	//Input Other Access Details
	public void InputOtherAccess(String OtherAccess) throws InterruptedException
	{
		InputOtherAccessDet.clear();
		funclib.DelayTime();
		InputOtherAccessDet.sendKeys(OtherAccess);
		funclib.DelayTime();	
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}