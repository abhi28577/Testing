package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_PropertyPurpose extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;		
				
	//Defining WebElements
				
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Purchase Property Purpose')]")
	WebElement HeadSection;
	
	//Select Purchase Description
	@FindBy(xpath="//select[@id='main:purposepropertyType:purposepropertyType']")
	WebElement SelectPurchaseDesc;
	
	//Select Property Type - New
	@FindBy(xpath="//input[@id='main:assetpropertyAge:assetpropertyAge:0']")
	WebElement SelPropertyNew;
	
	//Select Property Type - Existing
	@FindBy(xpath="//input[@id='main:assetpropertyAge:assetpropertyAge:1']")
	WebElement SelPropertyExist;
	
	//Select Property Type - Off The Plan
	@FindBy(xpath="//input[@id='main:assetpropertyAge:assetpropertyAge:2']")
	WebElement SelPropertyOffPlan;
	
	//Select Property Type - Purchase On Completion
	@FindBy(xpath="//input[@id='main:assetpropertyAge:assetpropertyAge:3']")
	WebElement SelPropertyCompletion;
	
	//Input Purchase Price
	@FindBy(xpath="//input[@id='main:purposepropertyPrice:purposepropertyPrice']")
	WebElement InputPurchasePrice;
	
	//Select Property Usage - Investment
	@FindBy(xpath="//input[@id='main:purposeusage:purposeusage:0']")
	WebElement SelUsageInvestment;
	
	//Select Property Usage - Owner Occupied
	@FindBy(xpath="//input[@id='main:purposeusage:purposeusage:1']")
	WebElement SelUsageOwner;
	
	//Select Principal Place of Residence - Yes
	@FindBy(xpath="//input[@id='main:purposeisPrincipalResForAny:purposeisPrincipalResForAny:0']")
	WebElement SelPrincipalResYes;
	
	//Select Principal Place of Residence - No
	@FindBy(xpath="//input[@id='main:purposeisPrincipalResForAny:purposeisPrincipalResForAny:1']")
	WebElement SelPrincipalResNo;
	
	//Select First Principal Place - Yes
	@FindBy(xpath="//input[@id='main:purposeisFirstPrincipalResForAll:purposeisFirstPrincipalResForAll:0']")
	WebElement SelFirstPrincipalResYes;
		
	//Select First Principal Place - No
	@FindBy(xpath="//input[@id='main:purposeisFirstPrincipalResForAll:purposeisFirstPrincipalResForAll:1']")
	WebElement SelFirstPrincipalResNo;
	
	//Select Mortgage Type - Yes
	@FindBy(xpath="//input[@id='main:assetmortgageType:assetmortgageType:0']")
	WebElement SelMortgageTypeYes;
	
	//Select Mortgage Type - No
	@FindBy(xpath="//input[@id='main:assetmortgageType:assetmortgageType:1']")
	WebElement SelMortgageTypeNo;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Purpose_PropertyPurpose()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
		
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Purchase Property Purpose");		
		return HeadSectionResult;
	}
	
	//Select Purchase Description
	public String SelPurchaseDesc(String PurchaseDescription)
	{
		String SelectOption = PurchaseDescription;
		String SelPurchaseDesc = funclib.DropdownListSelect(SelectOption, SelectPurchaseDesc);
		return SelPurchaseDesc;		
	}
	
	//Select Property Type
	public String SelPropertyType(String PropertyType) throws InterruptedException
	{		
		String OptionValue = PropertyType;
		String OptionResult=null;
		String PropertyType1 = SelPropertyNew.getAttribute("value").toUpperCase();
		String PropertyType2 = SelPropertyExist.getAttribute("value").toUpperCase();
		String PropertyType3 = SelPropertyOffPlan.getAttribute("value").toUpperCase();
		String PropertyType4 = SelPropertyCompletion.getAttribute("value").toUpperCase();
				
		if(OptionValue.toUpperCase() .equals(PropertyType1))
		{
			SelPropertyNew.click();
			OptionResult=SelPropertyNew.getAttribute("value");
		}
		
		if(OptionValue.toUpperCase() .equals(PropertyType2))
		{
			SelPropertyExist.click();
			OptionResult=SelPropertyExist.getAttribute("value");
		}	
		
		if(OptionValue.toUpperCase() .equals(PropertyType3))
		{
			SelPropertyOffPlan.click();
			OptionResult=SelPropertyOffPlan.getAttribute("value");
		}
		
		if(OptionValue.toUpperCase() .equals(PropertyType4))
		{
			SelPropertyCompletion.click();
			OptionResult=SelPropertyCompletion.getAttribute("value");
		}
		
		return OptionResult;
	}
	
	//Input Purchase Price
	public void InputPurchasePrice(String PurchasePrice)
	{
		InputPurchasePrice.sendKeys(PurchasePrice);
	}
	
	//Select Property Usage
	public String SelPropertyUsage(String PropertyUsage) throws InterruptedException
	{		
		String OptionValue = PropertyUsage;		
		String PropertyUsageResult= funclib.SelOptionValue(SelUsageInvestment, SelUsageInvestment.getAttribute("value"),SelUsageOwner,SelUsageOwner.getAttribute("value"),OptionValue);	
		return PropertyUsageResult;		
	}
	
	//Select Principal Residence
	public String SelPrincipalResidence(String PrincipalResidence) throws InterruptedException
	{		
		String OptionValue = PrincipalResidence;		
		String PrincipalResidenceResult= funclib.SelOptionValue(SelPrincipalResYes, SelPrincipalResYes.getAttribute("value"),SelPrincipalResNo,SelPrincipalResNo.getAttribute("value"),OptionValue);	
		return PrincipalResidenceResult;		
	}
	
	//Select First Principal Residence
	public String SelFirstPrincipalResidence(String FirstPrincipalResidence) throws InterruptedException
	{		
		String OptionValue = FirstPrincipalResidence;		
		String FirstPrincipalResidenceResult= funclib.SelOptionValue(SelFirstPrincipalResYes, SelFirstPrincipalResYes.getAttribute("value"),SelFirstPrincipalResNo,SelFirstPrincipalResNo.getAttribute("value"),OptionValue);	
		return FirstPrincipalResidenceResult;		
	}
	
	//Select Mortgage Type
	public String SelMortgageType(String MortgageType) throws InterruptedException
	{		
		String OptionValue = MortgageType;		
		String MortgageTypeResult= funclib.SelOptionValue(SelMortgageTypeYes, SelMortgageTypeYes.getAttribute("value"),SelMortgageTypeNo,SelMortgageTypeNo.getAttribute("value"),OptionValue);	
		return MortgageTypeResult;		
	}
	
	public void NextPage() throws InterruptedException
	{
		//Navigate to Next Page
		funclib.DelayTime();
		NextClick.click();	
	}
}