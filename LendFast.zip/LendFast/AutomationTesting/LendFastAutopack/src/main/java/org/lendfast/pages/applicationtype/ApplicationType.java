package org.lendfast.pages.applicationtype;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class ApplicationType extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
	
	//Define WebElements
	
	//Define Application Type
	@FindBy(xpath="//div[contains(text(),'Application Type')]")
	WebElement HeadSection;
	
	//Define Select Dropdown List for Application Type
	@FindBy(xpath ="//select[@id='main:applicationTypeDropDown:applicationTypeDropDown']")
	WebElement SelectAppType;
	
	//Define Radio Button Options (Yes)
	@FindBy(xpath="//input[@id='main:IsToppingUp:IsToppingUp:0']")
	WebElement RadioTopUpYes;
	
	//Define Radio Button Options (No)
	@FindBy(xpath="//input[@id='main:IsToppingUp:IsToppingUp:1']")
	WebElement RadioTopUpNo;
	
	//Input Existing Loan Account Number
	@FindBy(xpath="//input[@id='main:TopupLoanaccountnumber:TopupLoanaccountnumber']")
	WebElement InputAccountNumber;

	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	
	//Constructor
	public ApplicationType()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}	
	
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Application Type");
		
		return HeadSectionResult;
	}	
	
	//Select Application Type
	public String SelApplicationType(String TAppType)
	{
		String SelectApplication = funclib.DropdownListSelect(TAppType, SelectAppType);
		return SelectApplication;			
	}
	
	//Select Existing Top Up
	public String SelExistTopUp(String TTopUp) throws InterruptedException
	{		
		String SelExistTopUpOption = funclib.SelOptionValue(RadioTopUpYes, RadioTopUpYes.getAttribute("value"),RadioTopUpNo,RadioTopUpNo.getAttribute("value"), TTopUp);		
		return SelExistTopUpOption;		
	}
	
	//Input Existing Loan Account Number
	public void InputAccountNumber(String AccountNumber) throws InterruptedException 
	{
		InputAccountNumber.clear();
		funclib.DelayTime();
		InputAccountNumber.sendKeys(AccountNumber);
		funclib.DelayTime();
	}
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
	
	
}
