package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicantBankrupt extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
				
	//Defining WebElements
				
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Bankruptcy Detail for Applicant')]")
	WebElement HeadSection;
	
	//Applicant Bankrupt or Insolvent - Yes
	@FindBy(xpath="//input[@id='main:partybeenBankrupt:partybeenBankrupt:0']")
	WebElement RadioBankruptYes;
	
	//Applicant Bankrupt or Insolvent - No
	@FindBy(xpath="//input[@id='main:partybeenBankrupt:partybeenBankrupt:1']")
	WebElement RadioBankruptNo;
	
	//Applicant Creditors - Yes
	@FindBy(xpath="//input[@id='main:partybankruptcyScheme:partybankruptcyScheme:0']")
	WebElement RadioCreditorYes;
		
	//Applicant Creditors - No
	@FindBy(xpath="//input[@id='main:partybankruptcyScheme:partybankruptcyScheme:1']")
	WebElement RadioCreditorNo;
	
	//Applicant Legal Proceedings - Yes
	@FindBy(xpath="//input[@id='main:partyhasLegalProceedings:partyhasLegalProceedings:0']")
	WebElement RadioLegalProceedYes;
			
	//Applicant Legal Proceedings - No
	@FindBy(xpath="//input[@id='main:partyhasLegalProceedings:partyhasLegalProceedings:1']")
	WebElement RadioLegalProceedNo;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public ApplicantBankrupt()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Bankruptcy Detail for Applicant");
		
		return HeadSectionResult;
	}
	
	//Select Applicant Bankrupt
	public String SelBankruptType(String Bankrupt) throws InterruptedException
	{		
		String OptionValue = Bankrupt;		
		String OptionResult= funclib.SelOptionValue(RadioBankruptYes, RadioBankruptYes.getAttribute("value"),RadioBankruptNo,RadioBankruptNo.getAttribute("value"),OptionValue);	
		return OptionResult;		
	}
	
	//Select Applicant Creditors
	public String SelCreditorType(String Creditor) throws InterruptedException
	{		
		String OptionValue = Creditor;		
		String OptionResult= funclib.SelOptionValue(RadioCreditorYes, RadioCreditorYes.getAttribute("value"),RadioCreditorNo,RadioCreditorNo.getAttribute("value"),OptionValue);	
		return OptionResult;		
	}
	
	//Select Applicant Legal Proceedings
	public String SelLegalProceedType(String LegalProceed) throws InterruptedException
	{		
		String OptionValue = LegalProceed;		
		String OptionResult= funclib.SelOptionValue(RadioLegalProceedYes, RadioLegalProceedYes.getAttribute("value"),RadioLegalProceedNo,RadioLegalProceedNo.getAttribute("value"),OptionValue);
		return OptionResult;		
	}
	
	public void NextPage() throws InterruptedException
	{
		//Navigate to Next Page
		funclib.DelayTime();
		NextClick.click();	
	}

}
