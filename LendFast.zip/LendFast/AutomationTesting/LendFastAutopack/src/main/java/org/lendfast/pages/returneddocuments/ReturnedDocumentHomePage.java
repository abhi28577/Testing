package org.lendfast.pages.returneddocuments;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReturnedDocumentHomePage extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
						
	//Define WebElements
						
	//Define Application Type
	@FindBy(xpath="//div[contains(text(),'Returned documents')]")
	WebElement HeadSection;
	
	//Received Link
	@FindBy(linkText="Received")
	WebElement ReceivedClick;
	
	//Received Status
	@FindBy(xpath="//td[@id='main:returnedDocList:0:j_id795']")
	WebElement ReceivedStatusResult;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
				
	//Constructor
	public ReturnedDocumentHomePage()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}	
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Returned documents");		
		return HeadSectionResult;
	}
	
	//Received Action	
	public void ReceivedCommentsMethod() throws InterruptedException
	{
		//Click on Received Link		
		WebDriverWait wait = new WebDriverWait(driver, 25);
		Actions action = new Actions(driver);	
		
		//WebDriverWait wait = new WebDriverWait(driver.get(), 25);
		//Actions action = new Actions(driver.get());
		
		WebElement ReceiveClick = wait.until(ExpectedConditions.elementToBeClickable(ReceivedClick));
		java.util.List<WebElement> MaxLink=driver.findElements(By.linkText("Received"));	
		//java.util.List<WebElement> MaxLink=driver.get().findElements(By.linkText("Received"));
		
		for(int ReceivedCounter=1;ReceivedCounter<=MaxLink.size();ReceivedCounter++)
		{
			funclib.DelayTime();
			action.moveToElement(ReceiveClick).doubleClick(ReceiveClick).perform();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
		}
	}
	
	//Navigation to Next Page
	public void NextPage() throws InterruptedException
	{
		funclib.DelayTime();
		NextClick.click();
	}
	
}
