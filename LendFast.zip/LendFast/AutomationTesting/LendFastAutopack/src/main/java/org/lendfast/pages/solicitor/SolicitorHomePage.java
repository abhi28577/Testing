package org.lendfast.pages.solicitor;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SolicitorHomePage extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;
								
	//Defining WebElements
							
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Customer Settlement Agent/Solicitor Details')]")
	WebElement HeadSection;
	
	//Input Date
	@FindBy(xpath="//input[@id='main:FinanceApprovalDate:FinanceApprovalDateInputDate']")
	WebElement InputDate;
	
	//Settlement - Yes
	@FindBy(xpath="//input[@id='main:UsingSolicitor:UsingSolicitor:0']")
	WebElement RadioSolicitorYes;
				
	//Settlement - No
	@FindBy(xpath="//input[@id='main:UsingSolicitor:UsingSolicitor:1']")
	WebElement RadioSolicitorNo;
	
	//Input Solicitor's Name
	@FindBy(xpath="//input[@id='main:Name:Name']")
	WebElement InputSolicitorName;
	
	//LookUp Link
	@FindBy(xpath="//input[@id='main:Name:searchSolicitor']")
	WebElement NameLookUpLink;
	
	//Select LookUp Link
	@FindBy(xpath="//input[@id='SolicitorSearchForm:searchTableResult:0:selectSolicitor']")
	WebElement SelectLookUpLink;
	
	//Loan Approval Letter - Yes
	@FindBy(xpath="//input[@id='main:IsConsentGiven:IsConsentGiven:0']")
	WebElement RadioLoanApprovalYes;
					
	//Loan Approval Letter - No
	@FindBy(xpath="//input[@id='main:IsConsentGiven:IsConsentGiven:1']")
	WebElement RadioLoanApprovalNo;
	
	//Documents Mail Typ - Solicitor
	@FindBy(xpath="//select[@id='main:WhereToSendDocs:WhereToSendDocs']")
	WebElement SelectMailType;
	
	//Documents Mail Typ - Non-Solicitor
	@FindBy(xpath="//select[@id='main:WhereToSendNonSolicitor:WhereToSendNonSolicitor']")
	WebElement SelectNonSolicitorMailType;
	
	//Method Type
	@FindBy(xpath="//select[@id='main:SendDocsByMail:SendDocsByMail']")
	WebElement SelectMethodType;
	
	//Input Reference
	@FindBy(xpath="//textarea[@id='main:Reference:Reference']")
	WebElement InputReference;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public SolicitorHomePage()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Customer Settlement Agent/Solicitor Details");		
		return HeadSectionResult;
	}
			
	//Select Settlement Type
	public String SelSettlement(String Settlement) throws InterruptedException
	{		
		String OptionValue = Settlement;		
		String SettlementResult= funclib.SelOptionValue(RadioSolicitorYes, RadioSolicitorYes.getAttribute("value"),RadioSolicitorNo,RadioSolicitorNo.getAttribute("value"),OptionValue);	
		return SettlementResult;		
	}
	
	//Input Date
	public void InputDate(String ApprovalDate) throws InterruptedException
	{
		InputDate.clear();
		funclib.DelayTime();
		InputDate.sendKeys(ApprovalDate);
		funclib.DelayTime();	
	}
	
	//Input Agent/Solicitor's Name
	public void InputSolicitorName(String SolicitorName) throws InterruptedException
	{
		InputSolicitorName.clear();
		funclib.DelayTime();
		InputSolicitorName.sendKeys(SolicitorName);
		funclib.DelayTime();		
	}
	
	//Name LookUp
	public void NameLookUp() throws InterruptedException
	{		
		funclib.DelayTime();
		NameLookUpLink.click();	
	}
	
	//Name Select LookUp
	public void SelectNameLookUp() throws InterruptedException
	{		
		funclib.DelayTime();
		SelectLookUpLink.click();	
	}
	
	//Select Loan Approval Type
	public String SelLoanApprovalType(String LoanApproval) throws InterruptedException
	{		
		String OptionValue = LoanApproval;		
		String LoanApprovalResult= funclib.SelOptionValue(RadioLoanApprovalYes, RadioLoanApprovalYes.getAttribute("value"),RadioLoanApprovalNo,RadioLoanApprovalNo.getAttribute("value"),OptionValue);	
		return LoanApprovalResult;		
	}
	
	//Select Documents Type for Solicitor
	public String SelDocumentType(String DocumentType)
	{
		String SelectOption = DocumentType;
		String SelDocumentType = funclib.DropdownListSelect(SelectOption, SelectMailType);
		return SelDocumentType;		
	}
	
	//Select Documents Type for Non-Solicitor
	public String SelNonSolicitorDocumentType(String DocumentType)
	{
		String SelectOption = DocumentType;
		String SelDocumentType = funclib.DropdownListSelect(SelectOption, SelectNonSolicitorMailType);
		return SelDocumentType;		
	}
	
	//Select Method Type
	public String SelMethodType(String MethodType)
	{
		String SelectOption = MethodType;
		String SelMethodType = funclib.DropdownListSelect(SelectOption, SelectMethodType);
		return SelMethodType;		
	}
	
	//Input Reference
	public void InputReference(String Reference) throws InterruptedException
	{
		funclib.DelayTime();
		InputReference.clear();
		funclib.DelayTime();
		InputReference.sendKeys(Reference);
		funclib.DelayTime();		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
