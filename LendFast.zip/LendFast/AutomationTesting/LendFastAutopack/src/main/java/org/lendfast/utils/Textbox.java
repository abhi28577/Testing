package org.lendfast.utils;

import java.util.Arrays;
import java.util.List;
import org.openqa.selenium.WebElement;


public class Textbox implements ITextbox
{
	private WebElement element;

	public Textbox(WebElement element) 
	{
		this.element = element;

		if (!isTextBox())
			throw new RuntimeException("not a textbox");
		if (!isEnabled())
			throw new RuntimeException("textbox not enabled!");
	}

	private boolean isTextBox() 
	{
		List<String> tags = Arrays.asList("input", "textarea");
		return tags.contains(this.element.getTagName());
	}

	public String getText() 
	{
		if (!this.element.getAttribute("value").isEmpty())
			return this.element.getAttribute("value");
		return this.element.getText();
	}

	public void clear() 
	{
		this.element.clear();
	}

	public void click() 
	{

		this.element.click();

	}

	public boolean isDisplayed() 
	{
		return this.element.isDisplayed();
	}

	private boolean isEnabled() 
	{
		return this.element.isEnabled();
	}

	public void type(String... keyword) 
	{
		this.element.clear();
		this.element.sendKeys(keyword);

	}

}
