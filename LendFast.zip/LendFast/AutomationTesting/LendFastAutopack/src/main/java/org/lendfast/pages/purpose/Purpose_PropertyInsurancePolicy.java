package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_PropertyInsurancePolicy extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
										
	//Defining WebElements
								
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Property Insurance Policy Detail')]")
	WebElement HeadSection;
	
	//Insurance Policy - Yes
	@FindBy(xpath="//input[@id='main:securityinsPrempolicyNewExisting:securityinsPrempolicyNewExisting:0']")
	WebElement RadioInsurancePolicyYes;
					
	//Insurance Policy - No
	@FindBy(xpath="//input[@id='main:securityinsPrempolicyNewExisting:securityinsPrempolicyNewExisting:1']")
	WebElement RadioInsurancePolicyNo;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public Purpose_PropertyInsurancePolicy()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Property Insurance Policy Detail");		
		return HeadSectionResult;
	}
	
	//Select Property Insurance Policy - New/Existing
	public String SelInsurancePolicy(String InsurancePolicy) throws InterruptedException
	{		
		String OptionValue = InsurancePolicy;		
		String InsurancePolicyResult= funclib.SelOptionValue(RadioInsurancePolicyYes, RadioInsurancePolicyYes.getAttribute("value"),RadioInsurancePolicyNo,RadioInsurancePolicyNo.getAttribute("value"),OptionValue);	
		return InsurancePolicyResult;		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
