package org.lendfast.pages.mortgageinsurance;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MortgageInsuranceHomePage extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
							
	//Defining WebElements
						
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Mortgage Insurance')]")
	WebElement HeadSection;
	
	//Mortgage Insurance Required - Yes
	@FindBy(xpath="//input[@id='main:appisMIRequired:appisMIRequired:0']")
	WebElement RadioMortgageInsuranceYes;
			
	//Mortgage Insurance Required - No
	@FindBy(xpath="//input[@id='main:appisMIRequired:appisMIRequired:1']")
	WebElement RadioMortgageInsuranceNo;
	
	//Select Mortgage Insurer
	@FindBy(xpath="//select[@id='main:insurerNameChoice:insurerNameChoice']")
	WebElement SelectMortgageInsurer;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public MortgageInsuranceHomePage()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();		
	}
					
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Mortgage Insurance");		
		return HeadSectionResult;
	}
		
	//Select Mortage Insurance
	public String SelMortgageInsurance(String MortgageInsurance) throws InterruptedException
	{		
		String OptionValue = MortgageInsurance;		
		String MortgageInsuranceResult= funclib.SelOptionValue(RadioMortgageInsuranceYes, RadioMortgageInsuranceYes.getAttribute("value"),RadioMortgageInsuranceNo,RadioMortgageInsuranceNo.getAttribute("value"),OptionValue);	
		return MortgageInsuranceResult;		
	}
	
	//Select Mortgage Insurer
	public String SelMortgageInsurer(String Insurer)
	{
		String SelectOption = Insurer;
		String SelInsurerType = funclib.DropdownListSelect(SelectOption, SelectMortgageInsurer);
		return SelInsurerType;		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
}
