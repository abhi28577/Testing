package org.lendfast.pages.purpose;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Purpose_ConstructionContract extends ParentPage
{
	// Initialize Functions
	CommonFuncLib funclib;		
					
	//Defining WebElements
					
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Construction Contract Details')]")
	WebElement HeadSection;
	
	//Select Property Usage - Investment
	@FindBy(xpath="//input[@id='main:purposeusage:purposeusage:0']")
	WebElement RadioUsageInvestment;
		
	//Select Property Usage - Owner Occupied
	@FindBy(xpath="//input[@id='main:purposeusage:purposeusage:1']")
	WebElement RadioUsageOwner;
	
	//Construction By - Builder
	@FindBy(xpath="//input[@id='main:purposeisOwnerBuilder:purposeisOwnerBuilder:0']")
	WebElement RadioPropertyBuilder;
		
	//Construction By - Owner
	@FindBy(xpath="//input[@id='main:purposeisOwnerBuilder:purposeisOwnerBuilder:1']")
	WebElement RadioPropertyOwner;
	
	//Construction Contract - Yes
	@FindBy(xpath="//input[@id='main:purposehasTender:purposehasTender:0']")
	WebElement RadioConstructionContractYes;
			
	//Construction Contract - No
	@FindBy(xpath="//input[@id='main:purposehasTender:purposehasTender:1']")
	WebElement RadioConstructionContractNo;
	
	//Executed Signed Contract - Yes
	@FindBy(xpath="//input[@id='main:purposetenderSignedByAll:purposetenderSignedByAll:0']")
	WebElement RadioSignedContractYes;
				
	//Executed Signed Contract - No
	@FindBy(xpath="//input[@id='main:purposetenderSignedByAll:purposetenderSignedByAll:1']")
	WebElement RadioSignedContractNo;
	
	//Fixed Price Contract - Yes
	@FindBy(xpath="//input[@id='main:isFixedPriceContract:isFixedPriceContract:0']")
	WebElement RadioFixedPriceContractYes;
					
	//Fixed Price Contract - No
	@FindBy(xpath="//input[@id='main:isFixedPriceContract:isFixedPriceContract:1']")
	WebElement RadioFixedPriceContractNo;
	
	//NPBS Received Plan Specifications - Yes
	@FindBy(xpath="//input[@id='main:purposehasPlanOrQuote:purposehasPlanOrQuote:0']")
	WebElement RadioNPBSPlanYes;
	
	//NPBS Received Plan Specifications - No
	@FindBy(xpath="//input[@id='main:purposehasPlanOrQuote:purposehasPlanOrQuote:1']")
	WebElement RadioNPBSPlanNo;
	
	//Action on Plans
	@FindBy(xpath="//select[@id='main:purposeaction:purposeaction']")
	WebElement SelectActionPlan;
	
	//Action Details
	@FindBy(xpath="//input[@id='main:purposeactionDetails:purposeactionDetails']")
	WebElement InputActionDetail;
	
	//Council Approved - Yes
	@FindBy(xpath="//input[@id='main:purposearePlansCouncilApproved:purposearePlansCouncilApproved:0']")
	WebElement RadioCouncilApprovedYes;
		
	//Council Approved - No
	@FindBy(xpath="//input[@id='main:purposearePlansCouncilApproved:purposearePlansCouncilApproved:1']")
	WebElement RadioCouncilApprovedNo;
	
	//Estimate Building Commencement
	@FindBy(xpath="//input[@id='main:purposebuildStartDate:purposebuildStartDateInputDate']")
	WebElement InputBuildingCommenceDate;
	
	//Define Next Button
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	
	//Constructor
	public Purpose_ConstructionContract()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
			
	//Capturing Head Section
	public String CaptureHeadSection()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Construction Contract Details");		
		return HeadSectionResult;
	}
	
	//Select Property Usage
	public String SelPropertyUsage(String PropertyUsage) throws InterruptedException
	{		
		String OptionValue = PropertyUsage;		
		String PropertyUsageResult= funclib.SelOptionValue(RadioUsageInvestment, RadioUsageInvestment.getAttribute("value"),RadioUsageOwner,RadioUsageOwner.getAttribute("value"),OptionValue);	
		return PropertyUsageResult;		
	}
	
	//Select Construction as Owner Builder
	public String SelConstructionOwnership(String ConstructionOwnership) throws InterruptedException
	{		
		String OptionValue = ConstructionOwnership;		
		String OwnershipResult= funclib.SelOptionValue(RadioPropertyBuilder, RadioPropertyBuilder.getAttribute("value"),RadioPropertyOwner,RadioPropertyOwner.getAttribute("value"),OptionValue);	
		return OwnershipResult;		
	}
	
	//Select Construction Contract
	public String SelConstructionContract(String ConstructionContract) throws InterruptedException
	{		
		String OptionValue = ConstructionContract;		
		String ConstructionContractResult= funclib.SelOptionValue(RadioConstructionContractYes, RadioConstructionContractYes.getAttribute("value"),RadioConstructionContractNo,RadioConstructionContractNo.getAttribute("value"),OptionValue);
		return ConstructionContractResult;		
	}
	
	//Select Executed Signed Contract
	public String SelExecutedContract(String ExecutedContract) throws InterruptedException
	{		
		String OptionValue = ExecutedContract;		
		String ExecutedContractResult= funclib.SelOptionValue(RadioSignedContractYes, RadioSignedContractYes.getAttribute("value"),RadioSignedContractNo,RadioSignedContractNo.getAttribute("value"),OptionValue);
		return ExecutedContractResult;		
	}
	
	//Select Fixed Price Contract
	public String SelFixedPriceContract(String FixedPriceContract) throws InterruptedException
	{		
		String OptionValue = FixedPriceContract;		
		String FixedPriceContractResult= funclib.SelOptionValue(RadioFixedPriceContractYes, RadioFixedPriceContractYes.getAttribute("value"),RadioFixedPriceContractNo,RadioFixedPriceContractNo.getAttribute("value"),OptionValue);
		return FixedPriceContractResult;		
	}
	
	//Select NPBS Plans Specifications
	public String SelNPBSPlanSpecification(String NPBSPlanSpec) throws InterruptedException
	{		
		String OptionValue = NPBSPlanSpec;		
		String NPBSPlanSpecResult= funclib.SelOptionValue(RadioNPBSPlanYes, RadioNPBSPlanYes.getAttribute("value"),RadioNPBSPlanNo,RadioNPBSPlanNo.getAttribute("value"),OptionValue);
		return NPBSPlanSpecResult;		
	}
	
	//Select Action on Plans
	public String SelActionPlan(String ActionPlan)
	{
		String SelectOption = ActionPlan;
		String SelActionPlanType = funclib.DropdownListSelect(SelectOption, SelectActionPlan);
		return SelActionPlanType;		
	}
	
	//Input Action Details
	public void InputActionDetails(String ActionDetails) throws InterruptedException
	{
		InputActionDetail.clear();
		funclib.DelayTime();
		InputActionDetail.sendKeys(ActionDetails);
		funclib.DelayTime();		
	}
	
	//Select Council Approval Plans
	public String SelCouncilApprovalPlan(String CouncilApproval) throws InterruptedException
	{		
		String OptionValue = CouncilApproval;		
		String CouncilApprovalPlanResult= funclib.SelOptionValue(RadioCouncilApprovedYes, RadioCouncilApprovedYes.getAttribute("value"),RadioCouncilApprovedNo,RadioCouncilApprovedNo.getAttribute("value"),OptionValue);
		return CouncilApprovalPlanResult;		
	}
	
	//Input Estimated Building Commencement Date
	public void InputBuildCommencement(String BuildCommencementDate) throws InterruptedException
	{
		InputBuildingCommenceDate.sendKeys(BuildCommencementDate);
		funclib.DelayTime();		
	}
	
	//Navigate to Next Page
	public void NextPage() throws InterruptedException
	{		
		funclib.DelayTime();
		NextClick.click();	
	}
	
}
