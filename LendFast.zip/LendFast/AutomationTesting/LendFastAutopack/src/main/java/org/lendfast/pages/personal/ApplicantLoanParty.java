package org.lendfast.pages.personal;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ApplicantLoanParty extends ParentPage 
{
	// Initialize Functions
	CommonFuncLib funclib;
									
	//Defining WebElements
									
	//Define Heading Section
	@FindBy(xpath="//div[contains(text(),'Loan Parties')]")
	WebElement HeadSection;
	
	//Define Heading Section for Existing Applications
	@FindBy(xpath="//div[contains(text(),'Existing Applications')]")
	WebElement HeadSectionExisting;
	
	//Add Applicant Button	
	@FindBy(xpath="//input[@id='main:addBtn']")
	WebElement AddApplicant;
	
	//Modify Applicant
	@FindBy(xpath="//a[@id='main:partylist:0:modify']")
	WebElement ModifyApplicant;
	
	//Next Click
	@FindBy(xpath="//input[@id='main:next']")
	WebElement NextClick;
	
	//Constructor
	public ApplicantLoanParty()
	{			
		PageFactory.initElements(driver, this);
		//PageFactory.initElements(driver.get(), this);
		funclib=new CommonFuncLib();
	}
	
	//Capturing Head Section
	public String CaptureHeadSection() throws InterruptedException
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSection.getText(), "Loan Parties");		
		return HeadSectionResult;
	}
	
	//Capturing Head Section
	public String CaptureHeadSectionExisting()
	{
		String HeadSectionResult = funclib.HeadingSection(HeadSectionExisting.getText(), "Existing Applications");				
		return HeadSectionResult;
	}
	
	//Click on Add Applicant
	public void AddApplicantClick() throws InterruptedException
	{
		//Click on Add Applicant Button
		AddApplicant.click();
		Thread.sleep(4000);
	}
	
	//Click on Modify Applicant
	public void ModifyApplicantClick() throws InterruptedException
	{
		//Click on Modify Applicant Button
		ModifyApplicant.click();
		Thread.sleep(4000);
	}
	
	//Click on Next Link
	public void NextClick() throws InterruptedException
	{
		//Click on Next Click against Employment of Applicant
		funclib.DelayTime();
		NextClick.click();			
		funclib.DelayTime();
	}

}
