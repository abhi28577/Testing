package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_PropertyAccess;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S025_Purpose_PropertyAccessTest extends ParentPage 
{
	Purpose_PropertyAccess PropertyAccess;
	CommonFuncLib funclib; 
	String SheetName = "purpose_propertyaccess";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Purpose Contract
		PropertyAccess = new Purpose_PropertyAccess();
		funclib = new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] PropertyAccess()
	{
		//Extracting Contract Details from Excel Sheet
		Object PropertyContract[][] = TestDataUtil.getTestData(SheetName);
		return PropertyContract;
	}
	
	@Test (dataProvider = "PropertyAccess")
	public void Validate_PropertyAccess(String TestCaseId,String Contact, String ContactName, String AreaCode, String PhoneNum, String MobileNum, String OtherAccessDet) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=PropertyAccess.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Property Access");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Contact Type
			funclib.DelayTime();
			String ContactVal = PropertyAccess.SelContactType(Contact);		
			System.out.println("ContactType:" + ContactVal);
			Assert.assertEquals(ContactVal.toUpperCase(), Contact.toUpperCase());
			
			//Input Contact Name
			funclib.DelayTime();
			PropertyAccess.InputContactName(ContactName);
			
			//Input Business Phone Number - Area Code
			funclib.DelayTime();
			PropertyAccess.InputBusinessPhoneAreaCode(AreaCode);
			
			//Input Business Phone Number - Phone Number
			funclib.DelayTime();
			PropertyAccess.InputBusinessPhoneNumber(PhoneNum);
			
			//Input Mobile Number
			funclib.DelayTime();
			PropertyAccess.InputMobileNumber(MobileNum);
			
			//Input Other Access Details
			funclib.DelayTime();
			PropertyAccess.InputOtherAccess(OtherAccessDet);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			PropertyAccess.NextPage();
		
		}
	}	
	
}
