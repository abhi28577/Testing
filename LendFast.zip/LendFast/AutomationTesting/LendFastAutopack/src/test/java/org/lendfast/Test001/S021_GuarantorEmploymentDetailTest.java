package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.GuarantorEmploymentDetail;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S021_GuarantorEmploymentDetailTest extends ParentPage 
{
	GuarantorEmploymentDetail guarantoremploymentdetail;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Guarantor Employment
		guarantoremploymentdetail = new GuarantorEmploymentDetail();
		funclib=new CommonFuncLib();
	}
	
	//Validating Heading Section
	@Test
	public void Validate_HeadingSection()
	{		
		try 
		{
			funclib.DelayTime();
			String SectionText=guarantoremploymentdetail.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Employments for Guarantor");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}				
	}

	//Go to Next Page
	@Test
	public void NextClick() throws InterruptedException
	{
		Thread.sleep(1000);
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		Thread.sleep(1000);
		guarantoremploymentdetail.ModifyClick();		
	}

}
