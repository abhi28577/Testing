package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.solicitor.SettlementDetails;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S111_SettlementDetailsTest extends ParentPage 
{
	SettlementDetails settlementdetails;
	CommonFuncLib funclib;	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Settlement Details
		settlementdetails = new SettlementDetails();
		funclib=new CommonFuncLib();
	}	
	
	@Test
	public void Validate_Settlement4SettlementDetails() throws InterruptedException
	{	
		funclib.DelayTime();
		String SectionText=settlementdetails.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Settlement Details");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
			
		//Navigate to Next Page
		settlementdetails.NextPage();	
	}	
}
