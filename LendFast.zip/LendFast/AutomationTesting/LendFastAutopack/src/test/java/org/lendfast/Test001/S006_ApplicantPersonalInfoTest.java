package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantPersonalInfo;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S006_ApplicantPersonalInfoTest extends ParentPage 
{
	ApplicantPersonalInfo applicantpersonalinfo;
	CommonFuncLib funclib;
	String SheetName = "personal_detail";


	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Application Type
		applicantpersonalinfo = new ApplicantPersonalInfo();
		funclib=new CommonFuncLib();
	}
	
		
	@DataProvider
	public Object[][] ApplicantPersonalInfo()
	{
		//Extracting Trustee from Excel Sheet
		Object Trusteetype[][] = TestDataUtil.getTestData(SheetName);
		return Trusteetype;
	}
	
	
	@Test (dataProvider = "ApplicantPersonalInfo")
	public void Validate_ApplicantPersonalInfo(String TestCaseId, String Party, String Trustee, String Partner, String Dependent, String AgeDependent,String PreCompForm, String Sign) throws InterruptedException
	{
		String TestDataValue = "TC001_01";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=applicantpersonalinfo.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Personal Detail for Applicant");			
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			funclib.DelayTime();
			// Select Acting Trustee
			String TrusteeTypeVal = applicantpersonalinfo.SelTrusteeType(Trustee);		
			System.out.println("Applicant Trustee Type:" + TrusteeTypeVal);
			Assert.assertEquals(TrusteeTypeVal.toUpperCase(), Trustee.toUpperCase());			
			
			funclib.DelayTime();
			// Select Spouse/Partner
			String PartnerVal = applicantpersonalinfo.SelPartner(Partner);		
			System.out.println("Applicant Spouse/Partner:" + PartnerVal);
			Assert.assertEquals(PartnerVal.toUpperCase(), Partner.toUpperCase());
			
			funclib.DelayTime();
			// Select Dependents
			String DependentVal = applicantpersonalinfo.SelDependent(Dependent);		
			System.out.println("Applicant Dependent:" + DependentVal);
			Assert.assertEquals(DependentVal.toUpperCase(), Dependent.toUpperCase());
			
			funclib.DelayTime();
			// Select Pre-Completed Form
			String PreCompleteVal = applicantpersonalinfo.SelPreComplete(PreCompForm);		
			System.out.println("Applicant Pre-Complete Form:" + PreCompleteVal);
			Assert.assertEquals(PreCompleteVal.toUpperCase(), PreCompForm.toUpperCase());		
			
			funclib.DelayTime();
			// Select Signing Method
			String SignMethodVal = applicantpersonalinfo.SelSignMethod(Sign);
			System.out.println("Applicant Signing Method:" + SignMethodVal);
			Assert.assertEquals(SignMethodVal, Sign);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			applicantpersonalinfo.NextPage();
		}	
	}	
	
}
