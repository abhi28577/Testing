package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.GuarantorSignDeclare;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S018_GuarantorSignDeclareTest extends ParentPage
{
	GuarantorSignDeclare guarantorsigndeclare;
	CommonFuncLib funclib;
	String SheetName = "personal_signdeclare";


	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Application Type
		guarantorsigndeclare = new GuarantorSignDeclare();
		funclib=new CommonFuncLib();
	}
	
	
	@DataProvider
	public Object[][] SignDeclarationType()
	{
		//Extracting Values from Excel Sheet
		Object SignDeclaretype[][] = TestDataUtil.getTestData(SheetName);
		return SignDeclaretype;
	}

	@Test (dataProvider = "SignDeclarationType")
	public void Validate_GuarantorSignedDeclaration(String TestCaseId,String Party,String PartySigned, String Consent, String IdentityType, String StateType, String IdentificationNumber) throws InterruptedException
	{
		String TestDataValue = "TC001_02";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=guarantorsigndeclare.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Signed Guarantor Consent for Guarantor");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			funclib.DelayTime();
			// Select Guarantor Declaration
			String PartySignedVal = guarantorsigndeclare.SelDeclarationType(PartySigned);		
			System.out.println("Declaration Type:" + PartySignedVal);
			Assert.assertEquals(PartySignedVal.toUpperCase(), PartySigned.toUpperCase());
			
			funclib.DelayTime();
			// Select Guarantor Consent Signed Declaration
			String GuarantorSignedVal = guarantorsigndeclare.SelConsentForm(Consent);
			System.out.println("Consent Type:" + GuarantorSignedVal);
			Assert.assertEquals(GuarantorSignedVal.toUpperCase(), Consent.toUpperCase());
			
			funclib.DelayTime();
			// Select Identification Type	
			String IdentityTypeVal = guarantorsigndeclare.SelIdentityType(IdentityType);
			System.out.println("Identification Type:" + IdentityTypeVal);
			Assert.assertEquals(IdentityTypeVal, IdentityType);
			
			funclib.DelayTime();
			// Select State of Issue
			String StateTypeVal = guarantorsigndeclare.SelStateType(StateType);
			System.out.println("State Type:" + StateTypeVal);
			Assert.assertEquals(StateTypeVal, StateType);
			
			funclib.DelayTime();
			// Input Identification Number
			guarantorsigndeclare.InputIdentificationNumber(IdentificationNumber);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			guarantorsigndeclare.NextPage();
		}
	}

}
