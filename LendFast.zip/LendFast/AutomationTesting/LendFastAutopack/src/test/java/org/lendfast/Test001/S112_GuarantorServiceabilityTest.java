package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.serviceability.GuarantorServiceability;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S112_GuarantorServiceabilityTest extends ParentPage
{
	GuarantorServiceability guarantorserviceability;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Guarantor Serviceability
		guarantorserviceability = new GuarantorServiceability();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_Settlement4GuarantorServiceability() throws InterruptedException
	{
		funclib.DelayTime();
		String SectionText=guarantorserviceability.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Guarantor Serviceability");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Navigate to Next Page
		guarantorserviceability.NextPage();
	}
	
}
