package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.checklist.ChecklistHomePage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S043_CheckListHomePageTest extends ParentPage 
{
	ChecklistHomePage Chklist;
	CommonFuncLib funclib; 
	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  CheckList
		Chklist = new ChecklistHomePage();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_CheckListDocuments() throws InterruptedException
	{	
		//Validating Heading Section
		try 
		{
			funclib.DelayTime();
			String SectionText=Chklist.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Check List");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Select Non-Mandatory List
		Chklist.NonMandatory();
		
		
		//Submission Position
		Chklist.SubmissionPos();
		
		
		//Add Document(s)
		//Chklist.AddDocument();
		
		
	}
}
