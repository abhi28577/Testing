package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.assets.AssetsApplicant;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S033_AssetsApplicantTest extends ParentPage 
{
	AssetsApplicant AssetApp;
	CommonFuncLib funclib; 
	String SheetName = "assets";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		AssetApp = new AssetsApplicant();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] AssetApplicant()
	{
		//Extracting Contract Details from Excel Sheet
		Object Asset[][] = TestDataUtil.getTestData(SheetName);
		return Asset;
	}
	
	@Test (dataProvider = "AssetApplicant")
	public void Validate_AssetApplicant(String TestCaseId,String AssetType, String ManualAddress, String AusAddress, String PropertyName, String HouseNum, String UnitNumber, String Level, String StreetName, String StreetType, String StreetSuffix,String Suburb, String State, String PostalCode, String SecurityId,String Security, String AssetValue,  String Insurer, String Investment, String AmountOwe) throws InterruptedException
	{
		String TestDataValue = "TC001";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=AssetApp.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Assets");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Asset Type
			Thread.sleep(1000);
			String AssetTypeVal = AssetApp.SelAssetType(AssetType);		
			System.out.println("Asset Type:" + AssetTypeVal);
			Assert.assertEquals(AssetTypeVal.toUpperCase(), AssetType.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Add Asset Page
			AssetApp.AddAssetBut();
		}
	}	

}
