package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.checklist.ChecklistSettlement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S114_CheckListSettlementTest extends ParentPage 
{
	ChecklistSettlement Chklist;
	CommonFuncLib funclib; 
	
	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  CheckList
		Chklist = new ChecklistSettlement();
		funclib=new CommonFuncLib();
	}
	
	
	
	@Test
	public void Validate_FifthSettlementDocuments() throws InterruptedException
	{				
		//Select Non-Mandatory List
		Chklist.NonMandatory();
		
		//Submission - Image/Complete
		Chklist.SubmissionPos();
		
		//Navigate to Next Page (Additional Conditions Page)
		Chklist.NextPage();
		
		//Navigate to Next Page (Action Page)
		Chklist.NextPage();
		
	}
}
