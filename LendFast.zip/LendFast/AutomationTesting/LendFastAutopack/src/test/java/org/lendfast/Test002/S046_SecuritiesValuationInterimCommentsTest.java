package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.securities.SecuritiesValuationInterimComments;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S046_SecuritiesValuationInterimCommentsTest extends ParentPage 
{	
	SecuritiesValuationInterimComments SecurityValInterimComments;
	CommonFuncLib funclib; 
	String SheetName = "valuation";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		SecurityValInterimComments = new SecuritiesValuationInterimComments();		
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] SecuritiesValuationInterim()
	{
		//Extracting Contract Details from Excel Sheet
		Object Asset[][] = TestDataUtil.getTestData(SheetName);
		return Asset;
	}
	
	@Test (dataProvider = "SecuritiesValuationInterim")
	public void Validate_CreditSecuritiesValInterimComments(String TestCaseId,String ValuationType, String PreferredContact, String MobileNum, String InterimComments, String OrderNumber, String ValuerFirstName, String ValuerLastName, String ValuerFirm, String Zone, String LandValue, String ExistingImprovement, String InsuranceReplacement,String LocalEconomy, String MarketSegment, String MarketVolatility, String MarketDirection, String Environmental, String Improvement, String Land, String Neighbourhood, String UnfurnishedRental, String SiteArea, String LivingArea, String Declaration) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=SecurityValInterimComments.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Valuation Interim Comments");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Request
			funclib.DelayTime();
			SecurityValInterimComments.SelectInterimType(InterimComments);
			
			//Navigate to Next Page
			funclib.DelayTime();
			SecurityValInterimComments.NextPage();
			
			//Click on Status
			funclib.DelayTime();
			SecurityValInterimComments.AssessLinkClick();
		}
	}
}
