package org.lendfast.Test003;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.securities.SecuritiesHomePage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S086_SecuritiesHomePageTest extends ParentPage 
{
	SecuritiesHomePage SecurityHome;
	CommonFuncLib funclib; 
	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Securities Home 
		SecurityHome = new SecuritiesHomePage();
		funclib=new CommonFuncLib();
	}	
	
	
	@Test
	public void Validate_Settlement4SecuritiesHome() throws InterruptedException
	{
		
		//Validating Heading Section
		try 
		{
			funclib.DelayTime();
			String SectionText=SecurityHome.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Securities");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
			
		//Navigate to Next Page
		funclib.DelayTime();
		SecurityHome.NextPage();			
	}
}
