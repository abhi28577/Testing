package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.securities.SecuritiesValuationDetails;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S047_SecuritiesValuationDetailsTest extends ParentPage 
{	
	SecuritiesValuationDetails SecurityValDetails;
	CommonFuncLib funclib; 
	String SheetName = "valuation";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		SecurityValDetails = new SecuritiesValuationDetails();		
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] SecuritiesValuationDetails()
	{
		//Extracting Contract Details from Excel Sheet
		Object Asset[][] = TestDataUtil.getTestData(SheetName);
		return Asset;
	}
	
	@Test (dataProvider = "SecuritiesValuationDetails")
	public void Validate_CreditSecuritiesValDetails(String TestCaseId,String ValuationType, String PreferredContact, String MobileNum, String InterimComments, String OrderNumber, String ValuerFirstName, String ValuerLastName, String ValuerFirm, String Zone, String LandValue, String ExistingImprovement, String InsuranceReplacement,String LocalEconomy, String MarketSegment, String MarketVolatility, String MarketDirection, String Environmental, String Improvement, String Land, String Neighbourhood, String UnfurnishedRental, String SiteArea, String LivingArea, String Declaration) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=SecurityValDetails.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Valuation details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Input Order Number
			funclib.DelayTime();
			SecurityValDetails.InputOrderNumberText(OrderNumber);
			
			//Input Valuation Date
			funclib.DelayTime();
			SecurityValDetails.InputValuationDateText();
			
			//Input Valuer First Name
			funclib.DelayTime();
			SecurityValDetails.InputValuerFirstNameText(ValuerFirstName);
			
			//Input Valuer Last Name
			funclib.DelayTime();
			SecurityValDetails.InputValuerLastNameText(ValuerLastName);
			
			//Input Valuer Firm
			funclib.DelayTime();
			SecurityValDetails.InputValuerFirmText(ValuerFirm);
			
			//Input Zone
			funclib.DelayTime();
			SecurityValDetails.InputZoneText(Zone);
			
			//Input Land Value
			funclib.DelayTime();
			SecurityValDetails.InputLandValueText(LandValue);
			
			//Input Existing Improvements
			funclib.DelayTime();
			SecurityValDetails.InputExistingImprovementText(ExistingImprovement);
			
			//Input Insurance Replacement Value
			funclib.DelayTime();
			SecurityValDetails.InputInsuranceReplacementText(InsuranceReplacement);
			
			//Input Valuation Validity
			funclib.DelayTime();
			SecurityValDetails.InputvaluationValidFromText();
			
			//Input Date of Inspection
			funclib.DelayTime();
			SecurityValDetails.InputDateOfInspectionText();
			
			//Select Local Economy
			funclib.DelayTime();
			SecurityValDetails.SelectLocalEconomyType(LocalEconomy);
			
			//Select Market Segment
			funclib.DelayTime();
			SecurityValDetails.SelectMarketSegmentType(MarketSegment);
			
			//Select Market Volatility
			funclib.DelayTime();
			SecurityValDetails.SelectMarketVolatilityType(MarketVolatility);
			
			//Select Market Direction
			funclib.DelayTime();
			SecurityValDetails.SelectMarketDirectionType(MarketDirection);
			
			//Select Environmental
			funclib.DelayTime();
			SecurityValDetails.SelectEnvironmentalType(Environmental);
			
			//Select Improvements
			funclib.DelayTime();
			SecurityValDetails.SelectImprovementsType(Improvement);
			
			//Select Land
			funclib.DelayTime();
			SecurityValDetails.SelectLandType(Land);
			
			//Select Neighbourhood
			funclib.DelayTime();
			SecurityValDetails.SelectNeighbourhoodType(Neighbourhood);
			
			//Input UnFurnished Rental
			funclib.DelayTime();
			SecurityValDetails.InputUnfurnishedRentalText(UnfurnishedRental);
			
			//Input Site Area
			funclib.DelayTime();
			SecurityValDetails.InputSiteAreaText(SiteArea);
			
			//Input Living Area
			funclib.DelayTime();
			SecurityValDetails.InputLivingAreaText(LivingArea);
			
			//Select Declaration
			funclib.DelayTime();
			SecurityValDetails.SelDeclarationType(Declaration);
						
			//Navigate to Next Page (Valuation Reports)
			funclib.DelayTime();
			SecurityValDetails.NextPage();					
			
			//Navigate to Next Page (Securities)
			funclib.DelayTime();
			SecurityValDetails.NextPage();
		}
	}
}
