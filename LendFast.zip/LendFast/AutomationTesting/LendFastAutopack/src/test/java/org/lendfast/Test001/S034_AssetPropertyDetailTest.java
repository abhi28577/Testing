package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.assets.AssetPropertyDetail;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S034_AssetPropertyDetailTest extends ParentPage
{
	AssetPropertyDetail AssetProperty;
	CommonFuncLib funclib; 
	String SheetName = "assets";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose
		AssetProperty = new AssetPropertyDetail();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] AssetProperty()
	{
		//Extracting Contract Details from Excel Sheet
		Object Asset[][] = TestDataUtil.getTestData(SheetName);
		return Asset;
	}
	
	@Test (dataProvider = "AssetProperty")
	public void Validate_AssetProperty(String TestCaseId,String AssetType, String ManualAddress, String AusAddress, String PropertyName, String HouseNum, String HouseUnit, String HouseLevel, String HouseStreetName, String HouseStreetType, String HouseStreetSuffix,String HouseSuburb, String HouseState, String HousePostalCode, String SecurityId, String Security, String AssetValue,  String Insurer, String Investment, String AmountOwe) throws InterruptedException
	{
		String TestDataValue = "TC001";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=AssetProperty.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Enter Property asset details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Manual Property Address
			funclib.DelayTime();
			AssetProperty.InputManualAddress(ManualAddress);	
					
			//Manual Address Details
			funclib.DelayTime();
			AssetProperty.InputManualAddressDetails(AusAddress,PropertyName, HouseNum, HouseUnit, HouseLevel,  HouseStreetName, HouseStreetType, HouseStreetSuffix, HouseSuburb, HouseState, HousePostalCode);
			
			//Select Property Security Type
			funclib.DelayTime();
			String PropertySecurityVal = AssetProperty.SelPropertySecurityType(Security);		
			System.out.println("Property Security:" + PropertySecurityVal);
			Assert.assertEquals(PropertySecurityVal.toUpperCase(), Security.toUpperCase());
			
			//Input Estimated Value
			funclib.DelayTime();
			AssetProperty.InputEstimatedValue(AssetValue);
			
			//Input Insurance Company
			funclib.DelayTime();
			AssetProperty.InputInsuranceValue(Insurer);
			
			//Select Investment Property Type
			funclib.DelayTime();
			String InvestmentPropertyVal = AssetProperty.SelInvestmentPropertyType(Investment);		
			System.out.println("Investment Property:" + PropertySecurityVal);
			Assert.assertEquals(InvestmentPropertyVal.toUpperCase(), Investment.toUpperCase());
			
			//Select Amount Owe Type
			funclib.DelayTime();
			String AmountOweVal = AssetProperty.SelAmountOweType(AmountOwe);		
			System.out.println("Amount Owe:" + AmountOweVal);
			Assert.assertEquals(AmountOweVal.toUpperCase(), AmountOwe.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
					
			//Navigate to Next Page
			AssetProperty.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			AssetProperty.NextPage();
		}
	}	
}
