package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.securities.SecuritiesRecordValuation;
import org.lendfast.pages.securities.SecuritiesValuationReport;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S044_SecuritiesValuationTest extends ParentPage 
{
	SecuritiesValuationReport SecurityAssessment;
	SecuritiesRecordValuation SecurityDeclare;
	CommonFuncLib funclib; 
	String SheetName = "valuation";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		SecurityAssessment = new SecuritiesValuationReport();
		SecurityDeclare = new SecuritiesRecordValuation();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] SecuritiesValuation()
	{
		//Extracting Contract Details from Excel Sheet
		Object Asset[][] = TestDataUtil.getTestData(SheetName);
		return Asset;
	}
	
	@Test (dataProvider = "SecuritiesValuation")
	public void Validate_CreditSecuritiesValuation(String TestCaseId,String ValuationType, String PreferredContact, String MobileNum, String InterimComments, String OrderNumber, String ValuerFirstName, String ValuerLastName, String ValuerFirm, String Zone, String LandValue, String ExistingImprovement, String InsuranceReplacement,String LocalEconomy, String MarketSegment, String MarketVolatility, String MarketDirection, String Environmental, String Improvement, String Land, String Neighbourhood, String UnfurnishedRental, String SiteArea, String LivingArea, String Declaration) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=SecurityAssessment.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Valuation Reports");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Valuation Type
			funclib.DelayTime();
			String ValuationCodeVal = SecurityAssessment.SelectValuationType(ValuationType);		
			System.out.println("Valuation Type:" + ValuationCodeVal);
			Assert.assertEquals(ValuationCodeVal.toUpperCase(), ValuationType.toUpperCase());
			
			//Click on Add valuation
			funclib.DelayTime();
			SecurityAssessment.AddValuation();
		}
	}
}
