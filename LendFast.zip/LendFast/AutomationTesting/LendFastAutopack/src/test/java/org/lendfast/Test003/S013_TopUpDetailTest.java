package org.lendfast.Test003;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.topup.TopUpLoanDetails;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S013_TopUpDetailTest extends ParentPage
{
	TopUpLoanDetails TopUp;
	CommonFuncLib funclib;	
	String SheetName = "topup";
	
	@BeforeMethod
	public void SetUp()
	{
		//Initializing Top Up Loan Constructor
		TopUp = new TopUpLoanDetails();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] TopUp()
	{
		//Extracting Origination Area from Excel Sheet
		Object TopUp[][] = TestDataUtil.getTestData(SheetName);
		return TopUp;
	}

	@Test (dataProvider = "TopUp")
	public void Validate_TopUpLoan(String TestCaseId, String PartyType, String AdvancePayment, String AdvanceWriteOff, String LoanTermY, String LoanTermM) throws InterruptedException
	{
		//String RunValue = "Execute";
		String TestDataValue = "TC003";
		
		
		if(TestDataValue .equals(TestCaseId))
		{			
		
			//Validating Heading Section		
			try 
			{
				funclib.DelayTime();
				String SectionText=TopUp.CaptureHeadSection();
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Mortgage Top Up Loan Details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			// Selecting Advance Payment
			funclib.DelayTime();
			String AdvancePaymentVal = TopUp.SelAdvancePayment(AdvancePayment);		
			System.out.println("Advance Payment Needed:" + AdvancePaymentVal);
			Assert.assertEquals(AdvancePaymentVal.toUpperCase(), AdvancePayment.toUpperCase());
			
			//Input New Loan term - Years
			funclib.DelayTime();
			TopUp.InputLoanTermY(LoanTermY);
			
			//Input New Loan Term - Months
			funclib.DelayTime();
			TopUp.InputLoanTermM(LoanTermM);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			TopUp.NextPage();
		}
	}
}
