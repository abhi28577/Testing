package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_ConstructionContract;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S019_Purpose_ConstructionContractTest extends ParentPage
{
	Purpose_ConstructionContract ConstructContract;
	CommonFuncLib funclib; 
	String SheetName = "purpose_constructioncontract";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Construction Contract
		ConstructContract = new Purpose_ConstructionContract();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] ConstructionContract()
	{
		//Extracting Construction Contract Details from Excel Sheet
		Object ConstructionContract[][] = TestDataUtil.getTestData(SheetName);
		return ConstructionContract;
	}
	
	@Test (dataProvider = "ConstructionContract")
	public void Validate_ConnstructionContract(String TestCaseId,String PropertyUsage, String ConstructionOwnership, String ConstructionContract, String ExecutedContract, String FixedPriceContract, String NPBSPlanSpec, String ActionPlan, String ActionDetails, String CouncilApproval, String BuildCommencementDate) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=ConstructContract.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Construction Contract Details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Property Usage
			funclib.DelayTime();
			String PropertyUsageVal = ConstructContract.SelPropertyUsage(PropertyUsage);		
			System.out.println("Property Usage:" + PropertyUsageVal);
			Assert.assertEquals(PropertyUsageVal.toUpperCase(), PropertyUsage.toUpperCase());
			
			//Select Construction as Owner Builder
			funclib.DelayTime();
			String ConstructOwnershipVal = ConstructContract.SelConstructionOwnership(ConstructionOwnership);		
			System.out.println("Construction Ownership:" + ConstructOwnershipVal);
			Assert.assertEquals(ConstructOwnershipVal.toUpperCase(), ConstructionOwnership.toUpperCase());
			
			//Select Construction Contract
			funclib.DelayTime();
			String ConstructContractVal = ConstructContract.SelConstructionContract(ConstructionContract);		
			System.out.println("Construction Contract:" + ConstructContractVal);
			Assert.assertEquals(ConstructContractVal.toUpperCase(), ConstructionContract.toUpperCase());
			
			//Select Executed Signed Contract
			funclib.DelayTime();
			String ExecuteContractVal = ConstructContract.SelExecutedContract(ExecutedContract);		
			System.out.println("Executed Signed Contract:" + ExecuteContractVal);
			Assert.assertEquals(ExecuteContractVal.toUpperCase(), ExecutedContract.toUpperCase());
			
			//Select Fixed Price Contract
			funclib.DelayTime();
			String FixedPriceContractVal = ConstructContract.SelFixedPriceContract(FixedPriceContract);		
			System.out.println("Fixed Price Contract:" + FixedPriceContractVal);
			Assert.assertEquals(FixedPriceContractVal.toUpperCase(), FixedPriceContract.toUpperCase());
			
			//Select NPBS Plans Specifications
			funclib.DelayTime();
			String NPBSPlanVal = ConstructContract.SelNPBSPlanSpecification(NPBSPlanSpec);		
			System.out.println("NPBS Plan Specification:" + NPBSPlanVal);
			Assert.assertEquals(NPBSPlanVal.toUpperCase(), NPBSPlanSpec.toUpperCase());
			
			//Select Action on Plans
			funclib.DelayTime();
			String ActionPlanVal = ConstructContract.SelActionPlan(ActionPlan);		
			System.out.println("Action Plan:" + ActionPlanVal);
			Assert.assertEquals(ActionPlanVal.toUpperCase(), ActionPlan.toUpperCase());
			
			//Input Action Details
			funclib.DelayTime();
			ConstructContract.InputActionDetails(ActionDetails);
			
			//Select Council Approval Plans
			funclib.DelayTime();
			String CouncilApprovalVal = ConstructContract.SelCouncilApprovalPlan(CouncilApproval);		
			System.out.println("Council Approval Plan:" + CouncilApprovalVal);
			Assert.assertEquals(CouncilApprovalVal.toUpperCase(), CouncilApproval.toUpperCase());
			
			//Input Estimated Building Commencement Date
			funclib.DelayTime();
			ConstructContract.InputBuildCommencement(BuildCommencementDate);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			ConstructContract.NextPage();
		}
	}
}
