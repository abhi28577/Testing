package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantCustomer;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S016_GuarantorCustomerTest extends ParentPage 
{
	ApplicantCustomer guarantorcustomer;
	CommonFuncLib funclib;
	String SheetName = "personal_info";
	

	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Application Type
		guarantorcustomer = new ApplicantCustomer();
		funclib=new CommonFuncLib();
	}

	@DataProvider
	public Object[][] GuarantorCustomer()
	{
		//Extracting Values from Excel Sheet
		Object Guarantortype[][] = TestDataUtil.getTestData(SheetName);
		return Guarantortype;		
	}

	
	@Test (dataProvider = "GuarantorCustomer")
	public void Validate_GuarantorCustomer(String TestCaseId,String PartyType, String ApplicantType, String PrimaryApplicant,String ExistNPBS, String AccountNumber, String Lastname, String FirstName, String DOB) throws InterruptedException
	{
		String TestDataValue = "TC001_02";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=guarantorcustomer.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Existing Customer");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			funclib.DelayTime();
			// Selecting Party Type
			String PartyTypeVal = guarantorcustomer.SelPartyType(PartyType);
			System.out.println("Guarantor Party Type:" + PartyTypeVal);
			Assert.assertEquals(PartyTypeVal.toUpperCase(),PartyType.toUpperCase());
			
			funclib.DelayTime();
			// Selecting ApplicantType
			String ApplicantTypeVal = guarantorcustomer.SelApplicantType(ApplicantType);
			System.out.println("Guarantor Type:" + ApplicantTypeVal);
			Assert.assertEquals(ApplicantTypeVal.toUpperCase(), ApplicantType.toUpperCase());
			
			funclib.DelayTime();
			// Select if NPBS Customer
			String NPBSCustomerVal = guarantorcustomer.SelNPBSCustomerType(ExistNPBS);
			System.out.println("Guarantor NPBS Customer:" + NPBSCustomerVal);
			Assert.assertEquals(NPBSCustomerVal.toUpperCase(), ExistNPBS.toUpperCase());
			
			funclib.DelayTime();
			// Input Account/Customer Number
			guarantorcustomer.InputAccountNumber(AccountNumber);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			funclib.DelayTime();
			// Select & Click on Account/Customer Number
			guarantorcustomer.SelectCustomerNumber();
		}
	}

}
