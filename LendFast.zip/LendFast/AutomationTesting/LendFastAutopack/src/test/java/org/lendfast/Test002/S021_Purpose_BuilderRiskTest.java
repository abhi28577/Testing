package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_BuilderRisk;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S021_Purpose_BuilderRiskTest extends ParentPage
{
	Purpose_BuilderRisk BuilderRisk;
	CommonFuncLib funclib; 
	String SheetName = "purpose_builderrisk";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Construction Contract
		BuilderRisk = new Purpose_BuilderRisk();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] BuilderRisk()
	{
		//Extracting Builder Risk Details from Excel Sheet
		Object BuilderRisk[][] = TestDataUtil.getTestData(SheetName);
		return BuilderRisk;
	}
	
	@Test (dataProvider = "BuilderRisk")
	public void Validate_BuilderRisk(String TestCaseId,String BuilderInsurance, String InsuranceCode, String InsuranceType, String PolicyNumber, String ExpiryDate, String Comments) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=BuilderRisk.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Builder All Risk Details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Copy of Builder's Risk Insurance
			funclib.DelayTime();
			String InsuranceCopyVal = BuilderRisk.SelBuilderInsurance(BuilderInsurance);		
			System.out.println("Copy of Builder's Insurance Copy:" + InsuranceCopyVal);
			Assert.assertEquals(InsuranceCopyVal.toUpperCase(), BuilderInsurance.toUpperCase());
			
			//Select Insurance Company Code
			funclib.DelayTime();
			String InsuranceCodeVal = BuilderRisk.SelInsuranceCode(InsuranceCode);		
			System.out.println("Insurance Code:" + InsuranceCodeVal);
			Assert.assertEquals(InsuranceCodeVal.toUpperCase(), InsuranceCode.toUpperCase());
			
			//Select Insurance Type
			funclib.DelayTime();
			String InsuranceTypeVal = BuilderRisk.SelInsuranceType(InsuranceType);		
			System.out.println("Insurance Type:" + InsuranceTypeVal);
			Assert.assertEquals(InsuranceTypeVal.toUpperCase(), InsuranceType.toUpperCase());
			
			//Input Insurance Policy Number
			funclib.DelayTime();
			BuilderRisk.InputPolicyNumber(PolicyNumber);
			
			//Input Expiry Date
			funclib.DelayTime();
			BuilderRisk.InputExpiryDate(ExpiryDate);
			
			//Input Comments
			funclib.DelayTime();
			BuilderRisk.InputComments(Comments);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			BuilderRisk.NextPage();			
		}
	}
}
