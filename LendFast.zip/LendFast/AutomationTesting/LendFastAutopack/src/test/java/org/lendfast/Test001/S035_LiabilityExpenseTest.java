package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.liabilities.LiabilityExpense;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S035_LiabilityExpenseTest extends ParentPage
{
	LiabilityExpense LiabExpense;
	//LiabilityExpenseDetail LiabExpenseDet;
	CommonFuncLib funclib; 
	String SheetName = "liabilitiesparty";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		LiabExpense = new LiabilityExpense();		
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] LiabilityApplicant()
	{
		//Extracting Contract Details from Excel Sheet
		Object Liability[][] = TestDataUtil.getTestData(SheetName);
		return Liability;
	}
	
	@Test (dataProvider = "LiabilityApplicant")
	public void Validate_LiabilityApplicant(String TestCaseId,String LiabList, String AdvancePay, String LiabRepaid, String LiabCleared, String LiabChanged, String LiabLimit) throws InterruptedException
	{
		String TestDataValue = "TC001";
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		
		if(TestDataValue .equals(TestCaseId))
		{
			String ApplicantModifyVal = "Modify";
			if(LiabList .equals(ApplicantModifyVal))
			{				
				//Click on Modify Link
				LiabExpense.ClickModify();
				
				//Validating Heading Section
				try 
				{
					funclib.DelayTime();
					String SectionText=LiabExpense.CaptureHeadSection();		
					System.out.println("Heading Section:" + SectionText);
					Assert.assertEquals(SectionText, "Existing NPBS Liability Details");
				} 
				catch (InterruptedException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//Validate Applicant Information on Liability Repaid/Cleared/Limit
				LiabExpense.ModifyApplicant(LiabList, LiabRepaid, LiabCleared, LiabChanged, LiabLimit);						
			}
		}
	}		
	
}
