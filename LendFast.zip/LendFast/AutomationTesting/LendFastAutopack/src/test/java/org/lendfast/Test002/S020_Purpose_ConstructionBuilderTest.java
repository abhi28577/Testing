package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_ConstructionBuilder;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S020_Purpose_ConstructionBuilderTest extends ParentPage 
{
	Purpose_ConstructionBuilder ConstructBuilder;
	CommonFuncLib funclib; 
	String SheetName = "purpose_builderdetails";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Construction Builder
		ConstructBuilder = new Purpose_ConstructionBuilder();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] ConstructionBuilder()
	{
		//Extracting Construction Contract Details from Excel Sheet
		Object ConstructionBuilder[][] = TestDataUtil.getTestData(SheetName);
		return ConstructionBuilder;
	}
	
	@Test (dataProvider = "ConstructionBuilder")
	public void Validate_ConstructionBuilder(String TestCaseId,String BuilderName, String BuilderAddress, String AusAddress, String PropertyName, String HouseNum, String HouseUnit, String HouseLevel, String HouseStreetName, String HouseStreetType, String HouseStreetSuffix,String HouseSuburb, String HouseState, String HousePostalCode, String BuilderABN, String BuilderLicence, String State, String BuilderAreaCode, String BuilderAreaPhoneNumber, String BuilderFaxAreaCode, String BuilderFaxNumber, String BuilderEmail) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=ConstructBuilder.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);				
				Assert.assertEquals(SectionText, "Construction Builder Details");
				
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Input Builder's Name
			funclib.DelayTime();
			ConstructBuilder.InputName(BuilderName);			
			
			//Input Builder's Address Manually
			funclib.DelayTime();
			ConstructBuilder.InputAddress(BuilderAddress);
			
			//Manual Address Details
			funclib.DelayTime();
			ConstructBuilder.InputManualAddressDetails(AusAddress,PropertyName, HouseNum, HouseUnit, HouseLevel,  HouseStreetName, HouseStreetType, HouseStreetSuffix, HouseSuburb, HouseState, HousePostalCode);
			
			//Input Builder's ABN
			funclib.DelayTime();
			ConstructBuilder.InputABN(BuilderABN);
			
			//Input Builder's Licence Number
			funclib.DelayTime();
			ConstructBuilder.InputLicenceNumber(BuilderLicence);
			
			//Select State Of Issue
			funclib.DelayTime();
			String StateVal = ConstructBuilder.SelState(State);		
			System.out.println("State:" + StateVal);
			Assert.assertEquals(StateVal.toUpperCase(), State.toUpperCase());
			
			//Input Builder's Area Code
			funclib.DelayTime();
			ConstructBuilder.InputAreaCode(BuilderAreaCode);
			
			//Input Builder's Area Phone Number
			funclib.DelayTime();
			ConstructBuilder.InputAreaPhoneNumber(BuilderAreaPhoneNumber);
			
			//Input Builder's Fax Code
			funclib.DelayTime();
			ConstructBuilder.InputFaxAreaCode(BuilderFaxAreaCode);			
			
			//Input Builder's Fax Number
			funclib.DelayTime();
			ConstructBuilder.InputFaxNumber(BuilderFaxNumber);
			
			//Input Builder's Email Address
			funclib.DelayTime();
			ConstructBuilder.InputEmail(BuilderEmail);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			ConstructBuilder.NextPage();			
		}
	}
}
