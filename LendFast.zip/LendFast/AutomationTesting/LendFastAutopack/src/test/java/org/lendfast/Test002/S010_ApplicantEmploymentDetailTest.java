package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantEmploymentDetail;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S010_ApplicantEmploymentDetailTest extends ParentPage 
{
	ApplicantEmploymentDetail applicantemploymentdetail;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Employment
		applicantemploymentdetail = new ApplicantEmploymentDetail();
		funclib=new CommonFuncLib();
	}
	
	//Validating Heading Section
	@Test
	public void Validate_HeadingSection()
	{		
		try 
		{
			funclib.DelayTime();
			String SectionText=applicantemploymentdetail.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Employments for Applicant");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}				
	}

	//Go to Next Page
	@Test
	public void NextClick() throws InterruptedException
	{
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		Thread.sleep(1000);
		applicantemploymentdetail.ModifyClick();		
	}


}
