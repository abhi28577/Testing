package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.action.ActionHomePage;
import org.lendfast.utils.TestDataUtil;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S127_ActionGenerateDocListTest extends ParentPage
{
	ActionHomePage actionhomepage;	
	CommonFuncLib funclib; 
	
	String DocSheetName = "docgeneration";	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Action Type 
		actionhomepage = new ActionHomePage();		
		funclib=new CommonFuncLib();
	}	
	
	@DataProvider
	public Object[][] DocGenHome()
	{
		//Extracting Contract Details from Excel Sheet
		Object ActionType[][] = TestDataUtil.getTestData(DocSheetName);
		return ActionType;
	}	
	
	
	@Test
	public void SecondActionContractType() throws InterruptedException
	{		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		funclib.DelayTime();

		//Heading section
		//String SectionText=actionhomepage.CaptureHeadSection();		
		//System.out.println("Heading Section:" + SectionText);
		//Assert.assertEquals(SectionText, "Action");							
					
		//Click on Document Generator Tab
		funclib.DelayTime();
		actionhomepage.DocGeneratorClick();		
	}
		
	@Test (dataProvider = "DocGenHome")
	public void SecondDocumentGenerationList(String TestCaseId, String DocList) throws InterruptedException
	{
		String TestDataValue = "TC002_02";
		
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		
		if(TestDataValue .equals(TestCaseId))
		{		
			
			//Select Miscellenous Documents
			actionhomepage.MiscellaneousDocs(DocList);
		}
		
	}
	
	@Test
	public void Validate_SecondDocumentGeneration() throws InterruptedException
	{		
			actionhomepage.GenerateDocuments();
			funclib.DelayTime();				
	}
}
