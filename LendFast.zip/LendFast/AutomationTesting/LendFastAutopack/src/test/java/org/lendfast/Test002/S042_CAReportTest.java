package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.decision.CAReports;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S042_CAReportTest extends ParentPage
{
	CAReports careports;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  CA Reports
		careports = new CAReports();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_CreditCAReports() throws InterruptedException
	{
		funclib.DelayTime();
		String SectionText=careports.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "CA Reports");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Navigate to Next Page
		careports.NextPage();
	}
	
}
