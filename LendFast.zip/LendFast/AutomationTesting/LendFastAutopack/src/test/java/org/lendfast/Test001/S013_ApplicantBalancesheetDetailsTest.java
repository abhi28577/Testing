package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantBalancesheetDetails;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S013_ApplicantBalancesheetDetailsTest extends ParentPage 
{
	ApplicantBalancesheetDetails applicantbalancesheet;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Balancesheet Details
		applicantbalancesheet=new ApplicantBalancesheetDetails();
		funclib=new CommonFuncLib();
	}
	
	//Validating Heading Section
	@Test
	public void Validate_HeadingSection() throws InterruptedException
	{		
		try 
		{
			funclib.DelayTime();
			String SectionText=applicantbalancesheet.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Balance Sheet Details");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		funclib.DelayTime();
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		funclib.DelayTime();
		//Go to Next Page
		applicantbalancesheet.NextClick();
	}		
	
}
