package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_PropertySecurity;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S027_Purpose_PropertySecurityTest extends ParentPage 
{
	Purpose_PropertySecurity PropertySecurity;
	CommonFuncLib funclib; 
	String SheetName = "purpose_security";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		PropertySecurity = new Purpose_PropertySecurity();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] PropertySecurity()
	{
		//Extracting Contract Details from Excel Sheet
		Object PropertyContract[][] = TestDataUtil.getTestData(SheetName);
		return PropertyContract;
	}
	
	@Test (dataProvider = "PropertySecurity")
	public void Validate_PropertySecurity(String TestCaseId,String PurchaseContract, String ApplicantPurchaser,String GuarantorPurchaser, String ProposedOwner, String SpellCheck, String RealEstateAgent) throws InterruptedException
	{
		String TestDataValue = "TC001";
		String NullType="null";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=PropertySecurity.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Property Security");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Purchaser Contract List
			funclib.DelayTime();
			String PurchaserContractVal = PropertySecurity.SelPurchaserContractList(PurchaseContract);		
			System.out.println("Purchaser Contract:" + PurchaserContractVal);
			Assert.assertEquals(PurchaserContractVal.toUpperCase(), PurchaseContract.toUpperCase());
			
			//Click on Purchaser as Applicant and Capture Approver Text
			funclib.DelayTime();
			String ApplicantApproverResult = PropertySecurity.CaptureApplicantPurchaserApproval(ApplicantPurchaser);		
			System.out.println("Result of Applicant Approval:" + ApplicantApproverResult);
			Assert.assertEquals(ApplicantApproverResult.toUpperCase(), "APPLICANT PURCHASER APPROVED: PASSED");
			
			//Click on Purchaser as Guarantor and Capture Approver Text
			funclib.DelayTime();
			if(!GuarantorPurchaser .equals(NullType))
			{
				String GuarantorApproverResult = PropertySecurity.CaptureGuarantorPurchaserApproval(GuarantorPurchaser);		
				System.out.println("Result of Guarantor Approval:" + GuarantorApproverResult);
			
				if(GuarantorApproverResult =="Guarantor Purchaser Approved: Passed")		
					Assert.assertEquals(GuarantorApproverResult.toUpperCase(), "GUARANTOR PURCHASER APPROVED: PASSED");
				else
					Assert.assertEquals(GuarantorApproverResult.toUpperCase(), "GUARANTOR PURCHASER NOT APPROVED: PASSED");
			}
			
			//Validate Applicant Name matches with Proposed Applicant Name
			funclib.DelayTime();
			String ApplicantNameMatchResult = PropertySecurity.ApplicantGuarantorCompare();		
			System.out.println("Result of Applicant's Name Match:" + ApplicantNameMatchResult);
			Assert.assertEquals( ApplicantNameMatchResult.toUpperCase(), "PROPOSED NAMES: MATCH");
					
			//Select SpellCheck Borrowers/Guarantors
			funclib.DelayTime();
			String SpellCheckResult = PropertySecurity.SelSpellCheck(SpellCheck);		
			System.out.println("SpellCheck Result:" + SpellCheckResult);
			Assert.assertEquals(SpellCheckResult.toUpperCase(), SpellCheck.toUpperCase());
			
			//Select Purchase via Real Estate (Yes/No)
			funclib.DelayTime();
			String RealEstatePurchaseResult = PropertySecurity.SelPurchaseRealEstateAgent(RealEstateAgent);		
			System.out.println("Purchase from Real Estate Agent:" + RealEstatePurchaseResult);
			Assert.assertEquals(RealEstatePurchaseResult.toUpperCase(), RealEstateAgent.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
						
			//Navigate to Next Page
			PropertySecurity.NextPage();
		}
	}	
}
