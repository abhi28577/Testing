package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantCurrentEmployment;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S011_ApplicantCurrentEmploymentTest extends ParentPage 
{
	ApplicantCurrentEmployment applicantcurrentemployment;
	CommonFuncLib funclib;
	String SheetName = "personal_employment";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Employment
		applicantcurrentemployment = new ApplicantCurrentEmployment();
		funclib=new CommonFuncLib();
	}
	
		
	@DataProvider
	public Object[][] EmpStatusType()
	{
		//Extracting Employment Status from Excel Sheet
		Object EmpStatusType[][] = TestDataUtil.getTestData(SheetName);
		return EmpStatusType;
	}

	@Test (dataProvider = "EmpStatusType")
	public void Validate_ApplicantEmpStatusType(String TestCaseId, String Party,String EmpStat, String EmployerType, String IncomePercentage,String BusinessName,String ABNVal,String PositionType,String EmpAddress,String IndustryYears,String IndustryMonths,String AccountantName,String AccountPhone,String Probation,String SalaryVal,String GrossNet,String FrequencyType,String SalaryVal1,String GrossNet1,String FrequencyType1,String SalaryVal2,String GrossNet2,String FrequencyType2) throws InterruptedException
	{		
		String TestDataValue = "TC002_01";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=applicantcurrentemployment.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Current Employment Details for Individual");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Thread.sleep(1000);
			// Select Employment Status
			String EmpStatusTypeVal = applicantcurrentemployment.SelEmpStatusType(EmpStat);
			System.out.println("Applicant Employment Status Type:" + EmpStatusTypeVal);
			Assert.assertEquals(EmpStatusTypeVal, EmpStat);
			
			funclib.DelayTime();
			// Input Business Name
			applicantcurrentemployment.InputBusinessName(BusinessName);
			
			funclib.DelayTime();
			// Select Employer Type
			String EmployerTypeVal = applicantcurrentemployment.SelEmployerType(EmployerType);
			System.out.println("Applicant Employer Type:" + EmployerTypeVal);
			Assert.assertEquals(EmployerTypeVal, EmployerType);		
			
			funclib.DelayTime();
			// Input Position
			applicantcurrentemployment.InputPositionValue(PositionType);
			
			funclib.DelayTime();
			// Input Employer Address
			applicantcurrentemployment.InputEmpAddress(EmpAddress);
			
			funclib.DelayTime();
			// Input Industry in Years
			applicantcurrentemployment.InputIndustryYears(IndustryYears);
			
			funclib.DelayTime();
			// Input Industry in Months
			applicantcurrentemployment.InputIndustryMonths(IndustryMonths);
			
			funclib.DelayTime();
			// Select Probation (Yes or No)
			String ProbationVal = applicantcurrentemployment.SelProbation(Probation);		
			System.out.println("Applicant Probation:" + ProbationVal);
			Assert.assertEquals(ProbationVal.toUpperCase(), Probation.toUpperCase());
			
			funclib.DelayTime();
			// Input Salary/Drawings
			applicantcurrentemployment.InputSalaryIncome(SalaryVal);
			
			funclib.DelayTime();
			// Select Gross/Net
			String GrossVal = applicantcurrentemployment.SelGrossNetType(GrossNet);
			System.out.println("Gross/Net Type:" + GrossVal);
			Assert.assertEquals(GrossVal, GrossNet);
			
			funclib.DelayTime();
			// Select Frequency Type
			String FrequencyVal = applicantcurrentemployment.SelFrequencyType(FrequencyType);
			System.out.println("Frequency:" + FrequencyVal);
			Assert.assertEquals(FrequencyVal, FrequencyType);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			applicantcurrentemployment.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			applicantcurrentemployment.NextPage();
		}
	}
}
