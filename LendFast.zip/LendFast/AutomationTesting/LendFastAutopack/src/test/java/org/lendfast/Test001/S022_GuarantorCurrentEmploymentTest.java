package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.GuarantorCurrentEmployment;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S022_GuarantorCurrentEmploymentTest extends ParentPage 
{
	GuarantorCurrentEmployment guarantorcurrentemployment;
	CommonFuncLib funclib;
	String SheetName = "personal_employment";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Guarantor Employment
		guarantorcurrentemployment = new GuarantorCurrentEmployment();
		funclib=new CommonFuncLib();
	}
	
		
	@DataProvider
	public Object[][] EmpStatusType()
	{
		//Extracting Employment Status from Excel Sheet
		Object EmpStatusType[][] = TestDataUtil.getTestData(SheetName);
		return EmpStatusType;
	}

	@Test (dataProvider = "EmpStatusType")
	public void Validate_GuarantorEmpStatusType(String TestCaseId, String Party,String EmpStat, String EmployerType, String IncomePercent, String EmployerName, String ABNType, String PositionType,String EmpAddress,String IndustryYears,String IndustryMonths, String AccountantName, String AccountantPhone, String Probation,String SalaryVal,String GrossNet,String FrequencyType,String SalaryVal1,String GrossNet1,String FrequencyType1,String SalaryVal2,String GrossNet2,String FrequencyType2) throws InterruptedException
	{		
		String TestDataValue = "TC001_02";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=guarantorcurrentemployment.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Current Employment Details for Individual");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			funclib.DelayTime();
			// Select Employment Status
			String EmpStatusTypeVal = guarantorcurrentemployment.SelEmpStatusType(EmpStat);
			System.out.println("Applicant Employment Status Type:" + EmpStatusTypeVal);
			Assert.assertEquals(EmpStatusTypeVal, EmpStat);
			
			funclib.DelayTime();
			// Input Business Name
			guarantorcurrentemployment.InputBusinessName(EmployerName);
			
			funclib.DelayTime();
			// Select Employer Type
			String EmployerTypeVal = guarantorcurrentemployment.SelEmployerType(EmployerType);
			System.out.println("Applicant Employer Type:" + EmployerTypeVal);
			Assert.assertEquals(EmployerTypeVal, EmployerType);		
			
			funclib.DelayTime();
			// Input Position
			guarantorcurrentemployment.InputPositionValue(PositionType);
			
			funclib.DelayTime();
			// Input Employer Address
			guarantorcurrentemployment.InputEmpAddress(EmpAddress);
			
			funclib.DelayTime();
			// Input Industry in Years
			guarantorcurrentemployment.InputIndustryYears(IndustryYears);
			
			funclib.DelayTime();
			// Input Industry in Months
			guarantorcurrentemployment.InputIndustryMonths(IndustryMonths);
			
			funclib.DelayTime();
			// Select Probation (Yes or No)
			String ProbationVal = guarantorcurrentemployment.SelProbation(Probation);		
			System.out.println("Applicant Probation:" + ProbationVal);
			Assert.assertEquals(ProbationVal.toUpperCase(), Probation.toUpperCase());
			
			funclib.DelayTime();
			// Input Salary/Drawings
			guarantorcurrentemployment.InputSalaryIncome(SalaryVal);
			
			funclib.DelayTime();
			// Select Gross/Net
			String GrossVal = guarantorcurrentemployment.SelGrossNetType(GrossNet);
			System.out.println("Gross/Net Type:" + GrossVal);
			Assert.assertEquals(GrossVal, GrossNet);
			
			funclib.DelayTime();
			// Select Frequency Type
			String FrequencyVal = guarantorcurrentemployment.SelFrequencyType(FrequencyType);
			System.out.println("Frequency:" + FrequencyVal);
			Assert.assertEquals(FrequencyVal, FrequencyType);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			guarantorcurrentemployment.NextPage();
		}
	}
}
