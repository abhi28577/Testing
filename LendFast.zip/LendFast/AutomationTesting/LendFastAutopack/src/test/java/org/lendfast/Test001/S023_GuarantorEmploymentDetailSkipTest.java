package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.GuarantorEmploymentDetailSkip;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S023_GuarantorEmploymentDetailSkipTest extends ParentPage
{
	GuarantorEmploymentDetailSkip guarantoremploymentdetailskip;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Guarantor Employment
		guarantoremploymentdetailskip = new GuarantorEmploymentDetailSkip();
		funclib=new CommonFuncLib();
	}
	
	//Validating Heading Section
	@Test
	public void Validate_HeadingSection() throws InterruptedException
	{	
		String SectionText=null;
		try 
		{
			funclib.DelayTime();
			SectionText=guarantoremploymentdetailskip.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Employments for Guarantor");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Go to Next Page
		funclib.DelayTime();
		guarantoremploymentdetailskip.NextClick();
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Go to Next Page
		funclib.DelayTime();
		guarantoremploymentdetailskip.NextClick();
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
				
		funclib.DelayTime();
		String SectionTextExisting=null;
		String ExistHeadSection = "Existing Applications";
		SectionTextExisting=guarantoremploymentdetailskip.CaptureHeadSectionExisting();		
		System.out.println("Heading Section:" + SectionTextExisting);
		Assert.assertEquals(SectionTextExisting, "Existing Applications");
			
		if(SectionTextExisting .equals(ExistHeadSection))
		{
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Go to Next Page
			funclib.DelayTime();
			guarantoremploymentdetailskip.NextClick();					
				
		}			
	}
}
