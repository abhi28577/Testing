package org.lendfast.Test003;


import java.net.MalformedURLException;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.login.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.lendfast.utils.TestCredentialsUtil;

public class S001_LoginPageTest extends ParentPage 
{
	LoginPage loginpage;
	String SheetName = "testcredentials";
	CommonFuncLib funclib;
	
	public S001_LoginPageTest()
	{
		super();
	}
	
	@BeforeTest
	public void BrowserInitialize() throws MalformedURLException
	{
		initialization();
		//GridBrowserSetUp();
	}
	
	@BeforeMethod
	public void SetUp()
	{		
		loginpage=new LoginPage();
		funclib=new CommonFuncLib();
	}	
		
	@Test
	public void Validate_LoginPage_Title() throws InterruptedException
	{		
		funclib.DelayTime();
		String HeadTitle=loginpage.PageTitle();
		funclib.DelayTime();
		System.out.println("Page Title of Login Page:Origination:" + HeadTitle);
		Assert.assertEquals(HeadTitle, "LendFast");			
	}
	
	@DataProvider
	public Object[][] LoginCredentials()
	{
		Object logincred[][] = TestCredentialsUtil.getTestData(SheetName);
		return logincred;
	}
	
	@Test (dataProvider = "LoginCredentials") 
	public void Validate_Login_Credentials(String User, String Pwd) throws InterruptedException
	{
		String UserId= "abhishek.paspuleti";	
		
		if(UserId .equals(User))
		{
			loginpage.LoginCredentials(User, Pwd);
			
			funclib.DelayTime();
			String HeadTitle=loginpage.PageTitle();
			Assert.assertEquals(HeadTitle, "LendFast");
		}	
	}
}
