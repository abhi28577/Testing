package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_Purposes;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S024_Purpose_PurposesTest extends ParentPage 
{
	Purpose_Purposes Purpose;
	CommonFuncLib funclib; 
	String SheetName = "purpose_contract";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Purpose Contract
		Purpose = new Purpose_Purposes();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] PurposeContract()
	{
		//Extracting Contract Details from Excel Sheet
		Object ContractType[][] = TestDataUtil.getTestData(SheetName);
		return ContractType;
	}

	@Test (dataProvider = "PurposeContract")
	public void Validate_PurposeContract(String TestCaseId,String LoanPurposeType, String OtherPurpose, String OtherPayType, String CustAccountNumber, String PayableTo, String AmountRequired,String PropertyApprovalType, String SecurityType,String PropertyFound,String ManualAddress,String AustralianAddress,String PropertyName,String HouseNum,String HouseUnit,String HouseLevel,String HouseStreetName,String HouseStreetType,String HouseStreetSuffix,String HouseSuburb,String HouseState,String HousePostalCode,String PropertyZone,String PropertyContract,String ContractAvailable,String ContractSigned,String SignedDate,String VendorName) throws InterruptedException
	{
		String TestDataValue = "TC001";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=Purpose.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Purposes");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Loan Purpose Type
			funclib.DelayTime();
			String LoanPurposeVal = Purpose.SelLoanPurposeType(LoanPurposeType);		
			System.out.println("Loan Purpose Type:" + LoanPurposeVal);
			Assert.assertEquals(LoanPurposeVal.toUpperCase(), LoanPurposeType.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			Thread.sleep(1000);
			//Click on AddPurpose
			Purpose.AddPurposePage();
		}
	}	
}
