package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.applicationtype.ApplicationType;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S003_ApplicationTypeTest extends ParentPage 
{
		ApplicationType applicationtype;
		CommonFuncLib funclib;		
		String SheetName = "applicationtype";

	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Application Type
		applicationtype = new ApplicationType();
		funclib=new CommonFuncLib();
	}	
	
	@DataProvider
	public Object[][] ApplicationType()
	{
		//Extracting Values from Excel Sheet
		Object apptype[][] = TestDataUtil.getTestData(SheetName);
		return apptype;
	}

	@Test (dataProvider = "ApplicationType")
	public void Validate_ApplicationType(String TestCaseId,String AppType, String TopUp, String AccountNumber, String Origin, String OriginLevel, String OriginLevel2,String Referrer, String ApplicationId) throws InterruptedException
	{
		//String RunValue = "Execute";
		String TestDataValue = "TC002";
		
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=applicationtype.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Application Type");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			// Selecting Application Type
			funclib.DelayTime();
			String AppTypeVal = applicationtype.SelApplicationType(AppType);
			System.out.println("Application Type:" + AppTypeVal);
			Assert.assertEquals(AppType, AppTypeVal);
			
			// Selecting Existing Top Up Type
			funclib.DelayTime();
			String TopUpVal = applicationtype.SelExistTopUp(TopUp);		
			System.out.println("Top Up Needed:" + TopUpVal);
			Assert.assertEquals(TopUpVal.toUpperCase(), TopUp.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			funclib.DelayTime();
			
			//Navigate to Next Page
			applicationtype.NextPage();
		}	
	}

}