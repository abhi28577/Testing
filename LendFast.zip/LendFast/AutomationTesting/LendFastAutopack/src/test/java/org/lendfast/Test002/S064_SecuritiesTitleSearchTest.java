package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.securities.SecuritiesTitleSearch;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S064_SecuritiesTitleSearchTest extends ParentPage 
{
	SecuritiesTitleSearch SecurityTitleSearch;
	CommonFuncLib funclib; 
	String SheetName = "SettlementSecurities";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Securities Home 
		SecurityTitleSearch = new SecuritiesTitleSearch();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] SecuritiesTitle()
	{
		//Extracting Contract Details from Excel Sheet
		Object SecurityTitle[][] = TestDataUtil.getTestData(SheetName);
		return SecurityTitle;
	}
	
	
	@Test (dataProvider = "SecuritiesTitle")
	public void Validate_Settlement1SecuritiesTitleSearch(String TestCaseId, String ValidResult, String TitleType, String TitleVendorNameMatch, String PropertyContractMatch, String LandTransfer, String VendorOwnerLandTransferMatch, String EstateInterest, String ProceedAcceptable, String PhysicalTitle, String AncillaryTitle, String Encumbrances, String UnRegisteredDeal, String MortgageRank) throws InterruptedException
	{
		String TestId="TC002";
		
		//Validating Heading Section
		try 
		{
			funclib.DelayTime();
			String SectionText=SecurityTitleSearch.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "LTO Searches");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		if(TestId .equals(TestCaseId))
		{
			//Click on Add Title Extract Search
			SecurityTitleSearch.TitleSearch();			
			funclib.DelayTime();
			
			//Select Valid Search Result
			String ValidResults = SecurityTitleSearch.SelValidResult(ValidResult);
			System.out.println("Valid Research Result:" + ValidResults);
			funclib.DelayTime();
		
			//Select Title Type
			String TitleTypeResult = SecurityTitleSearch.SelTitleType(TitleType);
			System.out.println("Title Type Result:" + TitleTypeResult);
			funclib.DelayTime();
		
			//Select Title-Vendor Name Match
			String VendorNameMatch = SecurityTitleSearch.SelTitleNameMatch(TitleVendorNameMatch);
			System.out.println("Title Vendor Name Match Result:" + VendorNameMatch);
			funclib.DelayTime();
		
			//Select Real Property Match
			String PropertyMatchResult = SecurityTitleSearch.SelRealPropertyMatch(PropertyContractMatch);
			System.out.println("Real Property Match Result:" + PropertyMatchResult);
			funclib.DelayTime();
		
			//Select Transfer of Land
			String LandTransferResult = SecurityTitleSearch.SelLandTransfer(LandTransfer);
			System.out.println("Transfer of Land Result:" + LandTransferResult);
			funclib.DelayTime();
		
			//Select Transfer of Land -> Vendor-Owner Name Match
			String VendorOwnerLandTransferResult = SecurityTitleSearch.SelLandTransferMatch(VendorOwnerLandTransferMatch);
			System.out.println("Vendor Owner Land Transfer Result:" + VendorOwnerLandTransferResult);
			funclib.DelayTime();
		
			//Select Estate and Interest
			String EstateInterestResult = SecurityTitleSearch.SelEstateInterest(EstateInterest);
			System.out.println("Estate Interest Result:" + EstateInterestResult);
			funclib.DelayTime();
		
			//Select Acceptance of Proceed
			String AcceptanceProceedResult = SecurityTitleSearch.SelAcceptanceProceed(ProceedAcceptable);
			System.out.println("Acceptance Proceed Result:" + AcceptanceProceedResult);
			funclib.DelayTime();
		
			//Select Physical Title Existence
			String PhysicalTitleResult = SecurityTitleSearch.SelPhysicalTitle(PhysicalTitle);
			System.out.println("Physical Title Result:" + PhysicalTitleResult);
			funclib.DelayTime();
		
			//Select Ancillary Title
			String AncillaryTitleResult = SecurityTitleSearch.SelAncillaryTitle(AncillaryTitle);
			System.out.println("Ancillary Title Result:" + AncillaryTitleResult);
			funclib.DelayTime();
		
			//Navigate to Next Page
			SecurityTitleSearch.NextPage();
			funclib.DelayTime();
		}
	}

}
