package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.checklist.ChecklistSettlement;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S080_CheckListSettlementTest extends ParentPage 
{
	ChecklistSettlement Chklist;
	CommonFuncLib funclib; 
	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  CheckList
		Chklist = new ChecklistSettlement();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_FirstSettlementDocuments() throws InterruptedException
	{	
		//Validating Heading Section
		try 
		{
			funclib.DelayTime();
			String SectionText=Chklist.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Check List");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Select Non-Mandatory List
		Chklist.NonMandatory();
		
		
		//Submission Position
		Chklist.SubmissionPos();
		
		
		//Navigate to Next Page (Checklist)
		Chklist.NextPage();
		
		//Navigate to Next Page (Additional Conditions Page)
		Chklist.NextPage();
		
		
	}
}
