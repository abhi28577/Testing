package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantBankrupt;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S008_ApplicantBankruptTest extends ParentPage
{
	ApplicantBankrupt applicantbankrupt;
	CommonFuncLib funclib; 
	String SheetName = "personal_bankrupt";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Bankrupt
		applicantbankrupt = new ApplicantBankrupt();
		funclib=new CommonFuncLib();
	}	
	
	
	@DataProvider
	public Object[][] BankruptType()
	{
		//Extracting Bankrupt Details from Excel Sheet
		Object Insolventtype[][] = TestDataUtil.getTestData(SheetName);
		return Insolventtype;
	}

	@Test (dataProvider = "BankruptType")
	public void Validate_ApplicantBankruptType(String TestCaseId, String Party,String Bankrupt, String Creditor, String LegalProceed) throws InterruptedException
	{
		String TestDataValue = "TC002_01";
		
		if(TestDataValue .equals(TestCaseId))
		{		
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=applicantbankrupt.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Bankruptcy Detail for Applicant");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			funclib.DelayTime();
			// Select Applicant Bankrupt/Insolvent
			String BankruptVal = applicantbankrupt.SelBankruptType(Bankrupt);		
			System.out.println("Applicant Bankrupt:" + BankruptVal);
			Assert.assertEquals(BankruptVal.toUpperCase(), Bankrupt.toUpperCase());
			
			funclib.DelayTime();
			// Select Applicant Creditor
			String CreditorVal = applicantbankrupt.SelCreditorType(Creditor);		
			System.out.println("Applicant Creditor:" + CreditorVal);
			Assert.assertEquals(CreditorVal.toUpperCase(), Creditor.toUpperCase());
			
			funclib.DelayTime();
			// Select Applicant Legal Proceedings
			String LegalProceedVal = applicantbankrupt.SelLegalProceedType(LegalProceed);		
			System.out.println("Applicant Legal Proceed:" + LegalProceedVal);
			Assert.assertEquals(LegalProceedVal.toUpperCase(), LegalProceed.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			applicantbankrupt.NextPage();
		}	
	}

	
}
