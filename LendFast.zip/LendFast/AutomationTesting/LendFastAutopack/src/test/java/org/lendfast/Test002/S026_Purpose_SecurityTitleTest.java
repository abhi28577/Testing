package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_SecurityTitle;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S026_Purpose_SecurityTitleTest extends ParentPage
{
	Purpose_SecurityTitle PurposeSecurity;
	CommonFuncLib funclib; 
	String SheetName = "purpose_securitytitle";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		PurposeSecurity = new Purpose_SecurityTitle();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] PurposeSecurity()
	{
		//Extracting Contract Details from Excel Sheet
		Object PropertyContract[][] = TestDataUtil.getTestData(SheetName);
		return PropertyContract;
	}
	
	@Test (dataProvider = "PurposeSecurity")
	public void Validate_SecurityPurpose(String TestCaseId,String TitleRegister, String TitleName, String PolicyType) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=PurposeSecurity.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Security Title");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			//Select Title Registration
			funclib.DelayTime();
			String TitleRegistrationVal = PurposeSecurity.SelTitleRegister(TitleRegister);		
			System.out.println("Title Registration:" + TitleRegistrationVal);
			Assert.assertEquals(TitleRegistrationVal.toUpperCase(), TitleRegister.toUpperCase());
					
			// Add Property Title
			funclib.DelayTime();
			PurposeSecurity.AddPropertyTitle();
			
			// Add Property Title
			funclib.DelayTime();
			PurposeSecurity.InputPropertyTitle(TitleName);
			
			funclib.DelayTime();
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			PurposeSecurity.NextPage();	
			
			Thread.sleep(1000);
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			PurposeSecurity.NextPage();	
			
			Thread.sleep(1000);
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			PurposeSecurity.NextPage();	
		}
	}	
}
