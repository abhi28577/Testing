package org.lendfast.Test003;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_OtherPurpose;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S015_Purpose_OtherPurposeTest extends ParentPage
{
	Purpose_OtherPurpose OtherPurpose;
	CommonFuncLib funclib;	
	String SheetName = "purpose_contract";
	
	@BeforeMethod
	public void SetUp()
	{
		//Initializing Other Purpose Constructor
		OtherPurpose = new Purpose_OtherPurpose();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] OtherPurpose()
	{
		//Extracting Other Purpose from Excel Sheet
		Object OtherPurpose[][] = TestDataUtil.getTestData(SheetName);
		return OtherPurpose;
	}

	@Test (dataProvider = "OtherPurpose")
	public void Validate_OtherPurpose(String TestCaseId,String LoanPurposeType, String OtherPurposes, String OtherPayType, String CustAccountNumber, String PayableTo, String AmountRequired,String PropertyApprovalType, String SecurityType,String PropertyFound,String ManualAddress,String AustralianAddress,String PropertyName,String HouseNum,String HouseUnit,String HouseLevel,String HouseStreetName,String HouseStreetType,String HouseStreetSuffix,String HouseSuburb,String HouseState,String HousePostalCode,String PropertyZone,String PropertyContract,String ContractAvailable,String ContractSigned,String SignedDate,String VendorName) throws InterruptedException
	{
		String TestDataValue = "TC003";
		
		
		if(TestDataValue .equals(TestCaseId))
		{			
		
			//Validating Heading Section		
			try 
			{
				funclib.DelayTime();
				String SectionText=OtherPurpose.CaptureHeadSection();
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Other Purpose");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			// Selecting Other Purpose Type
			funclib.DelayTime();
			String OtherPurposeVal = OtherPurpose.SelOtherPurpose(OtherPurposes);		
			System.out.println("Other Purpose:" + OtherPurposeVal);
			Assert.assertEquals(OtherPurposeVal.toUpperCase(), OtherPurposes.toUpperCase());
			
			// Selecting Payment Type
			funclib.DelayTime();
			String PaymentTypeVal = OtherPurpose.SelPayment(OtherPayType);		
			System.out.println("Payment Type:" + PaymentTypeVal);
			Assert.assertEquals(PaymentTypeVal.toUpperCase(), OtherPayType.toUpperCase());
			
			//Input Payable To
			funclib.DelayTime();
			OtherPurpose.InputPayableTo(PayableTo);
			
			//Input Amount Required
			funclib.DelayTime();
			OtherPurpose.InputAmountRequired(AmountRequired);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Purposes Page
			OtherPurpose.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Assets Page
			OtherPurpose.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Liabilities Page
			OtherPurpose.NextPage();
			
			
		}
	}
}
