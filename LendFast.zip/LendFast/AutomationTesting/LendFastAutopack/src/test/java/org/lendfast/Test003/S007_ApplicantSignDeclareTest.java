package org.lendfast.Test003;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantSignDeclare;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S007_ApplicantSignDeclareTest extends ParentPage 
{
	ApplicantSignDeclare applicantsigndeclare;
	CommonFuncLib funclib;
	String SheetName = "personal_signdeclare";


	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Application Type
		applicantsigndeclare = new ApplicantSignDeclare();
		funclib=new CommonFuncLib();
	}
	
	
	@DataProvider
	public Object[][] SignDeclarationType()
	{
		//Extracting Values from Excel Sheet
		Object SignDeclaretype[][] = TestDataUtil.getTestData(SheetName);
		return SignDeclaretype;
	}

	@Test (dataProvider = "SignDeclarationType")
	public void Validate_ApplicantSignedDeclaration(String TestCaseId, String Party,String PartySigned, String Consent, String IdentityType, String StateType, String IdentificationNumber) throws InterruptedException
	{
		String TestDataValue = "TC003_01";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=applicantsigndeclare.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Signed Declaration for Applicant");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			funclib.DelayTime();
			// Select Applicant Declaration
			String PartySignedVal = applicantsigndeclare.SelDeclarationType(PartySigned);		
			System.out.println("Declaration Type:" + PartySignedVal);
			Assert.assertEquals(PartySignedVal.toUpperCase(), PartySigned.toUpperCase());
			
			funclib.DelayTime();
			// Select Identification Type	
			String IdentityTypeVal = applicantsigndeclare.SelIdentityType(IdentityType);
			System.out.println("Identification Type:" + IdentityTypeVal);
			Assert.assertEquals(IdentityTypeVal, IdentityType);
			
			funclib.DelayTime();
			// Select State of Issue
			String StateTypeVal = applicantsigndeclare.SelStateType(StateType);
			System.out.println("State Type:" + StateTypeVal);
			Assert.assertEquals(StateTypeVal, StateType);
			
			funclib.DelayTime();
			// Input Identification Number
			applicantsigndeclare.InputIdentificationNumber(IdentificationNumber);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			applicantsigndeclare.NextPage();
		}
	}

}
