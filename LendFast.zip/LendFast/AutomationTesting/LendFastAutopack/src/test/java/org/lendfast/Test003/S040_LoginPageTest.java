package org.lendfast.Test003;


import java.net.MalformedURLException;

import org.lendfast.base.ParentPage;
import org.lendfast.pages.login.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.lendfast.utils.TestCredentialsUtil;

public class S040_LoginPageTest extends ParentPage 
{
	LoginPage loginpage;
	String SheetName = "testcredentials";
	
	public S040_LoginPageTest()
	{
		super();
	}
	
/*	@BeforeTest
	public void BrowserInitialize() throws MalformedURLException
	{
		//initialization();
		//GridBrowserSetUp();
	}
*/	
	@BeforeMethod
	public void SetUp()
	{		
		loginpage=new LoginPage();
	}	
		
	@Test
	public void Validate_SettlementLoginPage_Title() throws MalformedURLException
	{		
		//initialization();
		//GridBrowserSetUp();
		
		String HeadTitle=loginpage.PageTitle();
		System.out.println("Page Title of Login Page:Settlement:" + HeadTitle);
		Assert.assertEquals(HeadTitle, "LendFast");			
	}
	
	@DataProvider
	public Object[][] LoginCredentials()
	{
		Object logincred[][] = TestCredentialsUtil.getTestData(SheetName);
		return logincred;
	}
	
	@Test (dataProvider = "LoginCredentials") 
	public void Validate_SettlementLogin_Credentials(String User, String Pwd) throws InterruptedException
	{
		String UserId= "kris.chapman";
		
		if(UserId .equals(User))
		{
			loginpage.LoginCredentials(User, Pwd);
		
			String HeadTitle=loginpage.PageTitle();
			Assert.assertEquals(HeadTitle, "LendFast");
		}
	}
}
