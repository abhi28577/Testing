package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.GuarantorCurrentAddress;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S020_GuarantorCurrentAddressTest extends ParentPage 
{
	GuarantorCurrentAddress guarantorcurrentaddress;
	CommonFuncLib funclib;
	String SheetName = "personal_address";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Current Address
		guarantorcurrentaddress = new GuarantorCurrentAddress();
		funclib=new CommonFuncLib();
	}
	
	
	
	@DataProvider
	public Object[][] ResidentialType()
	{
		//Extracting Residential Type from Excel Sheet
		Object ResidentialType[][] = TestDataUtil.getTestData(SheetName);
		return ResidentialType;
	}

	@Test (dataProvider = "ResidentialType")
	public void Validate_GuarantorResidentialType(String TestCaseId, String Party,String ResidentialStat, String ResidentialYears, String ResidentialMonths, String PostalAddressSame, String ResidencyStat) throws InterruptedException
	{		
		String TestDataValue = "TC001_02";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=guarantorcurrentaddress.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Current Address for Guarantor");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			
			funclib.DelayTime();
			// Select Residential Type
			String ResidentialTypeVal = guarantorcurrentaddress.SelResidentialType(ResidentialStat);
			System.out.println("Guarantor Residential Type:" + ResidentialTypeVal);
			Assert.assertEquals(ResidentialTypeVal, ResidentialStat);
			
			funclib.DelayTime();
			// Input Stay at Same Residence in Years
			guarantorcurrentaddress.InputAddressYears(ResidentialYears);
			
			funclib.DelayTime();
			// Input Stay at Same Residence in Months
			guarantorcurrentaddress.InputAddressMonths(ResidentialMonths);
			
			funclib.DelayTime();
			// Select Guarantor Postal Address same as Residential Address
			String PostalAddressVal = guarantorcurrentaddress.SelPostalAddressType(PostalAddressSame);		
			System.out.println("Applicant Postal Address Same:" + PostalAddressVal);
			Assert.assertEquals(PostalAddressVal.toUpperCase(), PostalAddressSame.toUpperCase());
			
			funclib.DelayTime();
			// Select Residency Status
			String ResidencyStatusVal = guarantorcurrentaddress.SelResidencyStatus(ResidencyStat);
			System.out.println("Applicant Residency Status:" + ResidencyStatusVal);
			Assert.assertEquals(ResidencyStatusVal, ResidencyStat);		
					
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			guarantorcurrentaddress.NextPage();
		}
	}

}
