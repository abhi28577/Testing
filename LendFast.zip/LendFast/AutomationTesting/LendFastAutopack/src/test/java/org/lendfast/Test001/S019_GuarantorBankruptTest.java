package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.GuarantorBankrupt;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S019_GuarantorBankruptTest extends ParentPage
{
	GuarantorBankrupt guarantorbankrupt;
	CommonFuncLib funclib;
	String SheetName = "personal_bankrupt";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Guarantor Bankrupt
		guarantorbankrupt = new GuarantorBankrupt();
		funclib=new CommonFuncLib();
	}	
	
	
	@DataProvider
	public Object[][] BankruptType()
	{
		//Extracting Bankrupt Details from Excel Sheet
		Object Insolventtype[][] = TestDataUtil.getTestData(SheetName);
		return Insolventtype;
	}

	@Test (dataProvider = "BankruptType")
	public void Validate_GuarantorBankruptType(String TestCaseId, String Party,String Bankrupt, String Creditor, String LegalProceed) throws InterruptedException
	{
		String TestDataValue = "TC001_02";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=guarantorbankrupt.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Bankruptcy Detail for Guarantor");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			funclib.DelayTime();
			// Select Guarantor Bankrupt/Insolvent
			String BankruptVal = guarantorbankrupt.SelBankruptType(Bankrupt);		
			System.out.println("Guarantor Bankrupt:" + BankruptVal);
			Assert.assertEquals(BankruptVal.toUpperCase(), Bankrupt.toUpperCase());
			
			funclib.DelayTime();
			// Select Guarantor Creditor
			String CreditorVal = guarantorbankrupt.SelCreditorType(Creditor);		
			System.out.println("Guarantor Creditor:" + CreditorVal);
			Assert.assertEquals(CreditorVal.toUpperCase(), Creditor.toUpperCase());
			
			funclib.DelayTime();
			// Select Guarantor Legal Proceedings
			String LegalProceedVal = guarantorbankrupt.SelLegalProceedType(LegalProceed);		
			System.out.println("Guarantor Legal Proceed:" + LegalProceedVal);
			Assert.assertEquals(LegalProceedVal.toUpperCase(), LegalProceed.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			guarantorbankrupt.NextPage();
		}
	}

}
