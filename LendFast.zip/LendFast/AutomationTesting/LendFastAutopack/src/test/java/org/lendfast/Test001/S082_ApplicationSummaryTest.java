package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.applicationtype.ApplicationSummary;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S082_ApplicationSummaryTest extends ParentPage 
{
	ApplicationSummary applicationsummary;
	CommonFuncLib funclib;		
	String SheetName = "applicationtype";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Application Summary
		applicationsummary = new ApplicationSummary();
		funclib=new CommonFuncLib();
	}	
	
	@DataProvider
	public Object[][] ApplicationSummary()
	{
		//Extracting Values from Excel Sheet
		Object apptype[][] = TestDataUtil.getTestData(SheetName);
		return apptype;
	}
	
	@Test (dataProvider = "ApplicationSummary")
	public void Validate_Settlement2ApplicationSummary(String TestCaseId,String AppType, String TopUp, String AccountNumber, String Origin, String OriginLevel, String OriginLevel2,  String Referrer, String ApplicationId) throws InterruptedException
	{
		//String RunValue = "Execute";
		String TestDataValue = "TC001";
		
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				//Capture Screenshot
				funclib.CaptureScreenShot();
				
				funclib.DelayTime();
				applicationsummary.SearchApplication(ApplicationId);
				
				//Click on Take Ownership Link
				funclib.DelayTime();
				applicationsummary.TakeOwnership();				
				
				String SectionText=applicationsummary.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Application Summary");
				
				//Capture Screenshot
				funclib.CaptureScreenShot();
				
				//Navigate to Next Page
				applicationsummary.NextPage();
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
	}

}
