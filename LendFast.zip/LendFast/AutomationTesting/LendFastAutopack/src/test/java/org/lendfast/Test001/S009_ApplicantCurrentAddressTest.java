package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantCurrentAddress;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S009_ApplicantCurrentAddressTest extends ParentPage 
{
	ApplicantCurrentAddress applicantcurrentaddress;
	CommonFuncLib funclib; 
	String SheetName = "personal_address";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Current Address
		applicantcurrentaddress = new ApplicantCurrentAddress();
		funclib=new CommonFuncLib();
	}
	
	
	
	@DataProvider
	public Object[][] ResidentialType()
	{
		//Extracting Residential Type from Excel Sheet
		Object ResidentialType[][] = TestDataUtil.getTestData(SheetName);
		return ResidentialType;
	}

	@Test (dataProvider = "ResidentialType")
	public void Validate_ApplicantResidentialType(String TestCaseId, String Party,String ResidentialStat, String ResidentialYears, String ResidentialMonths, String PostalAddressSame, String ResidencyStat) throws InterruptedException
	{		
String TestDataValue = "TC001_01";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=applicantcurrentaddress.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Current Address for Applicant");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			
			funclib.DelayTime();
			// Select Residential Type
			String ResidentialTypeVal = applicantcurrentaddress.SelResidentialType(ResidentialStat);
			System.out.println("Applicant Residential Type:" + ResidentialTypeVal);
			Assert.assertEquals(ResidentialTypeVal, ResidentialStat);
			
			funclib.DelayTime();
			// Input Stay at Same Residence in Years
			applicantcurrentaddress.InputAddressYears(ResidentialYears);
			
			funclib.DelayTime();
			// Input Stay at Same Residence in Months
			applicantcurrentaddress.InputAddressMonths(ResidentialMonths);
			
			funclib.DelayTime();
			// Select Applicant Postal Address same as Residential Address
			String PostalAddressVal = applicantcurrentaddress.SelPostalAddressType(PostalAddressSame);		
			System.out.println("Applicant Postal Address Same:" + PostalAddressVal);
			Assert.assertEquals(PostalAddressVal.toUpperCase(), PostalAddressSame.toUpperCase());
			
			funclib.DelayTime();
			// Select Residency Status
			String ResidencyStatusVal = applicantcurrentaddress.SelResidencyStatus(ResidencyStat);
			System.out.println("Applicant Residency Status:" + ResidencyStatusVal);
			Assert.assertEquals(ResidencyStatusVal, ResidencyStat);		
					
			funclib.DelayTime();
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			applicantcurrentaddress.NextPage();
		}
	}

}
