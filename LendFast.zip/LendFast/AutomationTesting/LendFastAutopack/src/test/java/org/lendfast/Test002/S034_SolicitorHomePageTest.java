package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.solicitor.SolicitorHomePage;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S034_SolicitorHomePageTest extends ParentPage 
{
	SolicitorHomePage Solicitor;
	CommonFuncLib funclib; 
	String SheetName = "solicitors";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Solicitors
		Solicitor = new SolicitorHomePage();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] Solicitor()
	{
		//Extracting Contract Details from Excel Sheet
		Object Mortgage[][] = TestDataUtil.getTestData(SheetName);
		return Mortgage;
	}
	
	@Test (dataProvider = "Solicitor")
	public void Validate_Solicitor(String TestCaseId,String ApprovalDate,String SolicitorType, String SolicitorName, String LoanApprovalType, String MailType, String MethodType, String Reference,String SettlementStatus, String SettlementDate, String Time, String Place, String Type) throws InterruptedException
	{	
		String SolicitorTransactionType= "TRUE";
		String MethodReferType="Courier";
		
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=Solicitor.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Customer Settlement Agent/Solicitor Details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			//Input Approval Date
			funclib.DelayTime();
			Solicitor.InputDate(ApprovalDate);
			
			//Select Settlement Type
			funclib.DelayTime();
			String SettlementTypeVal = Solicitor.SelSettlement(SolicitorType);		
			System.out.println("Solicitor Type:" + SettlementTypeVal);
			Assert.assertEquals(SettlementTypeVal.toUpperCase(), SolicitorType.toUpperCase());
			
			// If Solicitor Transaction Type - Yes
			if(SolicitorTransactionType .equals(SolicitorType))
			{			
				//Input Name
				funclib.DelayTime();
				Solicitor.InputSolicitorName(SolicitorName);
			
				//Click Name LookUp
				funclib.DelayTime();
				Solicitor.NameLookUp();
				funclib.DelayTime();
			
				//Click Seleck LookUp
				funclib.DelayTime();
				Solicitor.SelectNameLookUp();
				funclib.DelayTime();
			
				//Select Loan Approval Type
				funclib.DelayTime();
				String LoanApprovalTypeVal = Solicitor.SelLoanApprovalType(LoanApprovalType);		
				System.out.println("Loan Approval Type:" + LoanApprovalTypeVal);
				Assert.assertEquals(LoanApprovalTypeVal.toUpperCase(), LoanApprovalType.toUpperCase());
				
				//Mail Type for Solicitor
				funclib.DelayTime();
				String MailTypeVal = Solicitor.SelDocumentType(MailType);		
				System.out.println("Document Type for Solicitor:" + MailTypeVal);
				Assert.assertEquals(MailTypeVal.toUpperCase(), MailType.toUpperCase());
			}
			
			// If Solicitor Transaction Type - No (Non-Solicitor)
			if(!SolicitorTransactionType .equals(SolicitorType))
			{
				//Mail Type for Non-Solicitor
				funclib.DelayTime();
				String MailTypeVal = Solicitor.SelNonSolicitorDocumentType(MailType);
				System.out.println("Document Type for Non-Solicitor:" + MailTypeVal);
				Assert.assertEquals(MailTypeVal.toUpperCase(), MailType.toUpperCase());
			}
			
			
			
			//Method Type
			funclib.DelayTime();
			String MethodTypeVal = Solicitor.SelMethodType(MethodType);		
			System.out.println("Method Type:" + MethodTypeVal);
			Assert.assertEquals(MethodTypeVal.toUpperCase(), MethodType.toUpperCase());
			
			//method Type - Courier
			if(MethodType .equals(MethodReferType))
			{
				//Input Reference Comments
				funclib.DelayTime();		
				Solicitor.InputReference(Reference);
			}
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Settlement Details
			Solicitor.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
									
			//Navigate to Mortage Loan Disbursement Breakups
			Solicitor.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
											
			//Navigate to Mortage Loan Funding Schedule
			Solicitor.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
													
			//Navigate to Applicant Serviceability
			Solicitor.NextPage();			
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to CheckList
			Solicitor.NextPage();
		
		}
	}	
}
