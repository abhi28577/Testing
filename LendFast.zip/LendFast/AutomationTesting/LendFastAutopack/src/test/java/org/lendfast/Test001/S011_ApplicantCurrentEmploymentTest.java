package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantCurrentEmployment;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S011_ApplicantCurrentEmploymentTest extends ParentPage 
{
	ApplicantCurrentEmployment applicantcurrentemployment;
	CommonFuncLib funclib;
	String SheetName = "personal_employment";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Employment
		applicantcurrentemployment = new ApplicantCurrentEmployment();
		funclib=new CommonFuncLib();
	}
	
		
	@DataProvider
	public Object[][] EmpStatusType()
	{
		//Extracting Employment Status from Excel Sheet
		Object EmpStatusType[][] = TestDataUtil.getTestData(SheetName);
		return EmpStatusType;
	}

	@Test (dataProvider = "EmpStatusType")
	public void Validate_ApplicantEmpStatusType(String TestCaseId, String Party,String EmpStat, String BusinessEntity, String IncomePercentage,String BusinessName,String ABNVal,String PositionType,String EmpAddress,String IndustryYears,String IndustryMonths,String AccountantName,String AccountPhone,String ReleaseNPBS,String SalaryVal,String GrossNet,String FrequencyType,String SalaryVal1,String GrossNet1,String FrequencyType1,String SalaryVal2,String GrossNet2,String FrequencyType2) throws InterruptedException
	{		
		String TestDataValue = "TC001_01";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=applicantcurrentemployment.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Current Employment Details for Individual");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Thread.sleep(1000);
			// Select Employment Status
			String EmpStatusTypeVal = applicantcurrentemployment.SelEmpStatusType(EmpStat);
			System.out.println("Applicant Employment Status Type:" + EmpStatusTypeVal);
			Assert.assertEquals(EmpStatusTypeVal, EmpStat);
			
			Thread.sleep(1000);
			// Select Business Entity
			String BusinessTypeVal = applicantcurrentemployment.SelBusinessType(BusinessEntity);
			System.out.println("Applicant Business Entity Type:" + BusinessTypeVal);
			Assert.assertEquals(BusinessTypeVal, BusinessEntity);
			
			funclib.DelayTime();
			// Input Income Percentage
			applicantcurrentemployment.InputIncomePercentage(IncomePercentage);
			
			funclib.DelayTime();
			// Input Business Name
			applicantcurrentemployment.InputBusinessName(BusinessName);
			
			funclib.DelayTime();
			// Input ABN
			applicantcurrentemployment.InputABNValue(ABNVal);
			
			Thread.sleep(1000);
			// Input Position
			applicantcurrentemployment.InputPositionValue(PositionType);
			
			Thread.sleep(1000);
			// Input Employer Address
			applicantcurrentemployment.InputEmpAddress(EmpAddress);
			
			funclib.DelayTime();
			// Input Industry in Years
			applicantcurrentemployment.InputIndustryYears(IndustryYears);
			
			funclib.DelayTime();
			// Input Industry in Months
			applicantcurrentemployment.InputIndustryMonths(IndustryMonths);
			
			Thread.sleep(1000);
			// Select Release Info to NPBS (Yes or No)
			String ReleaseNPBSVal = applicantcurrentemployment.SelReleaseNPBS(ReleaseNPBS);		
			System.out.println("Applicant Release Info to NPBS:" + ReleaseNPBSVal);
			Assert.assertEquals(ReleaseNPBSVal.toUpperCase(), ReleaseNPBS.toUpperCase());
			
			funclib.DelayTime();
			// Input Salary/Drawings
			applicantcurrentemployment.InputSalaryIncome(SalaryVal);
			
			funclib.DelayTime();
			// Select Gross/Net
			String GrossVal = applicantcurrentemployment.SelGrossNetType(GrossNet);
			System.out.println("Gross/Net Type:" + GrossVal);
			Assert.assertEquals(GrossVal, GrossNet);
			
			funclib.DelayTime();
			// Select Frequency Type
			String FrequencyVal = applicantcurrentemployment.SelFrequencyType(FrequencyType);
			System.out.println("Frequency:" + FrequencyVal);
			Assert.assertEquals(FrequencyVal, FrequencyType);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			applicantcurrentemployment.NextPage();
		}
	}
}
