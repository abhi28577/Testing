package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.solicitor.SettlementDetails;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S074_SettlementDetailsTest extends ParentPage 
{
	SettlementDetails settlementdetails;
	CommonFuncLib funclib;
	String SheetName = "solicitors";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Settlement Details
		settlementdetails = new SettlementDetails();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] SettlementDetails()
	{
		//Extracting Contract Details from Excel Sheet
		Object SettlementType[][] = TestDataUtil.getTestData(SheetName);
		return SettlementType;
	}
	
	@Test (dataProvider = "SettlementDetails")
	public void Validate_Settlement1SettlementDetails(String TestCaseId,String ApprovalDate,String SolicitorType, String SolicitorName, String LoanApprovalType, String MailType, String MethodType, String Reference,String SettlementStatus, String SettlementDate, String Time, String Place, String Type) throws InterruptedException
	{	
		String TestId="TC001";
		String Heading = "Settlement Details";
		
		funclib.DelayTime();
		String SectionText=settlementdetails.CaptureHeadSection();
		
		if(TestId .equals(TestCaseId))
		{
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Settlement Details");
		}
		
		while(TestId .equals(TestCaseId))
		{		
			if(TestId .equals(TestCaseId))
			{
				//Select Settlement Status
				String SettlementStatusResult = settlementdetails.SettlementStat(SettlementStatus);
				System.out.println("Settlement Status Result:" + SettlementStatusResult);
				funclib.DelayTime();
			
				//Expected Settlement Date
				settlementdetails.InputSettlementDate(SettlementDate);
				System.out.println("Expected Settlement Date:" + SettlementDate);
				funclib.DelayTime();
			
				//Settlement Time
				settlementdetails.InputSettlementTime(Time);
				System.out.println("Expected Settlement Time:" + Time);
				funclib.DelayTime();
			
				//Settlement Place
				settlementdetails.InputSettlementPlace(Place);
				System.out.println("Expected Settlement Place:" + Place);
				funclib.DelayTime();
			
				//Lender Representation Type
				String LenderTypeResult = settlementdetails.SelLenderType(Type);
				System.out.println("Lender Type:" + LenderTypeResult);
				Thread.sleep(5000);
			
				//Navigate to Next Page (Mortgage Loan Disbursement Break-Ups)
			
				//Capture Screenshot			
				settlementdetails.NextPage();
				Thread.sleep(3000);
				
				SectionText=settlementdetails.CaptureHeadSection();
				if(!SectionText .equals(Heading))
				{					
					break;
				}
			}	
		}
	}	
}
