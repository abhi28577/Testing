package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_PropertyPurpose;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S026_Purpose_PropertyPurposeTest extends ParentPage 
{
	Purpose_PropertyPurpose PropertyPurpose;
	CommonFuncLib funclib; 
	String SheetName = "purpose_property";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		PropertyPurpose = new Purpose_PropertyPurpose();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] PropertyPurpose()
	{
		//Extracting Contract Details from Excel Sheet
		Object PropertyContract[][] = TestDataUtil.getTestData(SheetName);
		return PropertyContract;
	}
	
	@Test (dataProvider = "PropertyPurpose")
	public void Validate_PropertyPurpose(String TestCaseId,String PurchaseDescription, String PropertyType,String PropertyZone, String PurchasePrice, String PropertyUsage, String PrincipalResidence, String FirstPrincipal, String MortgageType) throws InterruptedException
	{
		String TestDataValue = "TC001";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=PropertyPurpose.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Purchase Property Purpose");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			
			//Select Purchase Description
			funclib.DelayTime();
			String PurchaseDescVal = PropertyPurpose.SelPurchaseDesc(PurchaseDescription);		
			System.out.println("Property Purchase Description:" + PurchaseDescVal);
			Assert.assertEquals(PurchaseDescVal.toUpperCase(), PurchaseDescription.toUpperCase());
			
			//Select Property Type
			funclib.DelayTime();
			String PropertyTypeVal = PropertyPurpose.SelPropertyType(PropertyType);		
			System.out.println("Property Type:" + PropertyTypeVal);
			Assert.assertEquals(PropertyTypeVal.toUpperCase(), PropertyType.toUpperCase());
			
			//Input Purchase Price
			funclib.DelayTime();
			PropertyPurpose.InputPurchasePrice(PurchasePrice);
			
			//Select Property Usage
			funclib.DelayTime();
			String PropertyUsageVal = PropertyPurpose.SelPropertyUsage(PropertyUsage);		
			System.out.println("Property Usage:" + PropertyUsageVal);
			Assert.assertEquals(PropertyUsageVal.toUpperCase(), PropertyUsage.toUpperCase());
			
			//Select Principal Residence
			funclib.DelayTime();
			String PrincipalResidenceVal = PropertyPurpose.SelPrincipalResidence(PrincipalResidence);		
			System.out.println("Principal Residence:" + PrincipalResidenceVal);
			Assert.assertEquals(PrincipalResidenceVal.toUpperCase(), PrincipalResidence.toUpperCase());
			
			//Select First Principal Residence
			funclib.DelayTime();
			String FirstPrincipalResidenceVal = PropertyPurpose.SelFirstPrincipalResidence(FirstPrincipal);		
			System.out.println("First Principal Residence:" + FirstPrincipalResidenceVal);
			Assert.assertEquals(FirstPrincipalResidenceVal.toUpperCase(), FirstPrincipal.toUpperCase());
			
			//Select Mortgage Type
			funclib.DelayTime();
			String MortgageTypeVal = PropertyPurpose.SelMortgageType(MortgageType);		
			System.out.println("Mortgage Type:" + MortgageTypeVal);
			Assert.assertEquals(MortgageTypeVal.toUpperCase(), MortgageType.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
					
			//Navigate to Next Page
			PropertyPurpose.NextPage();	
		}
	}	
}
