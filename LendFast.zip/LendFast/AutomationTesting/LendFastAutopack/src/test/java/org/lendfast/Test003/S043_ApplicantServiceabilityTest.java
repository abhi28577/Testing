package org.lendfast.Test003;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.serviceability.ApplicantServiceability;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S043_ApplicantServiceabilityTest extends ParentPage
{
	ApplicantServiceability applicantserviceability;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Serviceability
		applicantserviceability = new ApplicantServiceability();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_Settlement1ApplicantServiceability() throws InterruptedException
	{
		funclib.DelayTime();
		String SectionText=applicantserviceability.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Applicant Serviceability");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Navigate to Next Page
		applicantserviceability.NextPage();
	}
	
}
