package org.lendfast.Test003;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantLoanParty;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S005_ApplicantLoanPartyTest extends ParentPage 
{
	ApplicantLoanParty applicantloanparty;
	CommonFuncLib funclib;
	

	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Loan Party
		applicantloanparty=new ApplicantLoanParty();
		funclib=new CommonFuncLib();
	}
	
	//Validating Heading Section
	@Test
	public void Validate_HeadingSection()
	{		
		try 
		{
			funclib.DelayTime();
			String SectionText=applicantloanparty.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Loan Parties");
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Modify Applicant
			funclib.DelayTime();
			applicantloanparty.ModifyApplicantClick();
			
			//Click on Next Page
			funclib.DelayTime();
			applicantloanparty.NextClick();		
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}				
	}	

}
