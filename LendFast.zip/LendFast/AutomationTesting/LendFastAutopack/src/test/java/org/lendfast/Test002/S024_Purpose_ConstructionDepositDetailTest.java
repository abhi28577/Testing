package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_ConstructionDepositDetail;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S024_Purpose_ConstructionDepositDetailTest extends ParentPage
{
	Purpose_ConstructionDepositDetail ConstructionDeposit;
	CommonFuncLib funclib; 
	String SheetName = "purpose_constructiondeposit";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Purpose Construction
		ConstructionDeposit = new Purpose_ConstructionDepositDetail();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] ConstructionDeposit()
	{
		//Extracting Constructon Deposit Details from Excel Sheet
		Object ConstructionDeposit[][] = TestDataUtil.getTestData(SheetName);
		return ConstructionDeposit;
	}
	
	@Test (dataProvider = "ConstructionDeposit")
	public void Validate_ConstructionDepositDetails(String TestCaseId,String SourceDeposit, String DepositStatus, String DepositAmount) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=ConstructionDeposit.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Construction/Major Renovation - Deposit Details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Source of Deposit
			funclib.DelayTime();
			String SourceDepositVal = ConstructionDeposit.SelSourceDeposit(SourceDeposit);		
			System.out.println("Soure Deposit:" + SourceDepositVal);
			Assert.assertEquals(SourceDepositVal.toUpperCase(), SourceDeposit.toUpperCase());
			
			//Select Deposit Status
			funclib.DelayTime();
			String DepositStatusVal = ConstructionDeposit.SelDepositStatus(DepositStatus);		
			System.out.println("Deposit Status:" + DepositStatusVal);
			Assert.assertEquals(DepositStatusVal.toUpperCase(), DepositStatus.toUpperCase());
			
			//Input Deposit Amount
			funclib.DelayTime();
			ConstructionDeposit.InputDepositAmount(DepositAmount);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			ConstructionDeposit.NextPage();
			
			funclib.DelayTime();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
									
			//Navigate to Next Page
			ConstructionDeposit.NextPage();
		}		
	}	

}
