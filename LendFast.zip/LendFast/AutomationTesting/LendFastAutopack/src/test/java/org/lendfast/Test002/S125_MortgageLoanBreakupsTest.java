package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.schedule.MortgageLoanBreakups;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S125_MortgageLoanBreakupsTest extends ParentPage 
{
	MortgageLoanBreakups mortgageloanbreakups;
	CommonFuncLib funclib;
	String SheetName = "schedule";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Mortgage Loan Disbursement Breakups
		mortgageloanbreakups = new MortgageLoanBreakups();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] DisbursementMethod()
	{
		//Extracting Contract Details from Excel Sheet
		Object ItemMethod[][] = TestDataUtil.getTestData(SheetName);
		return ItemMethod;
	}
	
	@Test (dataProvider = "DisbursementMethod")
	public void Validate_Settlement5MortgageLoanDisbursementBreakups(String TestCaseId,String PayableType, String PayableTo,String ProgressPay, String FirstDraw, String FinalDraw, String CustAccountNumber, String CustomerAmount) throws InterruptedException
	{	
		String TestId="TC002";
		
		String ConstructionFirstDraw = "null";
		
		if(TestCaseId .equals(TestId))
		{
			funclib.DelayTime();
			String SectionText=mortgageloanbreakups.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Mortgage Loan Disbursement Breakups");
		
			funclib.DelayTime();
			
			//Select Progress Payment
			//String ProgressPaymentVal = mortgageloanbreakups.ProgressPaymentTypeMethod(ProgressPay);		
			//System.out.println("Proceed under Progress Payment:" + ProgressPaymentVal);
			//Assert.assertEquals(ProgressPaymentVal.toUpperCase(), ProgressPay.toUpperCase());		
			

// ************************ Construction Builder ************************** //
			
			if(ConstructionFirstDraw.equals(FirstDraw))
			{
				//Click on Modify against Vendor
				mortgageloanbreakups.ModifyConstructionBuilderClick();
			
				funclib.DelayTime();
		
				//First Construction Draw
				//mortgageloanbreakups.SelFirstConstructDraw(FirstDraw);
				
		
				//Final Construction Draw
				mortgageloanbreakups.SelFinalConstructDraw(FinalDraw);
		
				funclib.DelayTime();		
						
				//Navigate to Next Page (Disbursement Item Method)
				mortgageloanbreakups.NextPage();
			
				//Disbursement Item Method - Payable Type
				mortgageloanbreakups.DisbursementPayableTypeMethod(PayableType);
		
				funclib.DelayTime();
		
				//Disbursement Item Method - Payable To
				mortgageloanbreakups.DisbursementPayableToMethod(PayableTo);
				funclib.DelayTime();
		
				//Capture Screenshot
				funclib.CaptureScreenShot();
					
				//Navigate to Next Page (Mortgage Loan Disbursement Breakups Page)
				mortgageloanbreakups.NextPage();
				
				//Authorise Purchase Builder
				mortgageloanbreakups.AuthoriseConstructionBuilderClick();
				funclib.DelayTime();
				
				funclib.CaptureScreenShot();
				
				//Navigate to Next Page (Mortgage Loan Funding Schedule)
				mortgageloanbreakups.NextPage();				
			}			
		}
	}	
}
