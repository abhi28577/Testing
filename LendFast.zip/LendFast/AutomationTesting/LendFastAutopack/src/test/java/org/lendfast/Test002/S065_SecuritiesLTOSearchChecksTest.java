package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.securities.SecuritiesLTOSearchChecks;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S065_SecuritiesLTOSearchChecksTest extends ParentPage
{
	SecuritiesLTOSearchChecks SecuritySearchChecks;
	CommonFuncLib funclib; 
	String SheetName = "SettlementSecurities";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Securities Home 
		SecuritySearchChecks = new SecuritiesLTOSearchChecks();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] SecuritiesTitle()
	{
		//Extracting Contract Details from Excel Sheet
		Object SecurityTitle[][] = TestDataUtil.getTestData(SheetName);
		return SecurityTitle;
	}
	
	@Test (dataProvider = "SecuritiesTitle")
	public void Validate_Settlement1SecuritiesTitleSearch(String TestCaseId, String ValidResult, String TitleType, String TitleVendorNameMatch, String PropertyContractMatch, String LandTransfer, String VendorOwnerLandTransferMatch, String EstateInterest, String ProceedAcceptable, String PhysicalTitle, String AncillaryTitle, String Encumbrances, String UnRegisteredDeal, String MortgageRank) throws InterruptedException
	{
		String TestId="TC002";
		
		//Validating Heading Section
		try 
		{
			funclib.DelayTime();
			String SectionText=SecuritySearchChecks.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "LTO Search Checks Details");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		if(TestId .equals(TestCaseId))
		{		
			//Select Encumbrances Type
			String EncumbranceTypeResult = SecuritySearchChecks.SelEncumbranceType(Encumbrances);
			System.out.println("Encumbrances Type Result:" + EncumbranceTypeResult);
			funclib.DelayTime();
			
			//Select UnRegistered Dealings Type
			String UnRegisteredTypeResult = SecuritySearchChecks.SelUnRegisteredType(UnRegisteredDeal);
			System.out.println("UnRegistered Dealings Result:" + UnRegisteredTypeResult);
			funclib.DelayTime();
			
			//Select Mortgage Rank Type
			String MortgageRankTypeResult = SecuritySearchChecks.SelMortgageRankType(MortgageRank);
			System.out.println("Mortgage Rank Type Result:" + MortgageRankTypeResult);
			funclib.DelayTime();
			
			//Navigate to Next Page
			SecuritySearchChecks.NextPage();
			funclib.DelayTime();
			
			//Navigate to Next Page
			SecuritySearchChecks.NextPage();
			funclib.DelayTime();
			
			//Navigate to Next Page
			SecuritySearchChecks.NextPage();
			funclib.DelayTime();
		}
	}
}
