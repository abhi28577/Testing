package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.schedule.MortgageLoanBreakups;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S057_MortgageLoanBreakupsTest extends ParentPage 
{
	MortgageLoanBreakups mortgageloanbreakups;
	CommonFuncLib funclib;	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Mortgage Loan Disbursement Breakups
		mortgageloanbreakups = new MortgageLoanBreakups();
		funclib=new CommonFuncLib();
	}	
	
	@Test
	public void Validate_CreditMortgageLoanDisbursementBreakups() throws InterruptedException
	{	
		funclib.DelayTime();
		String SectionText=mortgageloanbreakups.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Mortgage Loan Disbursement Breakups");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
			
		//Navigate to Next Page
		mortgageloanbreakups.NextPage();	
	}	
}
