package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.productselection.ProductHomePage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S039_ProductHomePageTest extends ParentPage
{
	ProductHomePage ProductHome;
	CommonFuncLib funclib;
	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose
		ProductHome = new ProductHomePage();
		funclib=new CommonFuncLib();
	}	
	
	
	@Test
	public void Validate_ProductHomePage() throws InterruptedException
	{
		//Validating Heading Section
		try 
		{
			funclib.DelayTime();
			String SectionText=ProductHome.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Products Summary");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Click on Add Product Link/Button
		ProductHome.AddProductPage();
	}
}
