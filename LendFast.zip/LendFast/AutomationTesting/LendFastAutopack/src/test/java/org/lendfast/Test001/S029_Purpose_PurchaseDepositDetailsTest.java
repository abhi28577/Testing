package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_PurchaseDepositDetails;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S029_Purpose_PurchaseDepositDetailsTest extends ParentPage 
{
	Purpose_PurchaseDepositDetails PurchaseDeposit;
	CommonFuncLib funclib; 
	String SheetName = "purpose_deposit";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Purpose Contract
		PurchaseDeposit = new Purpose_PurchaseDepositDetails();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] PurchaseDeposit()
	{
		//Extracting Contract Details from Excel Sheet
		Object PropertyContract[][] = TestDataUtil.getTestData(SheetName);
		return PropertyContract;
	}
	
	@Test (dataProvider = "PurchaseDeposit")
	public void Validate_PurchaseDepositDetails(String TestCaseId,String SourceDeposit, String DepositStatus, String DepositAmount) throws InterruptedException
	{
		String TestDataValue = "TC001";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=PurchaseDeposit.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Purchase Real Estate - Deposit Details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Source of Deposit
			funclib.DelayTime();
			String SourceDepositVal = PurchaseDeposit.SelSourceDeposit(SourceDeposit);		
			System.out.println("Soure Deposit:" + SourceDepositVal);
			Assert.assertEquals(SourceDepositVal.toUpperCase(), SourceDeposit.toUpperCase());
			
			//Select Deposit Status
			funclib.DelayTime();
			String DepositStatusVal = PurchaseDeposit.SelDepositStatus(DepositStatus);		
			System.out.println("Deposit Status:" + DepositStatusVal);
			Assert.assertEquals(DepositStatusVal.toUpperCase(), DepositStatus.toUpperCase());
			
			//Input Deposit Amount
			funclib.DelayTime();
			PurchaseDeposit.InputDepositAmount(DepositAmount);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			PurchaseDeposit.NextPage();
			
			funclib.DelayTime();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
									
			//Navigate to Next Page
			PurchaseDeposit.NextPage();
		}		
	}	
}
