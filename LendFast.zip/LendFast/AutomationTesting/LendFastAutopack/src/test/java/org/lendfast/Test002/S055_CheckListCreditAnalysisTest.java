package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.checklist.ChecklistCreditAnalysis;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S055_CheckListCreditAnalysisTest extends ParentPage 
{
	ChecklistCreditAnalysis Chklist;
	CommonFuncLib funclib; 
	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  CheckList
		Chklist = new ChecklistCreditAnalysis();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_CheckListCreditAnalysisDocuments() throws InterruptedException
	{	
		//Validating Heading Section
		try 
		{
			funclib.DelayTime();
			String SectionText=Chklist.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Check List");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Select Non-Mandatory List
		Chklist.NonMandatory();
		
		
		//Submission Position
		Chklist.SubmissionPos();
		
		
		//Navigate to Next Page
		Chklist.NextPage();
		
		
	}
}
