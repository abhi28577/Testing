package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.schedule.MortgageLoanBreakups;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S106_MortgageLoanBreakupsTest extends ParentPage 
{
	MortgageLoanBreakups mortgageloanbreakups;
	CommonFuncLib funclib;
	String SheetName = "schedule";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Mortgage Loan Disbursement Breakups
		mortgageloanbreakups = new MortgageLoanBreakups();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] DisbursementMethod()
	{
		//Extracting Contract Details from Excel Sheet
		Object ItemMethod[][] = TestDataUtil.getTestData(SheetName);
		return ItemMethod;
	}
	
	@Test (dataProvider = "DisbursementMethod")
	public void Validate_Settlement3MortgageLoanDisbursementBreakups(String TestCaseId,String PayableType, String PayableTo,String ProgressPay, String FirstDraw, String FinalDraw, String CustAccountNumber, String CustomerAmount) throws InterruptedException
	{	
		String TestId="TC001";
		
		if(TestCaseId .equals(TestId))
		{
			funclib.DelayTime();
			String SectionText=mortgageloanbreakups.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Mortgage Loan Disbursement Breakups");
		
			funclib.DelayTime();
		
			//Disbursement Item Method - Maximum
			mortgageloanbreakups.DisbursementMaximumItemMethod();
		
			funclib.DelayTime();
		
			//Disbursement Item Method - Payable Type
			mortgageloanbreakups.DisbursementPayableTypeMethod(PayableType);
		
			funclib.DelayTime();
		
			//Disbursement Item Method - Payable To
			mortgageloanbreakups.DisbursementPayableToMethod(PayableTo);		
		
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page (Mortgage Loan Funding Schedule)
			mortgageloanbreakups.NextPage();	
		
			//Capture Screenshot
			funclib.CaptureScreenShot();
					
			//Navigate to Next Page (Mortgage Loan Disbursement Breakups Page)
			mortgageloanbreakups.NextPage();
		}
	}	
}
