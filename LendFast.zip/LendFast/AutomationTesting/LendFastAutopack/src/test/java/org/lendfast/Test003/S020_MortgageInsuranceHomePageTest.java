package org.lendfast.Test003;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.mortgageinsurance.MortgageInsuranceHomePage;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S020_MortgageInsuranceHomePageTest extends ParentPage 
{
	MortgageInsuranceHomePage MortgageInsurance;
	CommonFuncLib funclib; 
	String SheetName = "mortgageinsurance";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose
		MortgageInsurance = new MortgageInsuranceHomePage();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] MortgageInsurance()
	{
		//Extracting Contract Details from Excel Sheet
		Object Mortgage[][] = TestDataUtil.getTestData(SheetName);
		return Mortgage;
	}
	
	@Test (dataProvider = "MortgageInsurance")
	public void Validate_MortgageInsurance(String TestCaseId, String MortInsurance, String Insurer) throws InterruptedException
	{	
		String TestDataValue = "TC003";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=MortgageInsurance.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Mortgage Insurance");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Mortgage Insurance
			funclib.DelayTime();
			String MortgageInsuranceVal = MortgageInsurance.SelMortgageInsurance(MortInsurance);		
			System.out.println("Mortgage Insurance Needed:" + MortgageInsuranceVal);
			Assert.assertEquals(MortgageInsuranceVal.toUpperCase(), MortInsurance.toUpperCase());
			
			//Select Mortgage Insurer
			funclib.DelayTime();
			String NullType="null";
			if(!Insurer .equals(NullType))
			{
				String MortgageInsurerVal = MortgageInsurance.SelMortgageInsurer(Insurer);		
				System.out.println("Mortgage Insurer:" + MortgageInsurerVal);
				Assert.assertEquals(MortgageInsurerVal.toUpperCase(), Insurer.toUpperCase());
			}
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
					
			//Navigate to LPI Policies
			MortgageInsurance.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Agent/Solicitor Details
			MortgageInsurance.NextPage();
		}
	}	
}
