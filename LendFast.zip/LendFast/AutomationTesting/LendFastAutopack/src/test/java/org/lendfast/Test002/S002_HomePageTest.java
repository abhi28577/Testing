package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.applicationtype.ApplicationType;
import org.lendfast.pages.login.HomePage;
import org.lendfast.pages.login.LoginPage;
import org.lendfast.utils.TestCredentialsUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S002_HomePageTest extends ParentPage 
{
	LoginPage loginpage;
	HomePage homepage;	
	CommonFuncLib funclib;
	ApplicationType applicationtype;
	String SheetName = "testcredentials";
	
	public S002_HomePageTest()
	{
		super();
	}
			
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Home Page
		homepage = new HomePage();
		funclib=new CommonFuncLib();
	}	
	
	@DataProvider
	public Object[][] UserIdCredentials()
	{
		//Extracting User Credentials from Excel Sheet
		Object logincred[][] = TestCredentialsUtil.getTestData(SheetName);
		return logincred;
	}
	
	@Test (dataProvider = "UserIdCredentials")
	public void Validate_UserIdCredentials(String User, String Pwd) throws InterruptedException
	{
		String Username= "abhishek.paspuleti";
		
		if(Username .equals(User))
		{
			try 
			{
				funclib.DelayTime();
				String UserName = homepage.UserIdCredentials(User,Pwd);
				String UserId = User;
				System.out.println("Origination Test Case 2 User Id: " + UserName);
				Assert.assertEquals(UserName, UserId);
			}		
		catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		}	
	}
	
	@Test
	public void CreateApplicationType()
	{
		try
		{
			funclib.CaptureScreenShot();
			funclib.DelayTime();
			homepage.CreateApplication();
			
		}
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
