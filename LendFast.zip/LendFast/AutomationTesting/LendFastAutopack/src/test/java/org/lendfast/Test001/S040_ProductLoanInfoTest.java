package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.productselection.ProductLoanInfo;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S040_ProductLoanInfoTest extends ParentPage
{
	ProductLoanInfo ProductLoan;
	CommonFuncLib funclib; 
	String SheetName = "productselection";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose
		ProductLoan = new ProductLoanInfo();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] ProductLoan()
	{
		//Extracting Contract Details from Excel Sheet
		Object Asset[][] = TestDataUtil.getTestData(SheetName);
		return Asset;
	}
	
	@Test (dataProvider = "ProductLoan")
	public void Validate_ProductLoanInfo(String TestCaseId,String Duration, String TermLoanY, String TermLoanM, String InterestType,  String Repayment, String InvestmentType, String Predominant, String AmountProduct, String AmountAllocate, String ProductType, String DiscretionaryMargin, String DiscretionarySubsequent, String PositiveMargin, String PackageValue, String CampaignValue, String DiscretionaryReason, String OffsetFacility, String RepayFreq, String FirstRepayment, String RepayMethod) throws InterruptedException
	{
		String NullType="null";
		String DurationTypeTerm = "Term";
		String DurationTypeRevolve = "Revolving";
		String ProductAmount= "Specified amount";
		//String CheckDiscretionReason = "Meet Competitor Pricing (7)";
		
		String TestDataValue = "TC001";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Select Duration Type
			if((!Duration.toLowerCase() .equals(NullType.toLowerCase())))
			{	
				
				//Validating Heading Section
				try 
				{
					funclib.DelayTime();
					String SectionText=ProductLoan.CaptureHeadSection();		
					System.out.println("Heading Section:" + SectionText);
					Assert.assertEquals(SectionText, "Loan Information");
				} 
				catch (InterruptedException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}			
				
				
				//Durtaion Type - Term
				if(Duration.toLowerCase() .equals(DurationTypeTerm.toLowerCase()))
				{
					//Select Duration Type
					funclib.DelayTime();
					String DurationVal = ProductLoan.SelDuration(Duration);		
					System.out.println("Duration Type:" + DurationVal);
					Assert.assertEquals(DurationVal.toUpperCase(), Duration.toUpperCase());
				
					//Input Loan Term in Years
					funclib.DelayTime();
					ProductLoan.InputLoanTermYears(TermLoanY);
				
					//Input Loan Term in Months
					funclib.DelayTime();
					ProductLoan.InputLoanTermMonths(TermLoanM);
				
					//Select Interest Type
					funclib.DelayTime();
					String InterestVal = ProductLoan.SelInterestType(InterestType);	
					System.out.println("Interest Type:" + InterestVal);
					Assert.assertEquals(InterestVal.toUpperCase(), InterestType.toUpperCase());
				
					//Select Repayment Type
					funclib.DelayTime();
					String RepaymentVal = ProductLoan.SelRepaymentMethod(Repayment);	
					System.out.println("Interest Type:" + RepaymentVal);
					Assert.assertEquals(RepaymentVal.toUpperCase(), Repayment.toUpperCase());
				
					//Select Investment Purpose
					funclib.DelayTime();
					String InvestmentVal = ProductLoan.SelInvestmentPurpose(InvestmentType);	
					System.out.println("Interest Type:" + InvestmentVal);
					Assert.assertEquals(InvestmentVal.toUpperCase(), InvestmentType.toUpperCase());
				
					//Select Predominant Purpose
					funclib.DelayTime();
					String PredominantVal = ProductLoan.SelPredominant(Predominant);		
					System.out.println("Predominant Purpose:" + PredominantVal);
					Assert.assertEquals(PredominantVal.toUpperCase(), Predominant.toUpperCase());
				
					//Select Product Amount Type
					funclib.DelayTime();
					String ProductAmountVal = ProductLoan.SelProductAmount(AmountProduct);		
					System.out.println("Product Amount Type:" + ProductAmountVal);
					Assert.assertEquals(ProductAmountVal.toUpperCase(), AmountProduct.toUpperCase());
					
					if(ProductAmountVal .equals(ProductAmount))
					{
						//Input Specified Amount Allocation
						funclib.DelayTime();
						ProductLoan.InputSpecifiedAmount(AmountAllocate);
					}				
				}
				
				//Duration Type - Revolving
				if(Duration.toLowerCase() .equals(DurationTypeRevolve.toLowerCase()))
				{
					//Select Duration Type
					funclib.DelayTime();
					String DurationVal = ProductLoan.SelDuration(Duration);		
					System.out.println("Duration Type:" + DurationVal);
					Assert.assertEquals(DurationVal.toUpperCase(), Duration.toUpperCase());
					
					//Select Investment Purpose
					funclib.DelayTime();
					String InvestmentVal = ProductLoan.SelInvestmentPurpose(InvestmentType);	
					System.out.println("Interest Type:" + InvestmentVal);
					Assert.assertEquals(InvestmentVal.toUpperCase(), InvestmentType.toUpperCase());
				
					//Select Predominant Purpose
					funclib.DelayTime();
					String PredominantVal = ProductLoan.SelPredominant(Predominant);		
					System.out.println("Predominant Purpose:" + PredominantVal);
					Assert.assertEquals(PredominantVal.toUpperCase(), Predominant.toUpperCase());
					
					//Input Specified Amount Allocation
					funclib.DelayTime();
					ProductLoan.InputSpecifiedAmount(AmountAllocate);				
				}
				
				//Show Products
				funclib.DelayTime();
				ProductLoan.ShowProducts();
				funclib.DelayTime();
				
				//Select Product Type
				funclib.DelayTime();		
				System.out.println("Product Type:" + ProductType);
				String ProductTypeVal = ProductLoan.SelProductType(ProductType);			
				Assert.assertEquals(ProductTypeVal.toUpperCase(), ProductType.toUpperCase());
				
				//Select Package
				funclib.DelayTime();
				String PackageVal = ProductLoan.SelPackageType(PackageValue);		
				System.out.println("Package:" + PackageVal);
				Assert.assertEquals(PackageVal.toUpperCase(), PackageValue.toUpperCase());
				
				//Select Campaign
				funclib.DelayTime();
				String CampaignVal = ProductLoan.SelCampaignType(CampaignValue);
				System.out.println("Campaign:" + CampaignVal);
				Assert.assertEquals(CampaignVal.toUpperCase(), CampaignValue.toUpperCase());
				
				//Input Discretionary Margin
				funclib.DelayTime();
				if(!DiscretionaryMargin .equals(NullType))
					ProductLoan.InputDiscretionaryMargin(DiscretionaryMargin);
				
				//Input Discretionary Subsequent
				funclib.DelayTime();
				if((Duration.toLowerCase() .equals(DurationTypeTerm.toLowerCase())) && !DiscretionarySubsequent .equals(NullType))
				{			
					ProductLoan.InputDiscretionarySubsequent(DiscretionarySubsequent);
				}
				
				//Select Campaign
				funclib.DelayTime();
				ProductLoan.SelCampaignType(CampaignValue);								
				
				//Select Discretionary Reason
				funclib.DelayTime();
				if(!DiscretionaryReason .equals(NullType))
				{						
					driver.get(driver.getCurrentUrl());
					String DiscretionaryReasonVal = ProductLoan.SelDiscretionaryReason(DiscretionaryReason);
					System.out.println("Discretionary Reason:" + DiscretionaryReasonVal);					
					Assert.assertEquals(DiscretionaryReasonVal.toUpperCase(), DiscretionaryReason.toUpperCase());				
				}	
				
				//Select Offset Facility
				funclib.DelayTime();
				if(!OffsetFacility .equals(NullType))
				{
					String OffsetFacilityVal = ProductLoan.SelOffsetFacility(OffsetFacility);	
					System.out.println("Offset Facility:" + OffsetFacilityVal);
					Assert.assertEquals(OffsetFacilityVal.toUpperCase(), OffsetFacility.toUpperCase());
				}	
				
				//Capture Screenshot
				funclib.CaptureScreenShot();
				
				//Click Next Page
				funclib.DelayTime();
				ProductLoan.NextPage();
				funclib.DelayTime();
				
				//Durtaion Type - Revolving
				if(Duration.toLowerCase() .equals(DurationTypeRevolve.toLowerCase()))
				{
					//Click on Add Product Link/Button
					funclib.DelayTime();
					ProductLoan.AddProductPage();
					funclib.DelayTime();
				}
				
				if(Duration.toLowerCase() .equals(DurationTypeTerm.toLowerCase()))
				{
					//Select Repayment Frequency
					funclib.DelayTime();
					String RepaymentFrequencyVal = ProductLoan.SelRepaymentFrequency(RepayFreq);
					System.out.println("Repayment Frequency:" + RepaymentFrequencyVal);
					Assert.assertEquals(RepaymentFrequencyVal.toUpperCase(), RepayFreq.toUpperCase());
				
					//Select Repayment First Date
					funclib.DelayTime();
					String RepaymentFirstDayVal = ProductLoan.SelFirstRepaymentDate(FirstRepayment);
					System.out.println("First Repayment Date:" + RepaymentFirstDayVal);
					Assert.assertEquals(RepaymentFirstDayVal.toUpperCase(), FirstRepayment.toUpperCase());
				
					//Select Repayment Method
					funclib.DelayTime();
					String RepaymentMethodVal = ProductLoan.SelRepaymentMethodType(RepayMethod);
					System.out.println("Repayment Method:" + RepaymentMethodVal);
					Assert.assertEquals(RepaymentMethodVal.toUpperCase(), RepayMethod.toUpperCase());
				
					//Capture Screenshot
					funclib.CaptureScreenShot();
					
					//Click Next Page
					funclib.DelayTime();
					ProductLoan.NextPage();
					funclib.DelayTime();
					
					//Click on Add Product Link/Button
					funclib.DelayTime();
					ProductLoan.AddProductPage();
					funclib.DelayTime();
				}	
			}
			
			//Select Duration Type = NULL
			if((Duration.toLowerCase() .equals(NullType.toLowerCase())))
			{
				//Back Page
				ProductLoan.BackPage();
				funclib.DelayTime();
				
				//Capture Screenshot
				funclib.CaptureScreenShot();
						
				//Navigate to Commission Page
				ProductLoan.NextPage();
				funclib.DelayTime();
						
				//Capture Screenshot
				funclib.CaptureScreenShot();
								
				//Navigate to Mortgage Insurance
				ProductLoan.NextPage();
				funclib.DelayTime();
			}
		}
	}
}
