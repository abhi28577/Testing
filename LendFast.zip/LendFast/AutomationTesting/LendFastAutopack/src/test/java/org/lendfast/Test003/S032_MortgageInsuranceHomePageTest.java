package org.lendfast.Test003;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.mortgageinsurance.MortgageInsuranceHomePage;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S032_MortgageInsuranceHomePageTest extends ParentPage 
{
	MortgageInsuranceHomePage MortgageInsurance;
	CommonFuncLib funclib; 
	String SheetName = "mortgageinsurance";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose
		MortgageInsurance = new MortgageInsuranceHomePage();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] MortgageInsurance()
	{
		//Extracting Contract Details from Excel Sheet
		Object Mortgage[][] = TestDataUtil.getTestData(SheetName);
		return Mortgage;
	}
	
	@Test (dataProvider = "MortgageInsurance")
	public void Validate_CreditMortgageInsurance(String TestCaseId,String MortInsurance, String Insurer) throws InterruptedException
	{	
		String TestDataValue = "TC003";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=MortgageInsurance.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Mortgage Insurance");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
					
			//Navigate to LPI Policies
			MortgageInsurance.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Agent/Solicitor Details
			MortgageInsurance.NextPage();
		}
	}	
}
