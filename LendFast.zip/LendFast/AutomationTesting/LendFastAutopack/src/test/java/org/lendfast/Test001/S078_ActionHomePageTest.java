package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.action.ActionHomePage;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S078_ActionHomePageTest extends ParentPage
{
	ActionHomePage actionhomepage;	
	CommonFuncLib funclib; 
	String SheetName = "action";	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Action Type 
		actionhomepage = new ActionHomePage();		
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] ActionHome()
	{
		//Extracting Contract Details from Excel Sheet
		Object ActionType[][] = TestDataUtil.getTestData(SheetName);
		return ActionType;
	}
	
	
	@Test (dataProvider = "ActionHome")
	public void Validate_Settlement1ActionType(String TestCaseId,String CreditActionType,String SettlementActionType1, String SettlementActionType2, String SettlementActionType3, String SettlementActionType4, String SettlementActionType5) throws InterruptedException
	{
		String TestDataValue = "TC001";
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		
		if(TestDataValue .equals(TestCaseId))
		{
			funclib.DelayTime();
			//Heading section
			String SectionText=actionhomepage.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Action");			
						
			//Click on Generate Contract Link
			funclib.DelayTime();
			actionhomepage.GenerateContractButton();
			funclib.DelayTime();
			
			//Navigate to Next Page
			funclib.DelayTime();
			actionhomepage.NextPage();
			
			//Select Action Type
			funclib.DelayTime();
			actionhomepage.ActionType(SettlementActionType1);
		
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			funclib.DelayTime();
			actionhomepage.NextPage();				
		}
	}
}
