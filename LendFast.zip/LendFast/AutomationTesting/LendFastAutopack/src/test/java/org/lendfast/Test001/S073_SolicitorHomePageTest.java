package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.solicitor.SolicitorHomePage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S073_SolicitorHomePageTest extends ParentPage 
{
	SolicitorHomePage solicitor;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Solicitors
		solicitor = new SolicitorHomePage();
		funclib=new CommonFuncLib();
	}	
	
	@Test
	public void Validate_Settlement1Solicitor() throws InterruptedException
	{	
		funclib.DelayTime();
		String SectionText=solicitor.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Customer Settlement Agent/Solicitor Details");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();		
			
		//Navigate to Next Page
		solicitor.NextPage();	
	}	
}
