package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_ConstructionPurpose;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S022_Purpose_ConstructionPurposeTest extends ParentPage
{
	Purpose_ConstructionPurpose ConstructPurpose;
	CommonFuncLib funclib; 
	String SheetName = "purpose_constructionpurpose";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Construction Purpose
		ConstructPurpose = new Purpose_ConstructionPurpose();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] ConstructionPurpose()
	{
		//Extracting Construction Purpose Details from Excel Sheet
		Object ConstructionPurpose[][] = TestDataUtil.getTestData(SheetName);
		return ConstructionPurpose;
	}
	
	@Test (dataProvider = "ConstructionPurpose")
	public void Validate_ConstructionPurpose(String TestCaseId,String ConstructionPurpose, String ConstructionDescription, String ConstructionCost, String AdditionalCost) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=ConstructPurpose.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Construction Purpose");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Construction Purpose
			funclib.DelayTime();
			String ConstructionPurposeVal = ConstructPurpose.SelConstructionPurpose(ConstructionPurpose);		
			System.out.println("Construction Purpose:" + ConstructionPurposeVal);
			Assert.assertEquals(ConstructionPurposeVal.toUpperCase(), ConstructionPurpose.toUpperCase());
			
			//Select Construction Description
			funclib.DelayTime();
			String ConstructionDescriptionVal = ConstructPurpose.SelConstructionDescription(ConstructionDescription);		
			System.out.println("Construction Description:" + ConstructionDescriptionVal);
			Assert.assertEquals(ConstructionDescriptionVal.toUpperCase(), ConstructionDescription.toUpperCase());
			
			//Input Construction Cost
			funclib.DelayTime();
			ConstructPurpose.InputConstructionCost(ConstructionCost);
			
			//Select Additional Improvement Costs
			funclib.DelayTime();
			String ConstructionCostVal = ConstructPurpose.SelAdditionalCost(AdditionalCost);		
			System.out.println("Additional Construction Cost:" + ConstructionCostVal);
			Assert.assertEquals(ConstructionCostVal.toUpperCase(), AdditionalCost.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			ConstructPurpose.NextPage();
		}
	}
}
