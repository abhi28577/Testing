package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.schedule.MortgageLoanSchedule;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S126_MortgageLoanScheduleTest extends ParentPage 
{
	MortgageLoanSchedule mortgageloanschedule;
	CommonFuncLib funclib;	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Mortgage Loan Disbursement Breakups
		mortgageloanschedule = new MortgageLoanSchedule();
		funclib=new CommonFuncLib();
	}	
	
	@Test
	public void Validate_Settlement5MortgageLoanSchedule() throws InterruptedException
	{	
		funclib.DelayTime();
		String SectionText=mortgageloanschedule.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Mortgage Loan Funding Schedule");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
			
		//Navigate to Next Page
		mortgageloanschedule.NextPage();	
	}	
}
