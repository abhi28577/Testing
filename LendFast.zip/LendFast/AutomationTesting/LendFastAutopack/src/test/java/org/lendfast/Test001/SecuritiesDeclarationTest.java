package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.securities.SecuritiesRecordValuation;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SecuritiesDeclarationTest extends ParentPage
{
	SecuritiesRecordValuation SecurityDeclare;
	CommonFuncLib funclib; 
	String SheetName = "securities";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		SecurityDeclare = new SecuritiesRecordValuation();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] SecuritiesRecordValuation()
	{
		//Extracting Contract Details from Excel Sheet
		Object Asset[][] = TestDataUtil.getTestData(SheetName);
		return Asset;
	}
	
	@Test (dataProvider = "SecuritiesRecordValuation")
	public void Validate_SecuritiesHome(String TestCaseId,String Counter, String Value, String Assessment, String Declaration) throws InterruptedException
	{
		String TestDataValue = "TC001";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=SecurityDeclare.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Record Accept Valuation Details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Declaration Type
			Thread.sleep(1000);
			String DeclarationVal = SecurityDeclare.SelDeclarationType(Declaration);		
			System.out.println("Declaration Type:" + DeclarationVal);
			Assert.assertEquals(DeclarationVal.toUpperCase(), Declaration.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			SecurityDeclare.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
					
			//Navigate to Next Page
			SecurityDeclare.NextPage();
			
			
			// Loan Package
			//Capture Screenshot
			funclib.CaptureScreenShot();
					
			//Navigate to Next Page
			SecurityDeclare.NextPage();
			
			// List Of Packages
			//Capture Screenshot
			funclib.CaptureScreenShot();
							
			//Navigate to Next Page
			SecurityDeclare.NextPage();
		}
	}

}
