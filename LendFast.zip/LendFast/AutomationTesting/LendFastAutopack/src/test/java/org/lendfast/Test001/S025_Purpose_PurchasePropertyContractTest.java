package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_PurchasePropertyContract;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S025_Purpose_PurchasePropertyContractTest extends ParentPage
{	
	Purpose_PurchasePropertyContract PropertyCont;
	CommonFuncLib funclib; 
	String SheetName = "purpose_contract";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Purpose Contract
		PropertyCont = new Purpose_PurchasePropertyContract();
		funclib = new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] PurchasePropertyContract()
	{
		//Extracting Property Contract Details from Excel Sheet
		Object ContractType[][] = TestDataUtil.getTestData(SheetName);
		return ContractType;
	}

	@Test (dataProvider = "PurchasePropertyContract")
	public void Validate_PurchasePropertyContract(String TestCaseId,String LoanPurposeType, String OtherPurpose, String OtherPayType, String CustAccountNumber, String PayableTo, String AmountRequired,String PropertyApprovalType, String SecurityType,String PropertyFound,String ManualAddress,String AustralianAddress,String PropertyName,String HouseNum,String HouseUnit,String HouseLevel,String HouseStreetName,String HouseStreetType,String HouseStreetSuffix,String HouseSuburb,String HouseState,String HousePostalCode,String PropertyZone,String PropertyContract,String ContractAvailable,String ContractSigned,String SignedDate,String VendorName) throws InterruptedException
	{
		String TestDataValue = "TC001";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=PropertyCont.CaptureHeadSection();
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Purchase Property Contract Details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//Select Approval Type
			funclib.DelayTime();
			String PropertyApprovalVal = PropertyCont.SelApprovalType(PropertyApprovalType);		
			System.out.println("Property Approval Type:" + PropertyApprovalVal);
			Assert.assertEquals(PropertyApprovalVal.toUpperCase(), PropertyApprovalType.toUpperCase());
			
			//Select Property Security
			funclib.DelayTime();
			String PropertySecurityVal = PropertyCont.SelPropertySecurityType(SecurityType);	
			System.out.println("Property Security:" + PropertySecurityVal);
			Assert.assertEquals(PropertySecurityVal.toUpperCase(), SecurityType.toUpperCase());
			
			//Select Property Found
			funclib.DelayTime();
			String PropertyFoundVal = PropertyCont.SelPropertyFoundType(PropertyFound);		
			System.out.println("Property Found:" + PropertyFoundVal);
			Assert.assertEquals(PropertyFoundVal.toUpperCase(), PropertyFound.toUpperCase());
			
			//Manual Property Address
			funclib.DelayTime();
			PropertyCont.InputManualAddress(ManualAddress);	
			
			//Manual Address Details
			funclib.DelayTime();
			PropertyCont.InputManualAddressDetails(AustralianAddress,PropertyName, HouseNum, HouseUnit, HouseLevel,  HouseStreetName, HouseStreetType, HouseStreetSuffix, HouseSuburb, HouseState, HousePostalCode);
			
			//Select Property Zone
			funclib.DelayTime();
			String PropertyZoneVal = PropertyCont.SelPropertyZone(PropertyZone);		
			System.out.println("Property Zone:" + PropertyZoneVal);
			Assert.assertEquals(PropertyZoneVal.toUpperCase(), PropertyZone.toUpperCase());
			
			//Select Contract Sale
			funclib.DelayTime();
			String ContractSaleVal = PropertyCont.SelContractSaleType(PropertyContract);		
			System.out.println("Property Contract Sale:" + ContractSaleVal);
			Assert.assertEquals(ContractSaleVal.toUpperCase(), PropertyContract.toUpperCase());
			
			//Select Contract Copy
			funclib.DelayTime();
			String ContractCopyVal = PropertyCont.SelContractCopyType(ContractAvailable);		
			System.out.println("Property Contract Copy:" + ContractCopyVal);
			Assert.assertEquals(ContractCopyVal.toUpperCase(), ContractAvailable.toUpperCase());
			
			//Select Contract Sign
			funclib.DelayTime();
			String ContractSignedVal = PropertyCont.SelContractSignType(ContractSigned);		
			System.out.println("Property Contract Signed:" + ContractSignedVal);
			Assert.assertEquals(ContractSignedVal.toUpperCase(), ContractSigned.toUpperCase());
			
			//Input Vendor Name
			funclib.DelayTime();
			PropertyCont.InputVendorName(VendorName);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			PropertyCont.NextPage();
		}
	}	
}