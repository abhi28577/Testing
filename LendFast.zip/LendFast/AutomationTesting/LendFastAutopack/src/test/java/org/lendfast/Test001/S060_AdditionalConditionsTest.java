package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.contractconditions.AdditionalConditions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S060_AdditionalConditionsTest extends ParentPage 
{
	AdditionalConditions additionalconditions;
	CommonFuncLib funclib;	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Additional Conditions
		additionalconditions = new AdditionalConditions();
		funclib=new CommonFuncLib();
	}	
	
	@Test
	public void Validate_CreditAdditionalConditions() throws InterruptedException
	{	
		funclib.DelayTime();
		String SectionText=additionalconditions.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Additional Conditions");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
			
		//Navigate to Next Page
		additionalconditions.NextPage();	
	}	
}
