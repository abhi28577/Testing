package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.returneddocuments.ReturnedDocumentHomePage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S119_ReturnedDocumentHomePageTest extends ParentPage
{
	ReturnedDocumentHomePage ReturnedDocHome;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Decision
		ReturnedDocHome = new ReturnedDocumentHomePage();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_Settlement5ReturnedDocument() throws InterruptedException
	{
		funclib.DelayTime();
		String SectionText=ReturnedDocHome.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Returned documents");
			
		funclib.DelayTime();
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Navigate to Next Page
		ReturnedDocHome.NextPage();
	}
}

