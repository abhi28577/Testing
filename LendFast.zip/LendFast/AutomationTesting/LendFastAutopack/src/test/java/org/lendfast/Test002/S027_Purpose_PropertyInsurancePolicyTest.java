package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_PropertyInsurancePolicy;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S027_Purpose_PropertyInsurancePolicyTest extends ParentPage 
{
	Purpose_PropertyInsurancePolicy PurposeInsurancePolicy;
	CommonFuncLib funclib; 
	String SheetName = "purpose_securitytitle";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		PurposeInsurancePolicy = new Purpose_PropertyInsurancePolicy();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] PurposePolicy()
	{
		//Extracting Contract Details from Excel Sheet
		Object PropertyContract[][] = TestDataUtil.getTestData(SheetName);
		return PropertyContract;
	}
	
	@Test (dataProvider = "PurposePolicy")
	public void Validate_PolicyPurpose(String TestCaseId,String TitleRegister, String TitleName, String PolicyType) throws InterruptedException
	{
		String TestDataValue = "TC002";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=PurposeInsurancePolicy.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Property Insurance Policy Detail");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			//Select Property Insurance Policy - New/Existing
			funclib.DelayTime();
			String InsurancePolicyVal = PurposeInsurancePolicy.SelInsurancePolicy(PolicyType);		
			System.out.println("Insurance Policy Type:" + InsurancePolicyVal);
			Assert.assertEquals(InsurancePolicyVal.toUpperCase(), PolicyType.toUpperCase());
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
									
			//Navigate to Next Page
			PurposeInsurancePolicy.NextPage();	
					
			//Capture Screenshot
			funclib.CaptureScreenShot();
											
			funclib.DelayTime();
					
			//Navigate to Next Page
			PurposeInsurancePolicy.NextPage();
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
											
			funclib.DelayTime();
					
			//Navigate to Next Page
			PurposeInsurancePolicy.NextPage();
		}
	}	
}
