package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.checklist.ChecklistSettlement;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S088_CheckListSettlementTest extends ParentPage 
{
	ChecklistSettlement Chklist;
	CommonFuncLib funclib; 
	String SheetName = "checklist";
	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  CheckList
		Chklist = new ChecklistSettlement();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] ChecklistGoto()
	{
		//Extracting Contract Details from Excel Sheet
		Object ChecklistGoTo[][] = TestDataUtil.getTestData(SheetName);
		return ChecklistGoTo;
	}
	
	@Test (dataProvider = "ChecklistGoto")
	public void Validate_ThirdSettlementDocuments(String TestCaseId, String InsuranceReq, String InsurancePolicy, String CompanyCode, String PolicyType, String PolicyNumber, String CoverAmount, String ExpiryDate, String NPBSInterest) throws InterruptedException
	{	
		String TestId="TC002";
		
		if(TestCaseId .equals(TestId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=Chklist.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Check List");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			//Select Non-Mandatory List
			Chklist.NonMandatory();
		
		
			//Submission Position
			Chklist.SubmissionPosGoTo(InsuranceReq, InsurancePolicy, CompanyCode, PolicyType, PolicyNumber, CoverAmount, ExpiryDate, NPBSInterest);
			//Chklist.SubmissionPosImage();
			
		
			//Navigate to Next Page (Additional Conditions Page)
			Chklist.NextPage();
			
			//Navigate to Next Page (Action Page)
			Chklist.NextPage();
		}
		
		
	}
}
