package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantEmploymentDetailSkip;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S014_ApplicantEmploymentDetailSkipTest extends ParentPage 
{
	ApplicantEmploymentDetailSkip applicantemploymentdetailskip;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Employment		
		applicantemploymentdetailskip = new ApplicantEmploymentDetailSkip();
		funclib=new CommonFuncLib();
	}
	
	//Validating Heading Section
	@Test
	public void Validate_HeadingSection() throws InterruptedException
	{		
		try 
		{
			funclib.DelayTime();
			String SectionText=applicantemploymentdetailskip.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Employments for Applicant");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		funclib.DelayTime();
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Go to Next Page
		applicantemploymentdetailskip.NextClick();
	}	

}
