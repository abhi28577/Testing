package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.purpose.Purpose_PurchaseDeposit;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S017_Purpose_PurchaseDepositTest extends ParentPage 
{
	Purpose_PurchaseDeposit PurchaseDeposit;
	CommonFuncLib funclib;	
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Purpose Contract
		PurchaseDeposit = new Purpose_PurchaseDeposit();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_PurchaseDeposit() throws InterruptedException
	{
		//Validating Heading Section
		try 
		{
			funclib.DelayTime();
			String SectionText=PurchaseDeposit.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Purchase Real Estate - Deposits");
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Navigate to Add Deposit Page
		PurchaseDeposit.AddDepositPage();		
	}	
}
