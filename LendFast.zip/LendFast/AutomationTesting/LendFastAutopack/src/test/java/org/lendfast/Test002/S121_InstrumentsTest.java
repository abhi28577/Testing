package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.securities.Instruments;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S121_InstrumentsTest extends ParentPage
{
	Instruments instruments;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Instruments
		instruments = new Instruments();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_Settlement5Instruments() throws InterruptedException
	{
		funclib.DelayTime();
		String SectionText=instruments.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Instruments");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Navigate to Next Page
		instruments.NextPage();
	}
	
}
