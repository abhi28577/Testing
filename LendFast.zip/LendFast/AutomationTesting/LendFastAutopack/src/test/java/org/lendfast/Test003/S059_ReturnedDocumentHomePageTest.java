package org.lendfast.Test003;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.returneddocuments.ReturnedDocumentHomePage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S059_ReturnedDocumentHomePageTest extends ParentPage
{
	ReturnedDocumentHomePage ReturnedDocHome;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Decision
		ReturnedDocHome = new ReturnedDocumentHomePage();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_Settlement2ReturnedDocument() throws InterruptedException
	{
		funclib.DelayTime();
		String SectionText=ReturnedDocHome.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Returned documents");
		
		funclib.DelayTime();
		ReturnedDocHome.ReceivedCommentsMethod();
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Navigate to Next Page
		ReturnedDocHome.NextPage();
	}
}

