package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantLoanParty;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S012_ApplicantLoanPartyTest extends ParentPage 
{
	ApplicantLoanParty applicantloanparty;
	CommonFuncLib funclib;
	

	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Loan Party
		applicantloanparty=new ApplicantLoanParty();
		funclib=new CommonFuncLib();
	}
	
	//Validating Heading Section
	@Test
	public void Validate_HeadingSection()
	{		
		try 
		{
			funclib.DelayTime();
			String SectionText=applicantloanparty.CaptureHeadSection();		
			System.out.println("Heading Section:" + SectionText);
			Assert.assertEquals(SectionText, "Loan Parties");
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Go to Next Page
			funclib.DelayTime();
			applicantloanparty.NextClick();
			
			funclib.DelayTime();
			String SectionTextExisting=null;
			String ExistHeadSection = "Existing Applications";
			SectionTextExisting=applicantloanparty.CaptureHeadSectionExisting();		
			System.out.println("Heading Section:" + SectionTextExisting);
			Assert.assertEquals(SectionTextExisting, "Existing Applications");
				
			if(SectionTextExisting .equals(ExistHeadSection))
			{
				//Capture Screenshot
				funclib.CaptureScreenShot();	
				
				//Go to Next Page
				funclib.DelayTime();
				applicantloanparty.NextClick();
						
				//Capture Screenshot
				funclib.CaptureScreenShot();	
			}			
			
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}				
	}	

}
