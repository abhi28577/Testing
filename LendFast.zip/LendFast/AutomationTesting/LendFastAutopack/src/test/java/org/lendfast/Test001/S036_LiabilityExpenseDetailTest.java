package org.lendfast.Test001;

import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.liabilities.LiabilityExpenseDetail;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S036_LiabilityExpenseDetailTest 
{
	LiabilityExpenseDetail LiabExpense;	
	CommonFuncLib funclib; 
	String SheetName = "liabilities";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Property Purpose 
		LiabExpense = new LiabilityExpenseDetail();		
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] LiabilityApplicant()
	{
		//Extracting Contract Details from Excel Sheet
		Object Liability[][] = TestDataUtil.getTestData(SheetName);
		return Liability;
	}
	
	@Test (dataProvider = "LiabilityApplicant")
	public void Validate_LiabilityApplicantExpenseDetail(String TestCaseId,String Liability,String GeneralExpense, String LivingExpense, String LivingPayFreq, String PartyType, String IsLiable) throws InterruptedException	
	{		
		String NullType="null";
		String TestDataValue = "TC001";
		
		if(TestDataValue .equals(TestCaseId))
		{
		
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=LiabExpense.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Liabilities and Expenses");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			if(!Liability .equals(NullType))
			{			
				//Select Expense Type
				funclib.DelayTime();
				String ExpenseTypeVal = LiabExpense.SelExpenseType(GeneralExpense);		
				System.out.println("Expense Type for General Expense:" + ExpenseTypeVal);
				Assert.assertEquals(ExpenseTypeVal.toUpperCase(), GeneralExpense.toUpperCase());
				
				//Click on Add Expense
				LiabExpense.AddExpense();
				
				//Validating Expense Heading Section
				funclib.DelayTime();
				String SectionText=LiabExpense.CaptureExpenseHeadSection();		
				System.out.println("Expense Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "General Living Expenses Details");			
				
				//Add Expenses
				LiabExpense.GeneralLivingExpense(Liability,LivingExpense, LivingPayFreq, PartyType, IsLiable);		
			}
			
			
			if(Liability .equals(NullType))
			{
			
				//Capture Screenshot
				funclib.CaptureScreenShot();
									
				//Navigate to Employment Page
				Thread.sleep(1000);
				LiabExpense.NextPage();	
			
				//Capture Screenshot
				funclib.CaptureScreenShot();
									
				//Navigate to Income Page
				Thread.sleep(1000);
				LiabExpense.NextPage();
			
				//Capture Screenshot
				funclib.CaptureScreenShot();
											
				//Navigate to Securities Page
				Thread.sleep(1000);
				LiabExpense.NextPage();
			}	
		}
	}
}
