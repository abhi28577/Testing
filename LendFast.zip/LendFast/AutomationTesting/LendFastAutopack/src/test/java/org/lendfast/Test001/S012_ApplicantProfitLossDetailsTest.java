package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.ApplicantProfitLossDetails;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S012_ApplicantProfitLossDetailsTest extends ParentPage 
{
	ApplicantProfitLossDetails applicantprofitloss;
	CommonFuncLib funclib;
	String SheetName = "personal_profitlossdet";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Applicant Profit Loss/BalanceSheet Details
		applicantprofitloss=new ApplicantProfitLossDetails();
		funclib=new CommonFuncLib();
	}
	
		
	@DataProvider
	public Object[][] FinanYearType()
	{
		//Extracting Financial Year from Excel Sheet
		Object FinanYear[][] = TestDataUtil.getTestData(SheetName);
		return FinanYear;
	}

	@Test (dataProvider = "FinanYearType")
	public void Validate_ApplicantFinanYearType(String TestCaseId,String Party,String FinYear, String FinMonths, String FinAudit, String FinTurnOver, String FinExpenses, String FinDepreciation, String FinNonCash, String FinNonRecurring, String FinAddBackDescription, String FinAddBackAmount, String FinCurrentAssets, String FinFixedAssets, String FinOtherAssets, String FinCurrentLiabilities, String FinLongTermLiabilities, String FinShareholder, String FinEquity) throws InterruptedException
	{		
		
		String TestDataValue = "TC001_01";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=applicantprofitloss.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Profit and Loss Details");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			funclib.DelayTime();
			// Select Financial Year
			String FinancialYearVal = applicantprofitloss.SelFinanYearType(FinYear);
			System.out.println("Applicant Financial Year:" + FinancialYearVal);
			Assert.assertEquals(FinancialYearVal, FinYear);
			
			funclib.DelayTime();
			// Select Financial Months
			String FinancialMonthsVal = applicantprofitloss.SelFinanMonthsType(FinMonths);
			System.out.println("Applicant Financial Months:" + FinancialMonthsVal);
			Assert.assertEquals(FinancialMonthsVal, FinMonths);
			
			funclib.DelayTime();
			// Select Financial Audit
			String FinancialAuditVal = applicantprofitloss.SelFinanAuditType(FinAudit);
			System.out.println("Applicant Financial Audit:" + FinancialAuditVal);
			Assert.assertEquals(FinancialAuditVal, FinAudit);
			
			funclib.DelayTime();
			// Input TurnOver/Gross Sales
			applicantprofitloss.InputTurnOverSales(FinTurnOver);
			
			funclib.DelayTime();
			// Input Total Expenses
			applicantprofitloss.InputTotalExpenses(FinExpenses);
			
			funclib.DelayTime();
			// Input Depreciation
			applicantprofitloss.InputDepreciation(FinDepreciation);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			applicantprofitloss.NextPage();
		}
	}	
	
}
