package org.lendfast.Test002;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.status.ApplicationStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class S092_ApplicationStatusTest extends ParentPage
{
	ApplicationStatus applicationstatus;
	CommonFuncLib funclib;
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Application Status
		applicationstatus = new ApplicationStatus();
		funclib=new CommonFuncLib();
	}
	
	@Test
	public void Validate_Settlement3ApplicationStatus() throws InterruptedException
	{
		funclib.DelayTime();
		String SectionText=applicationstatus.CaptureHeadSection();		
		System.out.println("Heading Section:" + SectionText);
		Assert.assertEquals(SectionText, "Application Status");
		
		//Capture Screenshot
		funclib.CaptureScreenShot();
		
		//Navigate to Next Page
		applicationstatus.NextPage();
	}
	
}
