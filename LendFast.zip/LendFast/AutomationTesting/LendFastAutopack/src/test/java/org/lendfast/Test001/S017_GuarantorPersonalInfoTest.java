package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.personal.GuarantorPersonalInfo;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S017_GuarantorPersonalInfoTest extends ParentPage 
{
	GuarantorPersonalInfo guarantorpersonalinfo;
	CommonFuncLib funclib;
	String SheetName = "personal_detail";


	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Application Type
		guarantorpersonalinfo = new GuarantorPersonalInfo();
		funclib=new CommonFuncLib();
	}
	
		
	@DataProvider
	public Object[][] GuarantorPersonalInfo()
	{
		//Extracting Trustee from Excel Sheet
		Object Trusteetype[][] = TestDataUtil.getTestData(SheetName);
		return Trusteetype;
	}	
	
	@Test (dataProvider = "GuarantorPersonalInfo")
	public void Validate_GuarantorPersonalInfo(String TestCaseId,String Party,String Trustee, String Partner, String Dependent, String AgeDependent, String PreCompletedForm, String Sign) throws InterruptedException
	{
		String TestDataValue = "TC001_02";
		
		if(TestDataValue .equals(TestCaseId))
		{
			//Validating Heading Section
			try 
			{
				funclib.DelayTime();
				String SectionText=guarantorpersonalinfo.CaptureHeadSection();		
				System.out.println("Heading Section:" + SectionText);			
				Assert.assertEquals(SectionText, "Personal Detail for Guarantor");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			funclib.DelayTime();
			// Select Spouse/Partner
			String PartnerVal = guarantorpersonalinfo.SelPartner(Partner);		
			System.out.println("Guarantor Spouse/Partner:" + PartnerVal);
			Assert.assertEquals(PartnerVal.toUpperCase(), Partner.toUpperCase());
			
			funclib.DelayTime();
			// Select Dependents
			String DependentVal = guarantorpersonalinfo.SelDependent(Dependent);		
			System.out.println("Guarantor Dependent:" + DependentVal);
			Assert.assertEquals(DependentVal.toUpperCase(), Dependent.toUpperCase());
			
			funclib.DelayTime();
			// Select Signing Method
			String SignMethodVal = guarantorpersonalinfo.SelSignMethod(Sign);
			System.out.println("Guarantor Signing Method:" + SignMethodVal);
			Assert.assertEquals(SignMethodVal, Sign);
			
			//Capture Screenshot
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			guarantorpersonalinfo.NextPage();
		}
	}	
	
}
