package org.lendfast.Test001;

import org.lendfast.base.ParentPage;
import org.lendfast.functionlib.CommonFuncLib;
import org.lendfast.pages.applicationtype.Origination;
import org.lendfast.utils.TestDataUtil;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class S004_OriginationTest extends ParentPage 
{
	Origination origination;
	CommonFuncLib funclib;	
	String SheetName = "applicationtype";
	
	@BeforeMethod
	public void SetUp()
	{							
		//Initializing  Origination
		origination = new Origination();
		funclib=new CommonFuncLib();
	}
	
	@DataProvider
	public Object[][] Origination()
	{
		//Extracting Origination Area from Excel Sheet
		Object OriginArea[][] = TestDataUtil.getTestData(SheetName);
		return OriginArea;
	}

	@Test (dataProvider = "Origination")
	public void Validate_Origination(String TestCaseId, String AppType, String TopUp,String AccountNumber, String Origin, String OriginLevel, String OriginLevel2, String Referrer,String ApplicationId) throws InterruptedException
	{
		//String RunValue = "Execute";
		String TestDataValue = "TC001";
		
		
		if(TestDataValue .equals(TestCaseId))
		{			
		
			//Validating Heading Section		
			try 
			{
				funclib.DelayTime();
				String SectionText=origination.CaptureHeadSection();
				System.out.println("Heading Section:" + SectionText);
				Assert.assertEquals(SectionText, "Origination");
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			
			
			// Selecting Origination Area
			funclib.DelayTime();
			String OriginVal = origination.SelOriginationArea(Origin);
			System.out.println("Origination Area:" + OriginVal);
			Assert.assertEquals(OriginVal,Origin );
				
			
			// Selecting Originator Level
			funclib.DelayTime();
			String OriginLevelVal = origination.SelOriginatorLevel(OriginLevel);
			System.out.println("Originator Level:" + OriginLevelVal);
			Assert.assertEquals(OriginLevelVal, OriginLevel);
			funclib.DelayTime();
			
			// Selecting Referrer Commission
			funclib.DelayTime();
			String ReferrerVal = origination.SelReferrerType(Referrer);		
			System.out.println("Referrer Commission:" + ReferrerVal);
			Assert.assertEquals(ReferrerVal, Referrer.toLowerCase());
			funclib.DelayTime();
			
			//Update Application Id
			String AppIdResult = origination.CaptureApplicationId();
			System.out.println("Application Id:" + AppIdResult);
			
			String RowLine = TestCaseId.replaceAll("\\D","");
			int RowNum = Integer.parseInt(RowLine);
			RowNum = RowNum+1;
			funclib.SetCellData(SheetName, "ApplicationId", RowNum, AppIdResult);
			
			
			//Capture Screenshot
			funclib.DelayTime();
			funclib.CaptureScreenShot();
			
			//Navigate to Next Page
			origination.NextPage();
			
			//Update Result Type in Test Data Sheet
			//funclib.DelayTime();
			//funclib.SetCellData("applicationtype", "RunType", 2, "Complete");
		}	
	}
	

}
